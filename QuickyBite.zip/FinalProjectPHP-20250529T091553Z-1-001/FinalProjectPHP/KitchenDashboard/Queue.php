<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

date_default_timezone_set('Asia/Manila');

$conn = new mysqli("localhost", "root", "", "adris_ordertaking");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form status update
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['order_id'])) {
    $orderId = intval($_POST['order_id']);

    // Get current status and user ID
    $stmt = $conn->prepare("SELECT Status, user_id FROM orders WHERE OrderID = ?");
    $stmt->bind_param("i", $orderId);
    $stmt->execute();
    $stmt->bind_result($currentStatus, $user_id);
    $stmt->fetch();
    $stmt->close();

    // Determine next status
    $nextStatus = ($currentStatus === "In Queue") ? "Preparing" : (($currentStatus === "Preparing") ? "Done" : $currentStatus);

    if ($nextStatus !== $currentStatus) {
        // Update status in database
        $update = $conn->prepare("UPDATE orders SET Status = ? WHERE OrderID = ?");
        $update->bind_param("si", $nextStatus, $orderId);
        $update->execute();
        $update->close();

        // Get user email from `users` table
        $emailStmt = $conn->prepare("SELECT email FROM users WHERE user_id = ?");
        $emailStmt->bind_param("i", $user_id);
        $emailStmt->execute();
        $emailStmt->bind_result($userEmail);
        $emailStmt->fetch();
        $emailStmt->close();

        if (!empty($userEmail)) {
            // Send email
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'adrisquickybite@gmail.com';
                $mail->Password = 'dxvz rvwx hzvz frfn'; // Make sure this is a valid app password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
                $mail->Port = 465;

                $mail->setFrom('adrisquickybite@gmail.com', 'Adris Restaurant');
                $mail->addAddress($userEmail);
                $mail->Subject = "Order #$orderId Status Update";
                $mail->Body    = "Hello, your order status is now: $nextStatus.";

                $mail->send();
            } catch (Exception $e) {
                error_log("Email error: " . $mail->ErrorInfo);
            }
        }
    }

    // Only redirect after processing everything
    header("Location: LIVEORDER.php");
    exit();
}

// Get orders
$sql = "SELECT orders.OrderID, orders.CustomerName, orders.Type, orders.PickupDate, orders.Pickuptime, orders.Status,
               order_items.FoodName, order_items.Quantity
        FROM orders
        INNER JOIN order_items ON orders.OrderID = order_items.OrderID
        WHERE DATE(orders.PickupDate) = CURDATE()
        ORDER BY orders.OrderID";

$result = $conn->query($sql);

$now = new DateTime();
$groupA = []; // ≤ 30 min
$groupB = []; // > 30 min
$groupDone = []; // Done orders

// Group items by OrderID
$ordersGrouped = [];

while ($row = $result->fetch_assoc()) {
    $orderID = $row['OrderID'];
    
    // If the order doesn't exist yet in the grouped orders array, initialize it
    if (!isset($ordersGrouped[$orderID])) {
        $ordersGrouped[$orderID] = [
            'OrderID' => $orderID,
            'Status' => $row['Status']
        ];
    }

    // Add the item to the items array for this order
    $ordersGrouped[$orderID]['items'][] = [
        'OrderID' => $row['OrderID']
    ];
}

// Now, categorize orders into groups
foreach ($ordersGrouped as $order) {

    // Check if the order status is "Done"
    if ($order['Status'] === "Done") {
        $groupDone[] = $order;
    } else {
            // orders preparing
            $groupA[] = $order;  
        }
}


// Display orders by group
function displayGroup($orders, $title) {
    echo "<h2>$title</h2><div class='container'>";
    foreach ($orders as $order) {
        echo "<div class='card'>";
        echo "<strong>Order ID:</strong> " . $order["OrderID"] . "<br>";
        echo "</div>";
    }
    echo "</div>";
}

echo "<style>
.card {
  border: 1px solid #ccc;
  border-radius: 10px;
  padding: 15px;
  margin: 15px;
  background-color: #f9f9f9;
  width: 300px;
}
.container {
  display: flex;
  flex-wrap: wrap;
}
</style>";

if (empty($groupA) && empty($groupDone)) {
    echo "<p>No orders found for today.</p>";
} else {
    displayGroup($groupA, "⏳ Preparing");
    displayGroup($groupDone, "✅ Completed Orders");
}

$conn->close();
?>
