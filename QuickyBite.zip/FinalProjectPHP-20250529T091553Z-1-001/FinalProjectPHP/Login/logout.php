<?php
// Start the session
session_start();

// Database connection (to remove token from database if needed)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "adris_ordertaking";

// Create connection if needed for token deletion
if (isset($_SESSION['user_id']) && isset($_COOKIE['remember_token'])) {
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    if (!$conn->connect_error) {
        // Remove token from database
        $token = $_COOKIE['remember_token'];
        $userId = $_SESSION['user_id'];
        
        $stmt = $conn->prepare("DELETE FROM remember_tokens WHERE user_id = ? AND token = ?");
        $stmt->bind_param("is", $userId, $token);
        $stmt->execute();
        
        // Close connection
        $conn->close();
    }
}

// Option to keep username cookie but remove token for auto-login
$keepUsername = true; // Set to false if you want to clear the username too

// Clear the session variables
$_SESSION = array();

// Destroy the session
session_destroy();

// Clear the remember token cookie (but optionally keep username)
if (isset($_COOKIE['remember_token'])) {
    setcookie('remember_token', '', time() - 3600, '/');
}

// Optionally clear the username cookie
if (!$keepUsername && isset($_COOKIE['remember_user'])) {
    setcookie('remember_user', '', time() - 3600, '/');
}

// Redirect to the login page with a success message
header("Location: logins.php?status=success&message="); 
exit;
?>