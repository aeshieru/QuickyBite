    <?php
    session_start();
    $username = "root";
    $password = "";
    $database = "adris_ordertaking";
    $conn = mysqli_connect("localhost", $username, $password, $database);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Handle AJAX requests for adding to cart
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] == 'add_to_cart') {
        $item = [
            'FoodName' => $_POST['FoodName'],
            'FoodPrice' => $_POST['FoodPrice'],
            'FoodImage' => $_POST['FoodImage'],
            'Quantity' => 1
        ];

        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        $found = false;
        foreach ($_SESSION['cart'] as &$cartItem) {
            if ($cartItem['FoodName'] === $item['FoodName']) {
                $cartItem['Quantity']++;
                $found = true;
                break;
            }
        }

        if (!$found) {
            $_SESSION['cart'][] = $item;
        }
        
        // Redirect back to the menu page after adding to cart
        header("Location: DisplayMenu.php?added=true");
        exit;
    }

    // Show notification if item was added
    $showNotification = isset($_GET['added']) && $_GET['added'] === 'true';

    // Get menu items
    $sql = "SELECT FoodName, FoodPrice, Stock, FoodImage FROM menuitems";
    $result = mysqli_query($conn, $sql);

    // Calculate cart total
    $cartTotal = 0;
    if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $item) {
            $cartTotal += $item['FoodPrice'] * $item['Quantity'];
        }
    }
    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Menu - QuickyBite</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link rel="stylesheet" href="ustyles/DisplayMenu.css">
    </head>
    <body>
        <!-- Cart icon in top right corner with summary on hover -->
        <div class="cart-icon-container">
            <a href="ViewCart.php" class="cart-icon">
                <img src="uimages/shopping-cart.png" alt="Cart">
                <?php if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                    <span class="cart-count"><?php echo count($_SESSION['cart']); ?></span>
                <?php endif; ?>
            </a>
            
            <!-- Cart Summary Tooltip - Shows on hover using CSS -->
            <div class="cart-summary">
                <div class="cart-summary-title">Cart Summary</div>
                
                <?php if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                    <div class="cart-summary-items">
                        <?php 
                        // Display up to 5 items
                        $count = 0;
                        foreach ($_SESSION['cart'] as $item):
                            if ($count < 5):
                        ?>
                            <div class="cart-summary-item">
                                <img class="cart-summary-item-image" src="<?php echo $item['FoodImage']; ?>" alt="<?php echo $item['FoodName']; ?>">
                                <div class="cart-summary-item-details">
                                    <p class="cart-summary-item-name"><?php echo $item['FoodName']; ?></p>
                                    <p class="cart-summary-item-price">₱<?php echo number_format($item['FoodPrice'], 2); ?></p>
                                </div>
                                <span class="cart-summary-quantity">x<?php echo $item['Quantity']; ?></span>
                            </div>
                        <?php
                            endif;
                            $count++;
                        endforeach;
                        
                        // If there are more items than shown
                        if (count($_SESSION['cart']) > 5):
                            $moreItems = count($_SESSION['cart']) - 5;
                        ?>
                            <div class="cart-summary-more">+<?php echo $moreItems; ?> more item<?php echo $moreItems > 1 ? 's' : ''; ?></div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="cart-summary-total">
                        <span>Total:</span>
                        <span>₱<?php echo number_format($cartTotal, 2); ?></span>
                    </div>
                    
                <?php else: ?>
                    <div class="cart-summary-empty">Your cart is empty</div>
                <?php endif; ?>
                
                <a href="ViewCart.php" class="cart-summary-view">View Full Cart</a>
            </div>
        </div>
        
        <!-- Notification for added items -->
        <?php if ($showNotification): ?>
        <div class="notification show">
            <div class="notification-content">
                <span>Item added to cart!</span>
                <form method="get" action="DisplayMenu.php">
                    <button type="submit" class="close-btn">OK</button>
                </form>
            </div>
        </div>
        <script>
            // Auto-hide notification after 3 seconds
            setTimeout(function() {
                document.querySelector('.notification').classList.remove('show');
            }, 3000);
        </script>
        <?php endif; ?>

        <nav class="side-nav">
            <div class="logo-box">QB</div>
            <a href="user_dashboard.php" class="nav-icon">
                <img src="uimages/house-blank.png" alt="Dashboard">
                <span class="nav-icon-text">Dashboard</span>
            </a>
            <a href="DisplayMenu.php" class="nav-icon active">
                <img src="uimages/task-checklist.png" alt="Menu">
                <span class="nav-icon-text">Menu</span>
            </a>
            <a href="ViewCart.php" class="nav-icon">
                <img src="uimages/shopping-cart.png" alt="Cart">
                <span class="nav-icon-text">Cart</span>
            </a>
            <a href="SeatAvailability.php" class="nav-icon">
                <img src="uimages/chair.png" alt="Seats">
                <span class="nav-icon-text">Seat Availability</span>
            </a>
            <a href="MyAccount.php" class="nav-icon">
                <img src="uimages/user.png" alt="My Account">
                <span class="nav-icon-text">My Account</span>
            </a>
            <a href="../Login/logout.php" class="nav-icon">
                <img src="uimages/exit.png" alt="Logout">
                <span class="nav-icon-text">Log Out</span>
            </a>
        </nav>

        <div class="main-content">
            <h1>Menu</h1>
            
            <div class="container">
                <div class="menu-container">
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <div class="menu-card">
                            <?php 
                            $imageData = base64_encode($row['FoodImage']);
                            $src = 'data:image/jpeg;base64,' . $imageData;
                            ?>
                            <img src="<?php echo $src; ?>" alt="<?php echo $row['FoodName']; ?>">
                            <h3><?php echo $row['FoodName']; ?></h3>
                            <p>₱<?php echo number_format($row['FoodPrice'], 2); ?></p>
                            <form method="post" action="DisplayMenu.php">
                                <input type="hidden" name="action" value="add_to_cart">
                                <input type="hidden" name="FoodName" value="<?php echo htmlspecialchars($row['FoodName']); ?>">
                                <input type="hidden" name="FoodPrice" value="<?php echo $row['FoodPrice']; ?>">
                                <input type="hidden" name="FoodImage" value="<?php echo $src; ?>">
                                <?php if ($row['Stock'] >= 1): ?>
                                    <button type="submit" class="add-to-cart-btn">Add to Cart</button>
                                <?php else: ?>
                                    <button type="button" class="add-to-cart-btn out-of-stock" disabled>Item not available</button>
                                <?php endif; ?>
                            </form>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>
    </body>
    </html>