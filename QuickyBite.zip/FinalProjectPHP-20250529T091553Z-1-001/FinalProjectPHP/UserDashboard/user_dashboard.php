<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: logins.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "adris_ordertaking";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user details including profile picture (BLOB)
$userId = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT full_name, username, email, profile_picture FROM users WHERE user_id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Convert profile picture to base64
$profilePictureData = '';
if (!empty($user['profile_picture'])) {
    $base64 = base64_encode($user['profile_picture']);
    $profilePictureData = 'data:image/jpeg;base64,' . $base64;
} else {
    // Use default avatar image
    $profilePictureData = 'uimages/default-avatar.png';
}

// Set default member since date
$memberSince = date('F Y');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - QuickyBite</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="ustyles/user_dashboard.css">
</head>
<body>
    <nav class="side-nav">
        <div class="logo-box">QB</div>
        <a href="user_dashboard.php" class="nav-icon active">
            <img src="uimages/house-blank.png" alt="Dashboard">
            <span class="nav-icon-text">Dashboard</span>
        </a>
        <a href="DisplayMenu.php" class="nav-icon">
            <img src="uimages/task-checklist.png" alt="Menu">
            <span class="nav-icon-text">Menu</span>
        </a>
        <a href="ViewCart.php" class="nav-icon">
            <img src="uimages/shopping-cart.png" alt="Cart">
            <span class="nav-icon-text">Cart</span>
        </a>
        <a href="SeatAvailability.php" class="nav-icon">
            <img src="uimages/chair.png" alt="Seats">
            <span class="nav-icon-text">Seat Availability</span>
        </a>
        <a href="MyAccount.php" class="nav-icon">
            <img src="uimages/user.png" alt="My Account">
            <span class="nav-icon-text">My Account</span>
        </a>
        <a href="../Login/logout.php" class="nav-icon">
            <img src="uimages/exit.png" alt="Logout">
            <span class="nav-icon-text">Log Out</span>
        </a>
    </nav>

    <div class="main-content">
        <div class="dashboard-header">
            <h1>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?>!</h1>
            <div class="user-greeting">
                <p>What would you like to order today?</p>
                <a href="DisplayMenu.php" class="order-now-btn">Order Now</a>
            </div>
        </div>

        <div class="dashboard-grid">
            <div class="dashboard-card user-info">
                <div class="card-header">
                    <h2>My Profile</h2>
                    <a href="MyAccount.php" class="edit-btn"><i class="fas fa-pencil-alt"></i></a>
                </div>
                <div class="profile-details">
                    <div class="profile-avatar">
                        <img src="<?php echo htmlspecialchars($profilePictureData); ?>" alt="Profile Picture" style="width: 100px; height: 100px; border-radius: 50%; object-fit: cover;">
                    </div>
                    <div class="profile-info">
                        <p><span>Name:</span> <?php echo htmlspecialchars($user['full_name']); ?></p>
                        <p><span>Username:</span> <?php echo htmlspecialchars($user['username']); ?></p>
                        <p><span>Email:</span> <?php echo htmlspecialchars($user['email'] ?? 'Not set'); ?></p>
                        <p><span>Member since:</span> <?php echo $memberSince; ?></p>
                    </div>
                </div>
            </div>

            <div class="dashboard-card quick-actions">
                <div class="card-header">
                    <h2>Quick Actions</h2>
                </div>
                <div class="actions-grid">
                    <a href="DisplayMenu.php" class="action-item">
                        <i class="fas fa-utensils"></i>
                        <span>Browse Menu</span>
                    </a>
                    <a href="ViewCart.php" class="action-item">
                        <i class="fas fa-shopping-cart"></i>
                        <span>View Cart</span>
                    </a>
                    <a href="MyAccount.php" class="action-item">
                        <i class="fas fa-history"></i>
                        <span>Order History</span>
                    </a>    
                    <a href="SeatAvailability.php" class="action-item">
                        <i class="fas fa-chair"></i>
                        <span>Reserve Seat</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="ujs/user_dashboard.js"></script>
</body>
</html>
