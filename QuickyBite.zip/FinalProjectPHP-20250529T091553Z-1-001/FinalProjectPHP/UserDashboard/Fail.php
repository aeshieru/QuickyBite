    <?php
session_start();
        $conn = mysqli_connect("localhost", "root", "", "adris_ordertaking");
    if (!$conn) die("Connection failed");

    unset($_SESSION['cart']);


?>

    

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Order Confirmation - QuickyBite</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link rel="stylesheet" href="ustyles/ProcessCheckout.css">
    </head>
    <body>
        <nav class="side-nav">
            <div class="logo-box">QB</div>
            <a href="user_dashboard.php" class="nav-icon">
                <img src="uimages/house-blank.png" alt="Dashboard">
                <span class="nav-icon-text">Dashboard</span>
            </a>
            <a href="DisplayMenu.php" class="nav-icon">
                <img src="uimages/task-checklist.png" alt="Menu">
                <span class="nav-icon-text">Menu</span>
            </a>
            <a href="ViewCart.php" class="nav-icon">
                <img src="uimages/shopping-cart.png" alt="Cart">
                <span class="nav-icon-text">Cart</span>
            </a>
            <a href="SeatAvailability.php" class="nav-icon">
                <img src="uimages/chair.png" alt="Seats">
                <span class="nav-icon-text">Seat Availability</span>
            </a>
            <a href="MyAccount.php" class="nav-icon">
                <img src="uimages/user.png" alt="My Account">
                <span class="nav-icon-text">My Account</span>
            </a>
            <a href="../Login/logout.php" class="nav-icon">
                <img src="uimages/exit.png" alt="Logout">
                <span class="nav-icon-text">Log Out</span>
            </a>
        </nav>

        <div class="main-content">
            <h1>Transaction Failed</h1>
            
            <div class="container">
                <div class="confirmation-container">

                        <div class="confirmation-error">
                            <h2>We're sorry, but your transaction could not be completed.</h2>
                            <p>Please check your payment details and try again.<br>If the issue persists, contact our support team for assistance..</p>
                        </div>

                </div>
            </div>
        </div>
    </body>
    </html>