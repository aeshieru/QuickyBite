    <?php
session_start();

require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Process checkout
    $conn = mysqli_connect("localhost", "root", "", "adris_ordertaking");
    if (!$conn) die("Connection failed");
    $reference = $_GET['ref'] ?? null;
    $query = "SELECT * FROM pending_orders WHERE reference = '$reference'";
    $result = mysqli_query($conn, $query);
    $pickupTime = "";

    if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
        //confirming pending orders to queue
        $customerName = $row['customer_name'];
        $cartJson = $row['cart_json'];
        $total = $row['total'];
        $status = "In Queue";
        $orderType = $row['orderType'];
        $pickupDate = $row['pickupDate'];
        $pickupTime = $row['pickupTime'];
        $user_id = $row['userID'];

        // (Optional) Convert JSON cart to PHP array

        $cart = json_decode($cartJson, true);
            
        $stmt = $conn->prepare("INSERT INTO orders (CustomerName, Type, PickupDate, PickupTime, user_id, Status) VALUES (?, ?, ?, ?, ?, ?)");
        if (!$stmt) {
            die("Prepare failed for orders table: (" . $conn->errno . ") " . $conn->error);
        }
        $stmt->bind_param("ssssis",  $customerName, $orderType, $pickupDate,  $pickupTime, $user_id, $status);
        $stmt->execute();
        $orderId = $stmt->insert_id;
        
        //adding items to table order_items

        $stmt = $conn->prepare("INSERT INTO order_items (OrderID, FoodName, Quantity, Price) VALUES (?, ?, ?, ?)");
    if (!$stmt) {
        die("Prepare failed for order_items table: (" . $conn->errno . ") " . $conn->error);
    }
    
    $totalAmount = 0;
    
    foreach ($cart as $item) {
        $foodName = $item['FoodName'];
        $quantity = $item['Quantity'];
        $foodPrice = $item['FoodPrice'];
        $totalAmount += $foodPrice * $quantity;
        
        // Insert item to order_items
        $stmt->bind_param("isid", $orderId, $foodName, $quantity, $foodPrice);
        if (!$stmt->execute()) {
            die("Execute failed: (" . $stmt->errno . ") " . $stmt->error);
        }

        // Deduct stock from food table
        $checkStock = $conn->prepare("SELECT Stock FROM menuitems WHERE FoodName = ?");
        if (!$checkStock) {
            die("Prepare failed for checking stock: (" . $conn->errno . ") " . $conn->error);
        }
        $checkStock->bind_param("s", $foodName);
        $checkStock->execute();
        $checkStock->bind_result($currentStock);
        $checkStock->fetch();
        $checkStock->close();

        $newStock = $currentStock - $quantity;
        if ($newStock < 0) $newStock = 0; // optional safeguard

        $updateStock = $conn->prepare("UPDATE menuitems SET Stock = ? WHERE FoodName = ?");
        if (!$updateStock) {
            die("Prepare failed for updating stock: (" . $conn->errno . ") " . $conn->error);
        }
        $updateStock->bind_param("is", $newStock, $foodName);
        $updateStock->execute();
        $updateStock->close();

        
    }}
    else {
    echo "Order not found.";
    }
    

    $userQuery = $conn->prepare("SELECT email, full_name FROM users WHERE full_name = ?");
    $userQuery->bind_param("s", $customerName);
    $userQuery->execute();
    $userResult = $userQuery->get_result();
    if ($userResult->num_rows === 0) {
        die("User not found.");
    }
    $userData = $userResult->fetch_assoc();
    $userQuery->close();

    $userEmail = $userData['email'];
    $userFullName = $userData['full_name'];

    // Format pickup time and date for display
    $formattedTime = null;
    $formattedDate = null;
    if ($orderType === 'Take Out') {
        $formattedTime = date('g:i A', strtotime($pickupTime));
        $formattedDate = date('F j, Y', strtotime($pickupDate));
    }

    // Send email receipt
    $total = 0;
    $emailBody = "<h2>Hi $userFullName,</h2>";
    $emailBody .= "<p>Thank you for your order! Here's your receipt:</p>";

    // Updated Table with User ID and Order ID
    $emailBody .= "<table border='1' cellpadding='8' cellspacing='0'>";
    $emailBody .= "
        <tr>
            <th colspan='4' style='text-align:left'>Order ID: $orderId</th>
        </tr>
        <tr>
            <th colspan='4' style='text-align:left'>Order Type: $orderType</th>
        </tr>";
        
    // Add pickup details if applicable
    if ($orderType === 'Take Out') {
        $emailBody .= "
        <tr>
            <th colspan='4' style='text-align:left'>Pickup: $formattedDate at $formattedTime</th>
        </tr>";
    }
    
    $emailBody .= "
        <tr>
            <th>Item</th>
            <th>Price</th>
            <th>Qty</th>
            <th>Subtotal</th>
        </tr>";

    foreach ($cart as $item) {
        $subtotal = $item['FoodPrice'] * $item['Quantity'];
        $total += $subtotal;
        $emailBody .= "<tr>
            <td>{$item['FoodName']}</td>
            <td>₱" . number_format($item['FoodPrice'], 2) . "</td>
            <td>{$item['Quantity']}</td>
            <td>₱" . number_format($subtotal, 2) . "</td>
        </tr>";
    }

    $emailBody .= "</table>";
    $emailBody .= "<h3>Total: ₱" . number_format($total, 2) . "</h3>";
    $emailBody .= "<p>Payment Method: <strong>'Gcash'</strong></p>";
    
    // Add pickup reminder for take-out orders
    if ($orderType === 'Take Out') {
        $emailBody .= "<p><strong>Reminder:</strong> Please pick up your order on $formattedDate at $formattedTime.</p>";
    }
    
    $emailBody .= "<p>We appreciate your support! – Adris Restaurant</p>";

    // PHPMailer setup
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'adrisquickybite@gmail.com'; // Your Gmail address
        $mail->Password = 'dxvz rvwx hzvz frfn';       // App password
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;

        $mail->setFrom('adrisquickybite@gmail.com', 'Adris Restaurant');
        $mail->addAddress($userEmail, $userFullName);
        $mail->isHTML(true);
        $mail->Subject = 'Your Order Receipt';
        $mail->Body = $emailBody;
        $mail->send();
    } catch (Exception $e) {
        echo "❌ Email error: {$mail->ErrorInfo}<br>";
    }

    $stmt->close();
    mysqli_close($conn);
    
    // Clear cart only on successful checkout
    unset($_SESSION['cart']);
    
    // Store order success information for display
    $orderSuccess = true;
    
    // Store order type and pickup details for the confirmation page
    $_SESSION['last_order_type'] = $orderType;
    if ($orderType === 'Take Out') {
        $_SESSION['last_pickup_time'] = $formattedTime;
        $_SESSION['last_pickup_date'] = $formattedDate;
    }
    

?>

    

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Order Confirmation - QuickyBite</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link rel="stylesheet" href="ustyles/ProcessCheckout.css">
    </head>
    <body>
        <nav class="side-nav">
            <div class="logo-box">QB</div>
            <a href="user_dashboard.php" class="nav-icon">
                <img src="uimages/house-blank.png" alt="Dashboard">
                <span class="nav-icon-text">Dashboard</span>
            </a>
            <a href="DisplayMenu.php" class="nav-icon">
                <img src="uimages/task-checklist.png" alt="Menu">
                <span class="nav-icon-text">Menu</span>
            </a>
            <a href="ViewCart.php" class="nav-icon">
                <img src="uimages/shopping-cart.png" alt="Cart">
                <span class="nav-icon-text">Cart</span>
            </a>
            <a href="SeatAvailability.php" class="nav-icon">
                <img src="uimages/chair.png" alt="Seats">
                <span class="nav-icon-text">Seat Availability</span>
            </a>
            <a href="MyAccount.php" class="nav-icon">
                <img src="uimages/user.png" alt="My Account">
                <span class="nav-icon-text">My Account</span>
            </a>
            <a href="../Login/logout.php" class="nav-icon">
                <img src="uimages/exit.png" alt="Logout">
                <span class="nav-icon-text">Log Out</span>
            </a>
        </nav>

        <div class="main-content">
            <h1>Order Confirmation</h1>
            
            <div class="container">
                <div class="confirmation-container">
                    <?php if ($orderSuccess): ?>
                        <div class="confirmation-success">
                            <h2>Order Placed Successfully!</h2>
                            <p>Your order has been placed and is being processed.</p>
                            <p>Please come and get your order 10 mins before <?= date('g:i A', strtotime($pickupTime)) ?>, the Dine-in/Pick-up Time.</p>
                        </div>
                        
                        <?php if (isset($payment) && $payment == 'GCash'): ?>
                            <div class="qr-code-container">
                                <h2>Payment QR Code</h2>
                                <img src='uimages/GcashQR.jpg' alt='Gcash QR Code for Payment'>
                                <div class="payment-details">
                                    <p>Please pay the Full amount of:</p>
                                    <div class="payment-amount">₱<?= number_format($totalAmount, 2) ?></div>
                                    <p class="qr-caption">Scan this QR code with your GCash app to complete your payment</p>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (isset($payment) && $payment == 'GCash'): ?>
                            <form action="Myaccount.php#order-history"method="post" style="text-align: center; margin-top: 20px;">
                                <label for="gcashRefNo" style="display: block; font-weight: bold; margin-bottom: 8px;">
                                    Enter GCash Reference Number
                                </label>
                                <input type="text" id="gcashRefNo" name="gcashRefNo" placeholder="GCash Ref No." required
                                    style="padding: 10px; width: 250px; border-radius: 5px; border: 1px solid #ccc; margin-bottom: 10px;">
                                <br>
                                <button type="submit" name="submitRefNo" class="btn">Submit Reference No</button>
                            </form>
                        <?php endif; ?>

                    <?php else: ?>
                        <div class="confirmation-error">
                            <h2>No Items in Cart</h2>
                            <p>Your cart is empty or there was an error processing your order.</p>
                        </div>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </body>
    </html>