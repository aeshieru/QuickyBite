<?php
require 'vendor/autoload.php'; // PHPMailer via Composer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "adris_ordertaking";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";
$messageType = "";
$showVerificationMessage = false; // Flag to control verification message display
$autoRedirect = false; // Flag to control auto-redirect

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data and sanitize inputs
    $fullName = trim(htmlspecialchars($_POST['fullName'] ?? ''));
    $username = trim(htmlspecialchars($_POST['username'] ?? ''));
    $email = trim(filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL));
    $phone = trim(htmlspecialchars($_POST['phone'] ?? ''));
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirmPassword'] ?? '';
    
    // Server-side validation
    if (empty($fullName) || empty($username) || empty($email) || empty($phone) || empty($password) || empty($confirmPassword)) {
        $message = "All fields are required";
        $messageType = "error";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Please enter a valid email address";
        $messageType = "error";
    } elseif (strlen($password) < 8) {
        $message = "Password must be at least 8 characters long";
        $messageType = "error";
    } elseif ($password !== $confirmPassword) {
        $message = "Passwords do not match";
        $messageType = "error";
    } else {
        // Check if username already exists
        $checkUser = $conn->prepare("SELECT * FROM users WHERE username = ?");
        $checkUser->bind_param("s", $username);
        $checkUser->execute();
        $result = $checkUser->get_result();
        
        if ($result->num_rows > 0) {
            $message = "Username already exists";
            $messageType = "error";
        } else {
            // Check if email already exists
            $checkEmail = $conn->prepare("SELECT * FROM users WHERE email = ?");
            $checkEmail->bind_param("s", $email);
            $checkEmail->execute();
            $result = $checkEmail->get_result();
            
            if ($result->num_rows > 0) {
                $message = "Email already exists";
                $messageType = "error";
            } else {
                // Generate verification token
                $verificationToken = bin2hex(random_bytes(32));
                
                // Hash password for security
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                
                // Insert new user with verification token
                $insertUser = $conn->prepare("INSERT INTO users (username, password, email, phone_number, full_name, user_type, account_activation_hash) VALUES (?, ?, ?, ?, ?, 'customer', ?)");
                $insertUser->bind_param("ssssss", $username, $hashedPassword, $email, $phone, $fullName, $verificationToken);
                
                if ($insertUser->execute()) {
                    // Send verification email using PHPMailer
                    $mail = new PHPMailer(true);
                    try {
                        $mail->isSMTP();
                        $mail->Host = 'smtp.gmail.com';
                        $mail->SMTPAuth = true;
                        $mail->Username = 'adrisquickybite@gmail.com'; // Your Gmail address
                        $mail->Password = 'dxvz rvwx hzvz frfn';       // App password
                        $mail->SMTPSecure = 'ssl';
                        $mail->Port = 465;

                        $mail->setFrom('adrisquickybite@gmail.com', 'QuickyBite');
                        $mail->addAddress($email, $fullName);
                        $mail->isHTML(true);
                        $mail->Subject = 'Verify Your QuickyBite Account';
                        // Fixed the URL
                        $verifyUrl = "http://localhost:3000/email_verification.php?token=$verificationToken";// Correct URL
                        $mail->Body = "Hi $fullName,<br><br>Please verify your email by clicking the link below:<br><a href='$verifyUrl'>$verifyUrl</a><br><br>Thank you!";

                        $mail->send();
                        $message = "Account created! Please verify your email before logging in.";
                        $messageType = "success";
                        $showVerificationMessage = true; // Set flag to show verification instructions
                        $autoRedirect = true; // Set flag to auto-redirect after verification message is displayed
                    } catch (Exception $e) {
                        $message = "Account created, but email could not be sent. Error: {$mail->ErrorInfo}";
                        $messageType = "error";
                    }
                } else {
                    $message = "Error creating account: " . $conn->error;
                    $messageType = "error";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - QuickyBite</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="styles/signup.css">
    <style>
        /* Additional styles for verification message */
        .verification-message {
            background-color:rgb(7, 7, 7);
            border-left: 4px solid #1877f2;
            padding: 15px;
            margin: 20px 0;
            border-radius: 4px;
        }
        
        .verification-message h3 {
            margin-top: 0;
            color: #1877f2;
        }
        
        .verification-message ol {
            margin-left: 20px;
            line-height: 1.5;
        }
        
        .verification-message .email-icon {
            font-size: 28px;
            color: #1877f2;
            margin-right: 10px;
            vertical-align: middle;
        }

        .countdown {
            font-weight: bold;
            color: #1877f2;
        }
    </style>
    <?php if ($autoRedirect): ?>
    <script>
        // Auto-redirect to login after showing verification message for 5 seconds
        let secondsLeft = 5;
        
        window.onload = function() {
            const countdownElement = document.getElementById('countdown');
            
            const countdownInterval = setInterval(function() {
                secondsLeft -= 1;
                countdownElement.textContent = secondsLeft;
                
                if (secondsLeft <= 0) {
                    clearInterval(countdownInterval);
                    window.location.href = 'logins.php';
                }
            }, 1000);
        }
    </script>
    <?php endif; ?>
</head>
<body>
    <!-- Background animation elements -->
    <div class="bg-animation">
        <div class="bg-bubble"></div>
        <div class="bg-bubble"></div>
        <div class="bg-bubble"></div>
        <div class="bg-bubble"></div>
    </div>
    
    <div class="container">
        <h1>SIGN UP</h1>
        <p class="tagline">Create your QuickyBite account and start ordering today!</p>
        
        <?php if (!empty($message)): ?>
            <div class="message <?php echo $messageType; ?>">
                <i class="fas fa-<?php echo $messageType === 'error' ? 'exclamation-circle' : 'check-circle'; ?>"></i>
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($showVerificationMessage): ?>
            <div class="verification-message">
                <h3><i class="fas fa-envelope email-icon"></i> Check Your Email</h3>
                <p>We've sent a verification link to <strong><?php echo htmlspecialchars($email); ?></strong></p>
                <ol>
                    <li>Open your email inbox</li>
                    <li>Look for an email from QuickyBite</li>
                    <li>Click the verification link in the email</li>
                    <li>Once verified, you can log in to your account</li>
                </ol>
                <p><strong>Note:</strong> If you don't see the email, please check your spam folder.</p>
                <?php if ($autoRedirect): ?>
                <p>You will be redirected to login page in <span id="countdown">5</span> seconds...</p>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <form id="signupForm" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="form-group">
                    <label for="fullName">Full Name</label>
                    <input type="text" id="fullName" name="fullName" placeholder="Enter your full name" value="<?php echo isset($_POST['fullName']) ? htmlspecialchars($_POST['fullName']) : ''; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" placeholder="Choose a username" value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" placeholder="Enter your email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" name="phone" placeholder="Enter your phone number" value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="password-container">
                        <input type="password" id="password" name="password" placeholder="Create a password" required>
                        <i class="toggle-password fas fa-eye"></i>
                    </div>
                    <div class="password-strength"></div>
                    <div class="strength-label">Weak</div>
                </div>
                
                <div class="form-group">
                    <label for="confirmPassword">Confirm Password</label>
                    <div class="password-container">
                        <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm your password" required>
                        <i class="toggle-password fas fa-eye"></i>
                    </div>
                </div>
                
                <div class="agreement">
                    <input type="checkbox" id="agreement" name="agreement" required>
                    <label for="agreement">I agree to the <a href="#">Terms & Conditions</a> and <a href="#">Privacy Policy</a></label>
                </div>
                
                <button type="submit" class="btn" id="submitBtn">
                    <i class="fas fa-user-plus"></i>
                    CREATE ACCOUNT
                </button>
            </form>
        <?php endif; ?>
        
        <div class="login-link">
            Already have an account? <a href="logins.php">Login</a>
        </div>
    </div>

    <script src="js/signup.js"></script>
</body>
</html>