<?php
session_start();
$host = "localhost";
$username = "root"; 
$password = ""; 
$database = "adris_ordertaking"; 

// Connect to database
$conn = mysqli_connect($host, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Function to sanitize input
function sanitize($conn, $data) {
    return mysqli_real_escape_string($conn, trim($data));
}

// Get all unique user types for the filter dropdown
$userTypesSql = "SELECT DISTINCT user_type FROM users ORDER BY user_type";
$userTypesResult = mysqli_query($conn, $userTypesSql);
$userTypes = [];
while ($row = mysqli_fetch_assoc($userTypesResult)) {
    $userTypes[] = $row['user_type'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer List</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
          font-family: Arial, sans-serif;
          background-color: #000000;
          background-image: 
            radial-gradient(circle at 20% 30%, rgba(248, 120, 160, 0.15) 0%, transparent 50%),
            radial-gradient(circle at 80% 70%, rgba(248, 120, 160, 0.1) 0%, transparent 50%);
          margin: 0;
          padding: 0;
          color: #ffffff;
          display: flex;
          min-height: 100vh;
        }
        
        .side-nav {
          width: 80px;
          height: 100vh;
          background: rgba(17, 17, 17, 0.7);
          backdrop-filter: blur(10px);
          -webkit-backdrop-filter: blur(10px);
          display: flex;
          flex-direction: column;
          align-items: center;
          padding-top: 20px;
          position: fixed;
          border-right: 1px solid rgba(255, 255, 255, 0.1);
          box-shadow: 0 4px 30px rgba(0, 0, 0, 0.2);
          z-index: 10;
          transition: width 0.3s ease;
          overflow: hidden;
        }
        
        .side-nav:hover {
          width: 200px;
          align-items: flex-start;
          padding-left: 20px;
        }
        
        .logo-box {
          background-color: #f8e8e8;
          color: #000;
          padding: 8px 12px;
          margin-bottom: 30px;
          font-weight: bold;
          font-size: 18px;
          border-radius: 4px;
          box-shadow: 0 0 15px rgba(248, 120, 160, 0.5);
          align-self: center;
        }
        
        .side-nav:hover .logo-box {
          width: 80%;
          text-align: center;
          padding: 8px 0;
        }
        
        .nav-icon {
          width: 24px;
          height: 24px;
          margin: 15px 0;
          display: flex;
          align-items: center;
          color: #fff;
          opacity: 0.7;
          transition: all 0.3s;
          text-decoration: none;
          position: relative;
        }
        
        .nav-icon-text {
          white-space: nowrap;
          margin-left: 15px;
          opacity: 0;
          transition: opacity 0.3s ease;
          color: #ffffff;
          font-weight: 500;
        }
        
        .side-nav:hover .nav-icon {
          width: 90%;
          justify-content: flex-start;
        }
        
        .side-nav:hover .nav-icon-text {
          opacity: 1;
        }
        
        .nav-icon:hover {
          opacity: 1;
          text-shadow: 0 0 10px rgba(248, 232, 232, 0.8);
        }
        
        .nav-icon.active {
          opacity: 1;
          border-left: 2px solid #f8e8e8;
          padding-left: 10px;
          text-shadow: 0 0 10px rgba(248, 232, 232, 0.8);
        }
        
        .nav-icon img {
          width: 24px;
          height: 24px;
        }
        
        .main-content {
          flex: 1;
          margin-left: 80px;
          width: calc(100% - 80px);
          padding: 20px 0;
          transition: margin-left 0.3s ease, width 0.3s ease;
        }
        
        h1 {
          color: #ffffff;
          margin-bottom: 10px;
          text-align: center;
          padding-top: 20px;
          text-shadow: 0 0 10px rgba(248, 120, 160, 0.5);
        }
        
        .container {
          max-width: 1200px;
          margin: 0 auto;
          padding: 0 20px;
        }
        
        .nav-tabs {
          display: flex;
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
          margin-bottom: 20px;
        }
        
        .nav-tab {
          padding: 12px 20px;
          color: #ffffff;
          text-decoration: none;
          margin-right: 5px;
          border-bottom: 3px solid transparent;
          font-weight: bold;
          transition: all 0.3s;
        }
        
        .nav-tab.active {
          border-bottom: 3px solid #f8a8c8;
          color: #f8a8c8;
        }
        
        .nav-tab:hover {
          background-color: rgba(248, 120, 160, 0.1);
        }
        
        /* Customer list specific styles */
        .card {
            background: rgba(17, 17, 17, 0.7);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            margin-top: 20px;
        }
        
        .card-header {
            background: rgba(248, 120, 160, 0.2);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            color: #f8e8e8;
            text-shadow: 0 0 10px rgba(248, 120, 160, 0.5);
        }
        
        .table {
            color: #ffffff;
        }
        
        .table th {
            background: rgba(248, 120, 160, 0.1);
            border-color: rgba(255, 255, 255, 0.1);
            color: #f8a8c8;
        }
        
        .table td {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .table-hover tbody tr:hover {
            background: rgba(248, 120, 160, 0.05);
        }
        
        .btn-primary {
            background-color: rgba(248, 120, 160, 0.7);
            border-color: rgba(248, 120, 160, 0.3);
        }
        
        .btn-primary:hover {
            background-color: rgba(248, 120, 160, 0.9);
            border-color: rgba(248, 120, 160, 0.5);
        }
        
        .btn-info {
            background-color: rgba(120, 160, 248, 0.7);
            border-color: rgba(120, 160, 248, 0.3);
            color: white;
        }
        
        .btn-info:hover {
            background-color: rgba(120, 160, 248, 0.9);
            border-color: rgba(120, 160, 248, 0.5);
            color: white;
        }
        
        .btn-danger {
            background-color: rgba(248, 100, 100, 0.7);
            border-color: rgba(248, 100, 100, 0.3);
        }
        
        .btn-danger:hover {
            background-color: rgba(248, 100, 100, 0.9);
            border-color: rgba(248, 100, 100, 0.5);
        }
        
        #searchInput {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: white;
            transition: all 0.3s;
        }
        
        #searchInput:focus {
            border-color: rgba(248, 120, 160, 0.7);
            box-shadow: 0 0 10px rgba(248, 120, 160, 0.3);
            background: rgba(255, 255, 255, 0.15);
        }
        
        #searchInput::placeholder {
            color: rgba(255, 255, 255, 0.5);
        }
        
        .input-group-text {
            background: rgba(248, 120, 160, 0.3);
            border-color: rgba(255, 255, 255, 0.2);
            color: white;
        }
        
        .form-select {
            background-color: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: white;
        }
        
        .form-select:focus {
            border-color: rgba(248, 120, 160, 0.7);
            box-shadow: 0 0 10px rgba(248, 120, 160, 0.3);
            background: rgba(255, 255, 255, 0.15);
        }
        
        .form-select option {
            background-color: #212121;
            color: white;
        }
        
        .modal-content {
            background: rgba(17, 17, 17, 0.95);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: white;
        }
        
        .modal-header {
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .modal-footer {
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .status-pending { color: #ffc107; }
        .status-completed { color: #4caf50; }
        .status-cancelled { color: #f44336; }
    </style>
</head>
<body>
    <!-- Side Navigation -->
    <nav class="side-nav">
        <div class="logo-box">QB</div>
        <a href="get-user-orders.php" class="nav-icon active">
          <img src="aimages/user-gear.png" alt="Users">
          <span class="nav-icon-text">Manage Users</span>
        </a>
        <a href="ManageMenu.php" class="nav-icon">
          <img src="aimages/task-checklist.png" alt="Menu">
          <span class="nav-icon-text">Manage Menu</span>
        </a>
        <a href="ManageSeats.php" class="nav-icon">
          <img src="aimages/chair.png" alt="Seats">
          <span class="nav-icon-text">Manage Seats</span>
        </a>
        <a href="reports.php" class="nav-icon">
            <img src="aimages/user-gear.png" alt="Reports">
            <span class="nav-icon-text">Reports</span>
        </a>
        <a href="../Login/logout.php" class="nav-icon">
          <img src="aimages/exit.png" alt="Logout">
          <span class="nav-icon-text">Log Out</span>
        </a>
    </nav>

    <!-- Main Content Area -->
    <div class="main-content">
        <h1>Customer Management</h1>
        
        <div class="container">
            <div class="nav-tabs">
                <a href="#" class="nav-tab active">Customers</a>
               
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h3 class="mb-0">Customer List</h3>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <div class="input-group">
                                <span class="input-group-text">🔍</span>
                                <input type="text" id="searchInput" class="form-control" placeholder="Search by name, email, username or phone">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="input-group" style="max-width: 400px; float: right;">
                                <label class="input-group-text" for="userTypeFilter">Filter by Type:</label>
                                <select class="form-select" id="userTypeFilter">
                                    <option value="all">All Users</option>
                                    <?php foreach ($userTypes as $type): ?>
                                        <option value="<?php echo htmlspecialchars($type); ?>">
                                            <?php echo htmlspecialchars($type); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="customerTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Full Name</th>
                                    <th>User Type</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="customerTableBody">
                                <?php 
                                // Initial query to fetch all users
                                $userSql = "SELECT user_id, username, email, phone_number, full_name, user_type FROM users ORDER BY user_id";
                                $userResult = mysqli_query($conn, $userSql);
                                
                                if ($userResult && mysqli_num_rows($userResult) > 0): 
                                    while ($user = mysqli_fetch_assoc($userResult)): 
                                ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($user['user_id']); ?></td>
                                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                                        <td><?php echo htmlspecialchars($user['phone_number']); ?></td>
                                        <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                        <td><?php echo htmlspecialchars($user['user_type']); ?></td>
                                        <td>
                                            <button class="btn btn-primary btn-sm" onclick="viewOrders(<?php echo $user['user_id']; ?>, '<?php echo htmlspecialchars($user['full_name']); ?>')">
                                                View Orders
                                            </button>
                                            <a href="edit_user.php?id=<?php echo $user['user_id']; ?>" class="btn btn-info btn-sm">Edit</a>
                                            <button class="btn btn-danger btn-sm" onclick="deleteUser(<?php echo $user['user_id']; ?>)">Delete</button>
                                        </td>
                                    </tr>
                                <?php 
                                    endwhile; 
                                else: 
                                ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No customers found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal for Order History -->
    <div class="modal fade" id="orderHistoryModal" tabindex="-1" aria-labelledby="orderHistoryModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="orderHistoryModalLabel">Order History</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="orderHistoryContent">
                    <div class="text-center">
                        <div class="spinner-border text-light" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <p>Loading order history...</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
        // Function to view order history
        function viewOrders(userId, userName) {
            // Show modal
            const orderModal = new bootstrap.Modal(document.getElementById('orderHistoryModal'));
            orderModal.show();
            
            // Update modal title
            document.getElementById('orderHistoryModalLabel').textContent = "Order History - " + userName;
            
            // Fetch order history using AJAX
            fetch('getorderhistory.php?user_id=' + userId)
                .then(response => response.text())
                .then(data => {
                    document.getElementById('orderHistoryContent').innerHTML = data;
                    
                    // Initialize event handlers for view details buttons after content is loaded
                    $(document).ready(function() {
                        // Use event delegation for the dynamically loaded content
                        $(document).on('click', '.view-details', function() {
                            var orderId = $(this).data('orderid');
                            $('#orderDetails_' + orderId).toggle();
                        });
                    });
                })
                .catch(error => {
                    document.getElementById('orderHistoryContent').innerHTML = 
                        '<div class="alert alert-danger">Error loading order history: ' + error + '</div>';
                });
        }
        
        // Function to delete user
        function deleteUser(userId) {
            if (confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
                window.location.href = 'delete_user.php?id=' + userId;
            }
        }

        // Live search and filter functionality
        $(document).ready(function() {
            $('#searchInput, #userTypeFilter').on('input change', function() {
                const searchTerm = $('#searchInput').val().toLowerCase().trim();
                const userType = $('#userTypeFilter').val();

                // Filter table rows
                $('#customerTableBody tr').each(function() {
                    const row = $(this);
                    const username = row.find('td:nth-child(2)').text().toLowerCase();
                    const email = row.find('td:nth-child(3)').text().toLowerCase();
                    const phone = row.find('td:nth-child(4)').text().toLowerCase();
                    const fullName = row.find('td:nth-child(5)').text().toLowerCase();
                    const rowUserType = row.find('td:nth-child(6)').text().toLowerCase();

                    // Check search term
                    const matchesSearch = searchTerm === '' || 
                        username.includes(searchTerm) || 
                        email.includes(searchTerm) || 
                        phone.includes(searchTerm) || 
                        fullName.includes(searchTerm);

                    // Check user type
                    const matchesUserType = userType === 'all' || 
                        rowUserType === userType.toLowerCase();

                    // Show or hide row based on both conditions
                    row.toggle(matchesSearch && matchesUserType);
                });

                // Update "No customers found" message
                const visibleRows = $('#customerTableBody tr:visible').length;
                if (visibleRows === 0) {
                    if ($('.no-results').length === 0) {
                        $('#customerTableBody').append(
                            '<tr class="no-results"><td colspan="7" class="text-center">No customers found</td></tr>'
                        );
                    }
                } else {
                    $('.no-results').remove();
                }
            });
        });
    </script>
</body>
</html>
<?php
// Close the database connection
mysqli_close($conn);
?>