<?php
$username = "root";
$password = "";
$database = "adris_ordertaking";
$conn = mysqli_connect("localhost", $username, $password, $database);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
// Delete menu item
if (isset($_POST['delete'])) {
    $id = intval($_POST['id']); // Add validation
    $query = "DELETE FROM menuitems WHERE FoodID=$id";
    if (mysqli_query($conn, $query)) {
        $deleteSuccess = true;
    } else {
        $deleteError = mysqli_error($conn);
    }
}
// Add new menu item
if (isset($_POST['submit'])) {
    $FoodName = mysqli_real_escape_string($conn, $_POST['FoodName']);
    $FoodPrice = mysqli_real_escape_string($conn, $_POST['FoodPrice']);
    $Stock = mysqli_real_escape_string($conn, $_POST['Stock']);
    if (isset($_FILES['FoodImage']) && $_FILES['FoodImage']['error'] == 0) {
        $imageData = file_get_contents($_FILES['FoodImage']['tmp_name']);
        $imageData = mysqli_real_escape_string($conn, $imageData);
        $query = "INSERT INTO menuitems (FoodName, FoodPrice, Stock, FoodImage)
                  VALUES ('$FoodName', '$FoodPrice', '$Stock', '$imageData')";
        if (mysqli_query($conn, $query)) {
            $addSuccess = true;
        } else {
            $addError = mysqli_error($conn);
        }
    } else {
        $imageError = "No image uploaded or error occurred. Error code: " . $_FILES['FoodImage']['error'];
    }
}
// Update menu item
if (isset($_POST['update'])) {
    $id = intval($_POST['id']); // Add validation
    $FoodName = mysqli_real_escape_string($conn, $_POST['FoodName']);
    $FoodPrice = mysqli_real_escape_string($conn, $_POST['FoodPrice']);
    $Stock = mysqli_real_escape_string($conn, $_POST['Stock']);
    // Check if a new image was uploaded
    if (isset($_FILES['FoodImage']) && $_FILES['FoodImage']['error'] == 0) {
        $imageData = file_get_contents($_FILES['FoodImage']['tmp_name']);
        $imageData = mysqli_real_escape_string($conn, $imageData);
        
        $query = "UPDATE menuitems SET 
                  FoodName='$FoodName', 
                  FoodPrice='$FoodPrice', 
                  Stock='$Stock',
                  FoodImage='$imageData'
                  WHERE FoodID=$id";
    } else {
        $query = "UPDATE menuitems SET 
                  FoodName='$FoodName', 
                  FoodPrice='$FoodPrice', 
                  Stock='$Stock' 
                  WHERE FoodID=$id";
    }
    
    if (mysqli_query($conn, $query)) {
        $updateSuccess = true;
    } else {
        $updateError = mysqli_error($conn);
    }
}
$result = mysqli_query($conn, "SELECT * FROM menuitems");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Menu Items</title>
  <style>
          body {
      font-family: Arial, sans-serif;
      background-color: #000000;
      background-image: 
        radial-gradient(circle at 20% 30%, rgba(248, 120, 160, 0.15) 0%, transparent 50%),
        radial-gradient(circle at 80% 70%, rgba(248, 120, 160, 0.1) 0%, transparent 50%);
      margin: 0;
      padding: 0;
      color: #ffffff;
      display: flex;
      min-height: 100vh;
    }
    
    .side-nav {
      width: 80px;
      height: 100vh;
      background: rgba(17, 17, 17, 0.7);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      display: flex;
      flex-direction: column;
      align-items: center;
      padding-top: 20px;
      position: fixed;
      border-right: 1px solid rgba(255, 255, 255, 0.1);
      box-shadow: 0 4px 30px rgba(0, 0, 0, 0.2);
      z-index: 10;
      transition: width 0.3s ease;
      overflow: hidden;
    }
    
    .side-nav:hover {
      width: 200px;
      align-items: flex-start;
      padding-left: 20px;
    }
    
    .logo-box {
      background-color: #f8e8e8;
      color: #000;
      padding: 8px 12px;
      margin-bottom: 30px;
      font-weight: bold;
      font-size: 18px;
      border-radius: 4px;
      box-shadow: 0 0 15px rgba(248, 120, 160, 0.5);
      align-self: center;
    }
    
    .side-nav:hover .logo-box {
      width: 80%;
      text-align: center;
      padding: 8px 0;
    }
    
    .nav-icon {
      width: 24px;
      height: 24px;
      margin: 15px 0;
      display: flex;
      align-items: center;
      color: #fff;
      opacity: 0.7;
      transition: all 0.3s;
      text-decoration: none;
      position: relative;
    }
    
    .nav-icon-text {
      white-space: nowrap;
      margin-left: 15px;
      opacity: 0;
      transition: opacity 0.3s ease;
      color: #ffffff;
      font-weight: 500;
    }
    
    .side-nav:hover .nav-icon {
      width: 90%;
      justify-content: flex-start;
    }
    
    .side-nav:hover .nav-icon-text {
      opacity: 1;
    }
    
    .nav-icon:hover {
      opacity: 1;
      text-shadow: 0 0 10px rgba(248, 232, 232, 0.8);
    }
    
    .nav-icon.active {
      opacity: 1;
      border-left: 2px solid #f8e8e8;
      padding-left: 10px;
      text-shadow: 0 0 10px rgba(248, 232, 232, 0.8);
    }
    
    .nav-icon img {
      width: 24px;
      height: 24px;
    }
    
    .main-content {
      flex: 1;
      margin-left: 80px;
      width: calc(100% - 80px);
      padding: 20px 0;
      transition: margin-left 0.3s ease, width 0.3s ease;
    }
    
    h1 {
      color: #ffffff;
      margin-bottom: 10px;
      text-align: center;
      padding-top: 20px;
      text-shadow: 0 0 10px rgba(248, 120, 160, 0.5);
    }
    
    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 20px;
    }

    /* Menu table styling */
    .menu-table {
      width: 100%;
      border-collapse: collapse;
      background: rgba(248, 232, 232, 0.1);
      border-radius: 10px;
      overflow: hidden;
      margin-bottom: 30px;
    }

    .menu-table th {
      background: rgba(248, 120, 160, 0.2);
      color: #ffffff;
      padding: 12px 15px;
      text-align: left;
      font-weight: bold;
    }

    .menu-table td {
      padding: 12px 15px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    }

    .menu-table tr:last-child td {
      border-bottom: none;
    }

    .menu-table tr:hover {
      background: rgba(248, 120, 160, 0.1);
    }

    .menu-table input[type="text"],
    .menu-table input[type="number"] {
      background: rgba(0, 0, 0, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.2);
      color: #ffffff;
      padding: 8px;
      border-radius: 4px;
      width: 100%;
    }

    .menu-table img {
      border-radius: 6px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
    }

    /* Form styling */
    .add-form {
      background: rgba(248, 232, 232, 0.1);
      border-radius: 10px;
      padding: 20px;
      margin-top: 30px;
      border: 1px solid rgba(255, 255, 255, 0.08);
    }

    .form-group {
      margin-bottom: 15px;
    }

    .form-group label {
      display: block;
      margin-bottom: 5px;
      font-weight: 500;
    }

    .form-control {
      width: 100%;
      padding: 10px;
      background: rgba(0, 0, 0, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 4px;
      color: #ffffff;
      font-size: 16px;
    }

    .btn {
      padding: 10px 15px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-weight: bold;
      transition: all 0.3s ease;
    }

    .btn-primary {
      background-color: rgba(248, 120, 160, 0.8);
      color: white;
    }

    .btn-primary:hover {
      background-color: rgba(248, 120, 160, 1);
      box-shadow: 0 0 15px rgba(248, 120, 160, 0.5);
    }

    .btn-danger {
      background-color: rgba(220, 53, 69, 0.8);
      color: white;
    }

    .btn-danger:hover {
      background-color: rgba(220, 53, 69, 1);
      box-shadow: 0 0 15px rgba(220, 53, 69, 0.5);
    }

    .btn-success {
      background-color: rgba(40, 167, 69, 0.8);
      color: white;
    }

    .btn-success:hover {
      background-color: rgba(40, 167, 69, 1);
      box-shadow: 0 0 15px rgba(40, 167, 69, 0.5);
    }

    /* Alert messages */
    .alert {
      padding: 15px;
      margin-bottom: 20px;
      border-radius: 5px;
      font-weight: 500;
    }

    .alert-success {
      background: rgba(40, 167, 69, 0.2);
      border: 1px solid rgba(40, 167, 69, 0.5);
    }

    .alert-danger {
      background: rgba(220, 53, 69, 0.2);
      border: 1px solid rgba(220, 53, 69, 0.5);
    }

    /* Delete Modal styling */
    .modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.7);
      z-index: 1000;
      justify-content: center;
      align-items: center;
    }



    .close {
      color: #ffffff;
      font-size: 24px;
      font-weight: bold;
      cursor: pointer;
      background: none;
      border: none;
    }



    /* Navigation tabs */
    .nav-tabs {
      display: flex;
      margin-bottom: 20px;
      gap: 15px;
    }
    
    .nav-tab {
      padding: 10px 20px;
      color: #ffffff;
      text-decoration: none;
      font-weight: bold;
      transition: all 0.3s;
      background-color: rgba(248, 120, 160, 0.8);
      border-radius: 6px;
      text-align: center;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
      border: 1px solid rgba(248, 120, 160, 0.6);
    }
    
    .nav-tab.active {
      background-color: rgba(248, 120, 160, 0.9);
      box-shadow: 0 0 10px rgba(248, 120, 160, 0.5);
    }
    
    .nav-tab:hover {
      background-color: rgba(248, 120, 160, 1);
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(248, 120, 160, 0.4);
    }
    
    .add-item-btn {
      display: flex;
      align-items: center;
    }  
    /* Modal Styles */
    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0,0,0,0.5);
      justify-content: center;
      align-items: center;
    }
    
    .modal-content {
      background-color: white;
      border-radius: 5px;
      width: 90%;
      max-width: 500px;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    
    .modal-header {
      padding: 20px;
      border-bottom: 1px solid #ddd;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .modal-header h3 {
      margin: 0;
      color: #2c3e50;
    }
    
    .modal-header button {
      background: none;
      border: none;
      font-size: 24px;
      cursor: pointer;
      color: #999;
    }
    
    .modal-body {
      padding: 20px;
    }
    
    .modal-footer {
      padding: 20px;
      border-top: 1px solid #ddd;
      display: flex;
      justify-content: flex-end;
      gap: 10px;
    }
  </style>
</head>
<body>
    <nav class="side-nav">
        <div class="logo-box">QB</div>
        <a href="get-user-orders.php" class="nav-icon">
          <img src="aimages/user-gear.png" alt="Users">
          <span class="nav-icon-text">Manage Users</span>
        </a>
        <a href="ManageMenu.php" class="nav-icon active">
          <img src="aimages/task-checklist.png" alt="Menu">
          <span class="nav-icon-text">Manage Menu</span>
        </a>
        <a href="ManageSeats.php" class="nav-icon">
          <img src="aimages/chair.png" alt="Seats">
          <span class="nav-icon-text">Manage Seats</span>
        </a>
        <a href="reports.php" class="nav-icon">
            <img src="aimages/user-gear.png" alt="Reports">
            <span class="nav-icon-text">Reports</span>
        </a>
        <a href="../Login/logout.php" class="nav-icon">
          <img src="aimages/exit.png" alt="Logout">
          <span class="nav-icon-text">Log Out</span>
        </a>
    </nav>
  
  <div class="main-content">
    <div class="container">
      <h1>Manage Menu Items</h1>
      
      <div class="nav-tabs">
        <a href="#" class="nav-tab active">Food Items</a>
        <a href="#addMenuForm" class="nav-tab add-item-btn">+ Add Item</a>
      </div>
      
      <?php if(isset($addSuccess) && $addSuccess): ?>
        <div class="alert alert-success">Menu item added successfully!</div>
      <?php endif; ?>
      
      <?php if(isset($updateSuccess) && $updateSuccess): ?>
        <div class="alert alert-success">Menu item updated successfully!</div>
      <?php endif; ?>
      
      <?php if(isset($deleteSuccess) && $deleteSuccess): ?>
        <div class="alert alert-success">Menu item deleted successfully!</div>
      <?php endif; ?>
      
      <?php if(isset($addError)): ?>
        <div class="alert alert-danger">Error adding menu item: <?php echo $addError; ?></div>
      <?php endif; ?>
      
      <?php if(isset($updateError)): ?>
        <div class="alert alert-danger">Error updating menu item: <?php echo $updateError; ?></div>
      <?php endif; ?>
      
      <?php if(isset($deleteError)): ?>
        <div class="alert alert-danger">Error deleting menu item: <?php echo $deleteError; ?></div>
      <?php endif; ?>
      
      <?php if(isset($imageError)): ?>
        <div class="alert alert-danger"><?php echo $imageError; ?></div>
      <?php endif; ?>
      
      <!-- Menu Items Table -->
      <table class="menu-table">
        <thead>
          <tr>
            <th>Food Name</th>
            <th>Food Price</th>
            <th>Stock</th>
            <th>Image</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($row = mysqli_fetch_assoc($result)): ?>
            <tr>
              <form method="post" enctype="multipart/form-data">
                <td>
                  <input type="text" name="FoodName" value="<?php echo htmlspecialchars($row['FoodName']); ?>" required>
                </td>
                <td>
                  <input type="number" name="FoodPrice" value="<?php echo htmlspecialchars($row['FoodPrice']); ?>" step="0.01" required>
                </td>
                <td>
                  <input type="number" name="Stock" value="<?php echo htmlspecialchars($row['Stock']); ?>" required>
                </td>
                <td>
                  <img src="data:image/jpeg;base64,<?php echo base64_encode($row['FoodImage']); ?>" width="100" alt="<?php echo htmlspecialchars($row['FoodName']); ?>">
                  <input type="file" name="FoodImage" accept="image/*">
                </td>
                <td>
                  <input type="hidden" name="id" value="<?php echo $row['FoodID']; ?>">
                  <button type="submit" name="update" class="btn btn-primary">Update</button>
                  <button type="button" class="btn btn-danger" onclick="openDeleteModal(<?php echo $row['FoodID']; ?>, '<?php echo htmlspecialchars($row['FoodName'], ENT_QUOTES); ?>')">Delete</button>
                </td>
              </form>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
      
      <!-- Add New Menu Item Form -->
      <div id="addMenuForm" class="add-form">
        <h2>Add New Menu Item</h2>
        <form action="" method="post" enctype="multipart/form-data">
          <div class="form-group">
            <label for="FoodName">Food Name:</label>
            <input type="text" id="FoodName" name="FoodName" class="form-control" required>
          </div>
          
          <div class="form-group">
            <label for="FoodPrice">Food Price:</label>
            <input type="number" id="FoodPrice" name="FoodPrice" class="form-control" step="0.01" required>
          </div>
          
          <div class="form-group">
            <label for="Stock">Stock:</label>
            <input type="number" id="Stock" name="Stock" class="form-control" required>
          </div>
          
          <div class="form-group">
            <label for="FoodImage">Food Image:</label>
            <input type="file" id="FoodImage" name="FoodImage" class="form-control" accept="image/*" required>
          </div>
          
          <button type="submit" name="submit" class="btn btn-success">Add Menu Item</button>
        </form>
      </div>
    </div>
  </div>
  
  <!-- Delete Confirmation Modal -->
  <div id="deleteModal" class="modal">
    <div class="modal-content">
      <div class="modal-header">
        <h3>Confirm Deletion</h3>
        <button type="button" onclick="closeDeleteModal()">&times;</button>
      </div>
      <form method="post" id="deleteForm">
        <div class="modal-body">
          <p>Are you sure you want to delete <strong><span id="deleteItemName"></span></strong>?</p>
          <input type="hidden" name="id" id="deleteItemId">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn" onclick="closeDeleteModal()">Cancel</button>
          <button type="submit" name="delete" class="btn btn-danger">Delete</button>
        </div>
      </form>
    </div>
  </div>
  
  <script>
    // Smooth scroll to add menu form when clicking the Add Item button
    document.addEventListener('DOMContentLoaded', function() {
      const addItemBtn = document.querySelector('.add-item-btn');
      if (addItemBtn) {
        addItemBtn.addEventListener('click', function(e) {
          e.preventDefault();
          const addMenuForm = document.getElementById('addMenuForm');
          if (addMenuForm) {
            addMenuForm.scrollIntoView({ behavior: 'smooth' });
          }
        });
      }
    });
    
    // Delete modal functions
    function openDeleteModal(id, name) {
      console.log('Opening delete modal for:', id, name); // Debug log
      document.getElementById('deleteItemId').value = id;
      document.getElementById('deleteItemName').textContent = name;
      document.getElementById('deleteModal').style.display = 'flex';
    }
    
    function closeDeleteModal() {
      document.getElementById('deleteModal').style.display = 'none';
    }
    
    // Close modal when clicking outside
    window.onclick = function(event) {
      const modal = document.getElementById('deleteModal');
      if (event.target === modal) {
        closeDeleteModal();
      }
    }
    
    // Close modal with Escape key
    document.addEventListener('keydown', function(event) {
      if (event.key === 'Escape') {
        closeDeleteModal();
      }
    });
  </script>
</body>
</html>