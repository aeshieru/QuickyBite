<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuickyBite - Order Ahead, Skip the Line</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap">
    <link rel="stylesheet" href="styles/homepage.css">
</head>
<body>
    

    
    <!-- Background Animation -->
    <div class="bg-animation" id="bg-animation"></div>
    
    <!-- Header -->
    <header id="header">
        <div class="container header-container">
            <a href="#" class="logo">
                <span><span class="animated-letter">Q</span><span class="animated-letter">B</span></span> QuickyBite
            </a>
            <nav>
                <ul>        
                    <li><a href="#home" class="nav-link">Home</a></li>
                    <li><a href="#how-it-works" class="nav-link">How It Works</a></li>
                    <li><a href="#about" class="nav-link">About Us</a></li>
                    <li><a href="#menu" class="nav-link">Menu</a></li>
                    <li><a href="#contact" class="nav-link">Contact</a></li>
                </ul>
            </nav>
            <div class="auth-container">
                <div class="auth-buttons">
                    <a href="logins.php" class="login-button-link">
                        <button class="auth-button login-button">Log In</button>
                    </a>
                    <a href="signup.php" class="signup-button-link">
                        <button class="auth-button signup-button">Sign Up</button>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section id="home" class="hero-section">
        <div class="container hero-container">
            <div class="hero-content">
                <h1 class="hero-title">Order Ahead, <span>Skip the Line</span></h1>
                <p class="hero-subtitle">Delicious food, ready when you are. QuickyBite helps you order from your favorite restaurants and have your meal ready for pickup exactly when you need it.</p>
                <div class="hero-buttons">
                    <a href="#menu" class="hero-btn primary-btn">
                        <div class="btn-inner">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="12" cy="12" r="10"></circle>
                                <path d="M12 8l4 4-4 4"></path>
                                <path d="M8 12h8"></path>
                            </svg>
                            <span>View Menu</span>
                        </div>
                    </a>
                    <a href="signup.php" class="hero-btn secondary-btn">
                        <div class="btn-inner">
                            <span>Get Started</span>
                        </div>
                    </a>
                </div>
            </div>
            <div class="hero-image">
                <div class="hero-image-container">
                    <img src="1hero.jpg" alt="QuickyBite Food Example" class="main-image">
                    <div class="floating-element order-now">
                        <div class="floating-inner">
                            <span class="highlight">Order</span>
                            <span>Now</span>
                        </div>
                    </div>
                    <div class="floating-element ratings">
                        <div class="floating-inner">
                            <div class="stars">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="#d4af37" stroke="#d4af37" stroke-width="1">
                                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                                </svg>
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="#d4af37" stroke="#d4af37" stroke-width="1">
                                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                                </svg>
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="#d4af37" stroke="#d4af37" stroke-width="1">
                                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                                </svg>
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="#d4af37" stroke="#d4af37" stroke-width="1">
                                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                                </svg>
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="#d4af37" stroke="#d4af37" stroke-width="1">
                                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                                </svg>
                            </div>
                            <span class="rating-text">Sobrang Sarap</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="hero-bg">
            <div class="circle circle-1"></div>
            <div class="circle circle-2"></div>
            <div class="circle circle-3"></div>
        </div>
    </section>


      <!-- About Us Section -->
<section id="about" class="about-section">
    <div class="container">
        <div class="about-content">
            <div class="about-text">
                <div class="section-header left-align">
                    <h2>About <span>QuickyBite</span></h2>
                    <p>Smart menu access. Instant orders. Hassle-free dining.</p>
                </div>
                <p class="about-description">
                    QuickyBite isn’t just another food ordering platform, it’s a smarter way to experience meals. Whether you're dining in or grabbing takeout, we give you control over your time and food with a sleek digital menu, flexible order scheduling, and real-time order tracking.
                </p>
                <p class="about-description">
                    Designed for speed and convenience, QuickyBite lets you browse curated dishes, reserve a seat, or secure your takeout all with just a few taps. Our live queue system and status notifications make sure you're always in the loop, while advanced features like down payments and seat availability protect your time and order.
                </p>
                <div class="stats-container">
                    <div class="stat-item">
                        <h3>24/7</h3>
                        <p>Smart Menu Access</p>
                    </div>
                    <div class="stat-item">
                        <h3>100%</h3>
                        <p>Real-Time Updates</p>
                    </div>
                    <div class="stat-item">
                        <h3>1 Click</h3>
                        <p>Order & Reorder</p>
                    </div>
                </div>
            </div>
            <div class="about-image">
                <img src="1members.png" alt="QuickyBite App Preview">
                <div class="image-overlay"></div>
                <div class="pattern-dots"></div>
            </div>
        </div>
    </div>
</section>

     
<section id="how-it-works">
    <div class="container">
        <h2 class="section-title">How It Works</h2>
        <p class="section-subtitle">Order from Adris in just a few simple steps</p>
       
        <div class="steps-container">
            <div class="step-card" data-step="1">
                <div class="step-number">1</div>
                <div class="step-icon-container">
                    <div class="step-icon">
                        <svg viewBox="0 0 24 24" fill="red">
                            <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                        </svg>
                    </div>
                </div>
                <h3 class="step-title">Create Your Account</h3>
                <p class="step-description">Sign up with your basic information to access the QuickyBite platform. Your account keeps track of your order history and preferences for faster future orders.</p>
            </div>
           
            <div class="step-card" data-step="2">
                <div class="step-number">2</div>
                <div class="step-icon-container">
                    <div class="step-icon">
                        <svg viewBox="0 0 24 24" fill="palevioletred">
                            <path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/>
                        </svg>
                    </div>
                </div>
                <h3 class="step-title">Browse the Menu</h3>
                <p class="step-description">Explore Adris' complete digital menu with detailed descriptions, prices, and daily specials—all organized by category for easy navigation.</p>
            </div>
           
            <div class="step-card" data-step="3">
                <div class="step-number">3</div>
                <div class="step-icon-container">
                    <div class="step-icon">
                        <svg viewBox="0 0 24 24" fill="palevioletred">
                            <path d="M8.1 13.34l2.83-2.83L3.91 3.5c-1.56 1.56-1.56 4.09 0 5.66l4.19 4.18zm6.78-1.81c1.53.71 3.68.21 5.27-1.38 1.91-1.91 2.28-4.65.81-6.12-1.46-1.46-4.2-1.1-6.12.81-1.59 1.59-2.09 3.74-1.38 5.27L3.7 19.87l1.41 1.41L12 14.41l6.88 6.88 1.41-1.41L13.41 13l1.47-1.47z"/>
                        </svg>
                    </div>
                </div>
                <h3 class="step-title">Select Your Items</h3>
                <p class="step-description">Add your favorite dishes to your cart. Customize your order with available options and special instructions for the kitchen.</p>
            </div>
           
            <div class="step-card" data-step="4">
                <div class="step-number">4</div>
                <div class="step-icon-container">
                    <div class="step-icon">
                        <svg viewBox="0 0 24 24" fill="palevioletred">
                            <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z"/>
                            <path d="M12.5 7H11v6l5.25 3.15.75-1.23-4.5-2.67z"/>
                        </svg>
                    </div>
                </div>
                <h3 class="step-title">Choose Order Type & Time</h3>
                <p class="step-description">Decide between dine-in or takeout. For dine-in, you'll see real-time seat availability. Select your preferred pickup or dining time from available slots.</p>
            </div>
           
            <div class="step-card" data-step="5">
                <div class="step-number">5</div>
                <div class="step-icon-container">
                    <div class="step-icon">
                        <svg viewBox="0 0 24 24" fill="palevioletred">
                            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1.41 16.09V20h-2.67v-1.93c-1.71-.36-3.16-1.46-3.27-3.4h1.96c.1 1.05.82 1.87 2.65 1.87 1.96 0 2.4-.98 2.4-1.59 0-.83-.44-1.61-2.67-2.14-2.48-.6-4.18-1.62-4.18-3.67 0-1.72 1.39-2.84 3.11-3.21V4h2.67v1.95c1.86.45 2.79 1.86 2.85 3.39H14.3c-.05-1.11-.64-1.87-2.22-1.87-1.5 0-2.4.68-2.4 1.64 0 .84.65 1.39 2.67 1.91s4.18 1.39 4.18 3.91c-.01 1.83-1.38 2.83-3.12 3.16z"/>
                        </svg>
                    </div>
                </div>
                <h3 class="step-title">Secure Your Order with Payment</h3>
                <p class="step-description">Complete your order by making a 50% down payment through GCash or other e-wallets. This confirms your booking and prevents cancellations.</p>
            </div>
           
            <div class="step-card" data-step="6">
                <div class="step-number">6</div>
                <div class="step-icon-container">
                    <div class="step-icon">
                        <svg viewBox="0 0 24 24" fill="palevioletred">
                            <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/>
                        </svg>
                    </div>
                </div>
                <h3 class="step-title">Track Your Order</h3>
                <p class="step-description">Monitor your order's live queue position and receive real-time notifications about your order status via SMS or email. Arrive just in time for pickup or when your table is ready.</p>
            </div>
        </div>
    </div>
</section>


     <!-- Featured Menu Section with PHP -->
<?php
// DB connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "adris_ordertaking";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
// Query for most ordered items
$sql = "SELECT 
            o.FoodName, 
            COUNT(*) AS OrderCount, 
            SUM(o.Quantity) AS TotalOrdered, 
            m.FoodPrice AS AvgPrice, 
            m.FoodImage 
        FROM order_items o
        JOIN menuitems m ON o.FoodName = m.FoodName
        GROUP BY o.FoodName
        ORDER BY TotalOrdered DESC, OrderCount DESC
        LIMIT 6";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    echo '<section id="menu" class="menu-section">
            <div class="container">
                <div class="section-header">
                    <h2>Featured <span>Menu</span></h2>
                    <p>Explore our most popular silog meals</p>
                </div>
                <div class="menu-grid">';
    
        while($row = $result->fetch_assoc()) {
        $price = number_format($row["AvgPrice"], 2);
        // Get the image from menu_items
        $foodName = $conn->real_escape_string($row["FoodName"]);
        $imageQuery = "SELECT FoodImage FROM menuitems WHERE FoodName = '$foodName' LIMIT 1";
        $imageResult = $conn->query($imageQuery);
        $imageData = '';
        
        if ($imageResult && $imgRow = $imageResult->fetch_assoc()) {
            $imageData = 'data:image/jpeg;base64,' . base64_encode($imgRow['FoodImage']);
        } else {
            // Use a fallback placeholder image if needed
            $imageData = 'images/placeholder.png'; // or leave it empty if not preferred
        }
        echo '<div class="menu-item" data-category="popular">
                <div class="menu-image">';
        
        // Render base64 image
        if (str_starts_with($imageData, 'data:image')) {
            echo '<img src="' . $imageData . '" alt="' . htmlspecialchars($row["FoodName"]) . '">';
        } else {
            echo '<img src="' . $imageData . '" alt="No Image">';
        }
        echo       '<div class="menu-badge">Popular</div>
                </div>
                <div class="menu-details">
                    <h3>' . htmlspecialchars($row["FoodName"]) . '</h3>
                    <p class="restaurant">Ordered ' . (int)$row["TotalOrdered"] . ' times by ' . $row["OrderCount"] . ' customers</p>
                    <div class="menu-footer">
                        <span class="price">₱' . $price . '</span>
                        <a href="order.php?item=' . urlencode($row["FoodName"]) . '">
                            <button class="order-btn">Order Now</button>
                        </a>
                    </div>
                </div>
            </div>';
    }
    echo '</div>
            <div class="view-more-container">
                <a href="logins.php" class="view-more-btn">
                    <span>View Full Menu</span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                        <polyline points="12 5 19 12 12 19"></polyline>
                    </svg>
                </a>
            </div>
        </div>
    </section>';
} else {
    echo "<p>No popular food items found.</p>";
}
$conn->close();
?>

   <!-- CTA Section -->
    <section class="cta-section">
        <div class="container">
            <div class="cta-content">
                <h2>Ready to save time on your next meal?</h2>
                <p>Join thousands of satisfied customers who are skipping the line with QuickyBite.</p>
                <a href="signup.php" class="cta-btn">
                    <div class="cta-btn-inner">
                        <span>Sign Up Now</span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <polyline points="12 5 19 12 12 19"></polyline>
                        </svg>
                    </div>
                </a>
            </div>
        </div>
        <div class="cta-bg">
            <div class="bg-circle bg-circle-1"></div>
            <div class="bg-circle bg-circle-2"></div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="contact-section">
        <div class="container">
            <div class="contact-wrapper">
                <div class="contact-info">
                    <div class="section-header left-align">
                        <h2>Get in <span>Touch</span></h2>
                        <p>We'd love to hear from you</p>
                    </div>
                    <p class="contact-description">Have questions about QuickyBite? Want to partner with us? Our team is here to help!</p>
                    
                    <div class="contact-methods">
                        <div class="contact-method">
                            <div class="method-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                                </svg>
                            </div>
                            <div class="method-details">
                                <h3>Phone</h3>
                                <p>0905-284-9938</p>
                            </div>
                        </div>
                        
                        <div class="contact-method">
                            <div class="method-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                                    <polyline points="22,6 12,13 2,6"></polyline>
                                </svg>
                            </div>
                            <div class="method-details">
                                <h3>Email</h3>
                                <p>Adris_quickybite@gmail.com</p>
                            </div>
                        </div>
                        
                        <div class="contact-method">
                            <div class="method-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                    <circle cx="12" cy="10" r="3"></circle>
                                </svg>
                            </div>
                            <div class="method-details">
                                <h3>Address</h3>
                                <p>UMAK<br>University Of Makati</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="social-links">
                        <a href="#" class="social-link">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                            </svg>
                        </a>
                        <a href="#" class="social-link">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                                <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                                <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                            </svg>
                        </a>
                        <a href="#" class="social-link">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"></path>
                            </svg>
                        </a>
                        <a href="#" class="social-link">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                                <rect x="2" y="9" width="4" height="12"></rect>
                                <circle cx="4" cy="4" r="2"></circle>
                            </svg>
                        </a>
                    </div>
                </div>
                
                <div class="contact-form">
                    <h3>Send us a message</h3>
                    <form id="contactForm">
                        <div class="form-group">
                            <input type="text" id="name" name="name" placeholder="Your Name" required>
                        </div>
                        <div class="form-group">
                            <input type="email" id="email" name="email" placeholder="Your Email" required>
                        </div>
                        <div class="form-group">
                            <input type="text" id="subject" name="subject" placeholder="Subject">
                        </div>
                        <div class="form-group">
                            <textarea id="message" name="message" placeholder="Your Message" required></textarea>
                        </div>
                        <button type="submit" class="submit-btn">
                            <span>Send Message</span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <line x1="22" y1="2" x2="11" y2="13"></line>
                                <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                            </svg>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Newsletter Section -->
    <section class="newsletter-section">
        <div class="container">
            <div class="newsletter-content">
                <div class="newsletter-text">
                    <h2>Subscribe to Our Newsletter</h2>
                    <p>Get exclusive deals and updates on new restaurant partners.</p>
                </div>
                <form class="newsletter-form">
                    <input type="email" placeholder="Enter your email address" required>
                    <button type="submit" class="newsletter-btn">Subscribe</button>
                </form>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-column">
                    <a href="#" class="footer-logo"><span>QB</span> QuickyBite</a>
                    <p class="footer-description">Order ahead and skip the line at your favorite restaurants.</p>
                    <div class="footer-social">
                        <a href="#" class="social-link">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                            </svg>
                        </a>
                        <a href="#" class="social-link">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                                <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                                <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                            </svg>
                        </a>
                        <a href="#" class="social-link">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"></path>
                            </svg>
                        </a>
                    </div>
                </div>
                <div class="footer-column">
                    <h3>Quick Links</h3>
                    <ul class="footer-links">
                        <li><a href="#home">Home</a></li>
                        <li><a href="#about">About Us</a></li>
                        <li><a href="#how-it-works">How It Works</a></li>
                        <li><a href="#menu">Menu</a></li>
                        <li><a href="#contact">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Support</h3>
                    <ul class="footer-links">
                        <li><a href="#">FAQ</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Terms of Service</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Contact Us</h3>
                    <div class="footer-contact">
                        <p><strong>Address:</strong>University Of Makati</p>
                        <p><strong>Phone:</strong> 6969-696-6969</p>
                        <p><strong>Email:</strong> Adris_quickybite@gmail.com</p>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 QuickyBite. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <a href="#" class="back-to-top" id="backToTop">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="18 15 12 9 6 15"></polyline>
        </svg>
    </a>

    <!-- JavaScript -->
    <script src="homepage.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const stepCards = document.querySelectorAll('.step-card');
            
            // Hide all cards initially
            stepCards.forEach(card => {
                card.classList.add('hidden');
            });
            
            // Initialize Intersection Observer
            const options = {
                threshold: 0.1, // Card is considered visible when 10% of it is in viewport
                rootMargin: '0px 0px -10% 0px' // Adjust this to change when cards trigger
            };
            
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    const stepCard = entry.target;
                    
                    if (entry.isIntersecting) {
                        // Show card when it comes into view
                        stepCard.classList.remove('hidden');
                        stepCard.classList.add('visible');
                        
                        // Add floating animation to icon after entrance animation
                        setTimeout(() => {
                            const icon = stepCard.querySelector('.step-icon');
                            if (icon) {
                                icon.classList.add('floating');
                            }
                        }, 800);
                    } else {
                        // Hide card when it's out of view
                        stepCard.classList.remove('visible');
                        stepCard.classList.add('hidden');
                        
                        // Remove floating animation
                        const icon = stepCard.querySelector('.step-icon');
                        if (icon) {
                            icon.classList.remove('floating');
                        }
                    }
                });
            }, options);
            
            // Start observing all step cards
            stepCards.forEach(card => {
                observer.observe(card);
            });
            
            // Add hover effects for step icons
            stepCards.forEach(card => { 
                const icon = card.querySelector('.step-icon');
                
                card.addEventListener('mouseover', function() {
                    if (icon) {
                        icon.classList.remove('floating');
                        icon.classList.add('glow');
                        icon.style.animation = 'pulse 1s infinite, glow 2s infinite alternate';
                    }
                });
                
                card.addEventListener('mouseout', function() {
                    if (icon && card.classList.contains('visible')) {
                        icon.classList.remove('glow');
                        icon.classList.add('floating');
                        icon.style.animation = 'floating 3s ease-in-out infinite';
                    }
                });
            });
        });
    </script>
</body>
</html>