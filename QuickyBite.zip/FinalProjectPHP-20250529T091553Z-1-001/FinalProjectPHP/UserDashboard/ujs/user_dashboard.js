document.addEventListener('DOMContentLoaded', function() {
    // Animation timing for staggered card appearance
    const cards = document.querySelectorAll('.dashboard-card');
    cards.forEach((card, index) => {
        card.style.animationDelay = `${0.2 + (index * 0.1)}s`;
    });

    // Hover effects for action items
    const actionItems = document.querySelectorAll('.action-item');
    actionItems.forEach(item => {
        item.addEventListener('mouseenter', function() {
            const icon = this.querySelector('i');
            icon.classList.add('fa-bounce');
            setTimeout(() => {
                icon.classList.remove('fa-bounce');
            }, 1000);
        });
    });

    // Add pulse animation to the order now button
    const orderNowBtn = document.querySelector('.order-now-btn');
    if (orderNowBtn) {
        setTimeout(() => {
            orderNowBtn.classList.add('pulse');
            setTimeout(() => {
                orderNowBtn.classList.remove('pulse');
            }, 1500);
        }, 2000);
    }

    // Add CSS for the pulse animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); box-shadow: 0 0 15px rgba(241, 214, 214, 0.5); }
            100% { transform: scale(1); }
        }
        
        .pulse {
            animation: pulse 1.5s ease;
        }
        
        @keyframes fa-bounce {
            0% { transform: scale(1); }
            50% { transform: scale(1.3); }
            100% { transform: scale(1); }
        }
        
        .fa-bounce {
            animation: fa-bounce 0.6s ease;
        }
    `;
    document.head.appendChild(style);
    
    // Show a welcome message using toast notification
    // Create toast container if it doesn't exist
    if (!document.querySelector('.toast-container')) {
        const toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container';
        document.body.appendChild(toastContainer);
        
        // Add CSS for toast
        const toastStyle = document.createElement('style');
        toastStyle.textContent = `
            .toast-container {
                position: fixed;
                bottom: 20px;
                right: 20px;
                z-index: 1000;
            }
            
            .toast {
                background-color: rgba(30, 30, 30, 0.9);
                color: #fff;
                padding: 15px 20px;
                border-radius: 8px;
                margin-top: 10px;
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
                display: flex;
                align-items: center;
                transform: translateX(120%);
                transition: transform 0.3s ease;
                max-width: 300px;
            }
            
            .toast.show {
                transform: translateX(0);
            }
            
            .toast-icon {
                margin-right: 12px;
                font-size: 18px;
                color: var(--primary-color);
            }
            
            .toast-message {
                flex: 1;
            }
            
            .toast-close {
                background: none;
                border: none;
                color: #aaa;
                font-size: 16px;
                cursor: pointer;
                margin-left: 10px;
                transition: color 0.3s ease;
            }
            
            .toast-close:hover {
                color: #fff;
            }
        `;
        document.head.appendChild(toastStyle);
    }
    
    // Show welcome toast
    setTimeout(() => {
        showToast('Welcome to your dashboard!', 'smile');
    }, 1000);
});

// Function to show toast notifications
function showToast(message, icon = 'info', duration = 4000) {
    const toastContainer = document.querySelector('.toast-container');
    
    if (!toastContainer) return;
    
    // Create toast element
    const toast = document.createElement('div');
    toast.className = 'toast';
    
    // Set icon based on parameter
    let iconClass = 'fa-info-circle';
    if (icon === 'success') iconClass = 'fa-check-circle';
    else if (icon === 'warning') iconClass = 'fa-exclamation-triangle';
    else if (icon === 'error') iconClass = 'fa-times-circle';
    else if (icon === 'smile') iconClass = 'fa-smile';
    
    // Create toast content
    toast.innerHTML = `
        <i class="toast-icon fas ${iconClass}"></i>
        <div class="toast-message">${message}</div>
        <button class="toast-close"><i class="fas fa-times"></i></button>
    `;
    
    // Add toast to container
    toastContainer.appendChild(toast);
    
    // Show toast with slight delay for smooth animation
    setTimeout(() => {
        toast.classList.add('show');
    }, 10);
    
    // Close button functionality
    const closeBtn = toast.querySelector('.toast-close');
    closeBtn.addEventListener('click', () => {
        removeToast(toast);
    });
    
    // Auto remove after duration
    if (duration) {
        setTimeout(() => {
            removeToast(toast);
        }, duration);
    }
}

// Function to remove toast with animation
function removeToast(toast) {
    toast.classList.remove('show');
    
    // Remove from DOM after animation completes
    setTimeout(() => {
        toast.remove();
    }, 300);
}

// Function to update real-time notifications (can be expanded later)
function updateNotifications() {
    // This function could be used to fetch notifications from the server
    // For now, let's just simulate a notification after some time
    
    setTimeout(() => {
        showToast('Don\'t forget to check today\'s specials!', 'info', 5000);
    }, 30000); // Show after 30 seconds
}

// Initialize notification system
updateNotifications();

// Add smooth scroll behavior to the side navigation links
document.querySelectorAll('.nav-icon').forEach(link => {
    link.addEventListener('click', function(e) {
        // Only apply to same-page links
        const href = this.getAttribute('href');
        if (href.startsWith('#')) {
            e.preventDefault();
            const targetId = href.substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 20,
                    behavior: 'smooth'
                });
            }
        }
    });
});

// Add responsive behavior for mobile
function adjustForMobile() {
    const sideNav = document.querySelector('.side-nav');
    const mainContent = document.querySelector('.main-content');
    
    if (window.innerWidth <= 768) {
        // Handle mobile menu toggle
        if (!document.querySelector('.mobile-menu-toggle')) {
            const menuToggle = document.createElement('button');
            menuToggle.className = 'mobile-menu-toggle';
            menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
            document.body.appendChild(menuToggle);
            
            // Add CSS for mobile menu toggle
            const mobileStyle = document.createElement('style');
            mobileStyle.textContent = `
                .mobile-menu-toggle {
                    position: fixed;
                    top: 15px;
                    left: 15px;
                    background-color: var(--card-bg);
                    border: none;
                    color: var(--text-color);
                    font-size: 20px;
                    width: 40px;
                    height: 40px;
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    z-index: 200;
                    box-shadow: 0 3px 10px rgba(0,0,0,0.2);
                    cursor: pointer;
                    transition: all 0.3s ease;
                }
                
                .mobile-menu-toggle:hover {
                    background-color: var(--primary-color);
                    color: #333;
                }
                
                .side-nav.mobile-hidden {
                    transform: translateX(-100%);
                }
                
                .main-content.full-width {
                    padding-left: 20px;
                }
                
                .overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background-color: rgba(0,0,0,0.5);
                    z-index: 99;
                    display: none;
                    opacity: 0;
                    transition: opacity 0.3s ease;
                }
                
                .overlay.show {
                    display: block;
                    opacity: 1;
                }
            `;
            document.head.appendChild(mobileStyle);
            
            // Create overlay
            const overlay = document.createElement('div');
            overlay.className = 'overlay';
            document.body.appendChild(overlay);
            
            // Toggle menu on click
            menuToggle.addEventListener('click', () => {
                sideNav.classList.toggle('mobile-hidden');
                mainContent.classList.toggle('full-width');
                overlay.classList.toggle('show');
            });
            
            // Close menu when clicking overlay
            overlay.addEventListener('click', () => {
                sideNav.classList.add('mobile-hidden');
                mainContent.classList.add('full-width');
                overlay.classList.remove('show');
            });
            
            // Initial state
            sideNav.classList.add('mobile-hidden');
            mainContent.classList.add('full-width');
        }
    } else {
        // Remove mobile-specific elements on desktop
        const menuToggle = document.querySelector('.mobile-menu-toggle');
        const overlay = document.querySelector('.overlay');
        
        if (menuToggle) menuToggle.remove();
        if (overlay) overlay.remove();
        
        sideNav.classList.remove('mobile-hidden');
        mainContent.classList.remove('full-width');
    }
}

// Run on page load and resize
adjustForMobile();
window.addEventListener('resize', adjustForMobile);

// Add order tracking progress animation
const orderStatuses = document.querySelectorAll('.status-badge');
orderStatuses.forEach(status => {
    if (status.classList.contains('processing')) {
        // Add pulse animation to processing orders
        status.classList.add('pulse-status');
        
        // Add CSS for pulsing status
        const pulseStyle = document.createElement('style');
        pulseStyle.textContent = `
            .pulse-status {
                position: relative;
                overflow: hidden;
            }
            
            .pulse-status::after {
                content: '';
                position: absolute;
                top: 0;
                left: -100%;
                width: 100%;
                height: 100%;
                background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
                animation: pulse-slide 2s infinite;
            }
            
            @keyframes pulse-slide {
                0% { left: -100%; }
                100% { left: 100%; }
            }
        `;
        document.head.appendChild(pulseStyle);
    }
});