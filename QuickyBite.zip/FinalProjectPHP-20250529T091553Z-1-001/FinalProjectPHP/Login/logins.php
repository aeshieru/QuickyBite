<?php
// Database connection
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "adris_ordertaking";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";
$messageType = "";

// Check if user was just verified
if (isset($_GET['verified']) && $_GET['verified'] == 'true') {
    $message = "Your account has been verified successfully. You can now log in.";
    $messageType = "success";
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $rememberMe = isset($_POST['rememberMe']);
    
    // Basic validation
    if (empty($username) || empty($password)) {
        $message = "Username and password are required";
        $messageType = "error";
    } else {
        // Verify user credentials - Optimized query
        $stmt = $conn->prepare("SELECT `user_id`, username, password, full_name, user_type, is_active FROM users WHERE username = ? OR email = ? LIMIT 1");
        $stmt->bind_param("ss", $username, $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            
            // Check if the account is verified
            if ($user['is_active'] != 1) {
                $message = "Please verify your email address before logging in.";
                $messageType = "error";
            } else {
                // Verify password
                if (password_verify($password, $user['password']) || $password === $user['password']) {
                    // Set session variables - No need to start session again
                    $_SESSION['user_id'] = $user['user_id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['user_type'] = $user['user_type'];
                    $_SESSION['logged_in'] = true;
                    
                    // Handle remember me functionality
                    if ($rememberMe) {
                        $token = bin2hex(random_bytes(16)); // Reduced from 32 to 16 for efficiency
                        
                        // Store token in database - Use prepared statement
                        $expiry = date('Y-m-d H:i:s', strtotime('+30 days'));
                        $storeToken = $conn->prepare("INSERT INTO remember_tokens (user_id, token, expiry) VALUES (?, ?, ?)");
                        $storeToken->bind_param("iss", $user['user_id'], $token, $expiry);
                        $storeToken->execute();
                        $storeToken->close();
                        
                        // Set cookies
                        setcookie("remember_user", $user['username'], time() + (86400 * 30), "/"); // 30 days
                        setcookie("remember_token", $token, time() + (86400 * 30), "/"); // 30 days
                    }
                    
                    // Redirect based on user type
                    switch ($user['user_type']) {
                        case 'admin':
                            header("Location: /AdminDashboard/get-user-orders.php");
                            break;
                        case 'kitchen':
                            header("Location: /KitchenDashboard/live.php");
                            break;
                        case 'customer':
                        default:
                            header("Location: /UserDashboard/DisplayMenu.php");
                            break;
                    }
                    exit();
                } else {
                    $message = "Invalid username or password";
                    $messageType = "error";
                }
            }
        } else {
            $message = "Invalid username or password";
            $messageType = "error";
        }
        $stmt->close();
    }
}

// Check for remember me cookie - Optimized to avoid redundant queries
if (!isset($_SESSION['logged_in']) && isset($_COOKIE['remember_user']) && isset($_COOKIE['remember_token'])) {
    $cookieUsername = $_COOKIE['remember_user'];
    $cookieToken = $_COOKIE['remember_token'];
    
    // Verify token - Use JOIN for efficiency
    $verifyToken = $conn->prepare("
        SELECT u.user_id, u.username, u.full_name, u.user_type 
        FROM users u 
        JOIN remember_tokens t ON u.user_id = t.user_id 
        WHERE u.username = ? AND t.token = ? AND t.expiry > NOW()
        LIMIT 1
    ");
    
    $verifyToken->bind_param("ss", $cookieUsername, $cookieToken);
    $verifyToken->execute();
    $result = $verifyToken->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        // Set session variables
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['user_type'] = $user['user_type'];
        $_SESSION['logged_in'] = true;
        
        // Redirect based on user type
            switch ($user['user_type']) {
                case 'admin':
                    header("Location: admin_dashboard.php");
                    break;
                case 'kitchen':
                    header("Location: /KitchenDashboard/live.php");
                    break;
                case 'customer':
                default:
                    header("Location: /UserDashboard/DisplayMenu.php");
                    break;
            }
            exit();
}
    $verifyToken->close();
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - QuickyBite</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="styles/logins.css">
</head>
<body>
    
    <div class="bg-animation">
        <div class="bg-bubble"></div>
        <div class="bg-bubble"></div>
        <div class="bg-bubble"></div>
        <div class="bg-bubble"></div>
    </div>
    
    <div class="container">
        <h1>LOGIN</h1>
        <p class="tagline">Welcome back to QuickyBite!</p>
        
        <?php if (!empty($message)): ?>
            <div class="message <?php echo $messageType; ?>">
                <i class="fas fa-<?php echo $messageType === 'error' ? 'exclamation-circle' : 'check-circle'; ?>"></i>
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        
        <form id="loginForm" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-group">
                <label for="username">Username or Email</label>
                <input type="text" id="username" name="username" placeholder="Enter your username or email" value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>" required>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <div class="password-container">
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                    <i class="toggle-password fas fa-eye"></i>
                </div>
            </div>
            
            <div class="form-options">
                <div class="remember-me">
                    <input type="checkbox" id="rememberMe" name="rememberMe">
                    <label for="rememberMe">Remember me</label>
                </div>
                <a href="forgot-password.php" class="forgot-password">Forgot Password?</a>
            </div>
            
            <button type="submit" class="btn" id="loginBtn">
                <i class="fas fa-sign-in-alt"></i>
                LOGIN
            </button>
        </form>
        
        <div class="signup-link">
            Don't have an account? <a href="signup.php">Sign Up</a>
        </div>
    </div>

    <script src="js/logins.js"></script>
    
</body>
</html>