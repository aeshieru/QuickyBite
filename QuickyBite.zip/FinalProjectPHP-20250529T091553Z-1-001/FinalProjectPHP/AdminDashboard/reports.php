<?php
ob_start();
// DB connection
$host = 'localhost';
$db = 'adris_ordertaking';
$user = 'root';
$pass = '';
$dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";

try {
    $pdo = new PDO($dsn, $user, $pass);
} catch (PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}

// === Generate Insights ===

// 1. Best-selling items
$bestSellingQuery = "
    SELECT FoodName, SUM(Quantity) AS total_sold
    FROM order_items
    GROUP BY FoodName
    ORDER BY total_sold DESC
    LIMIT 5
";
$bestSelling = $pdo->query($bestSellingQuery)->fetchAll(PDO::FETCH_ASSOC);

// 2. Busiest time slots
$busiestTimesQuery = "
    SELECT HOUR(OrderDate) AS hour_slot, COUNT(*) AS order_count
    FROM `orders`
    GROUP BY hour_slot
    ORDER BY order_count DESC
    LIMIT 3
";
$busiestTimes = $pdo->query($busiestTimesQuery)->fetchAll(PDO::FETCH_ASSOC);

// 3. Total revenue
$totalSalesQuery = "
    SELECT SUM(Quantity * Price) AS total_revenue
    FROM order_items
";
$totalSales = $pdo->query($totalSalesQuery)->fetch(PDO::FETCH_ASSOC);

// Format insight summary
$summary = "INSIGHT DATA:\n\n";

// Best-selling
$summary .= "Best-Selling Items:\n";
foreach ($bestSelling as $item) {
    $summary .= "- {$item['FoodName']}: {$item['total_sold']} sold\n";
}

// Busiest hours
$summary .= "\nBusiest Time Slots:\n";
foreach ($busiestTimes as $row) {
    $summary .= "- Hour {$row['hour_slot']}: {$row['order_count']} orders\n";
}

// Total revenue
$summary .= "\nTotal Revenue: ₱" . number_format($totalSales['total_revenue'], 2);


function drawBarChart($pdf, $data, $title, $x, $y, $width = 100, $barHeight = 6) {
    $maxValue = max(array_column($data, 'value'));
    $barWidthUnit = $width / ($maxValue ?: 1); // Prevent division by zero

    $pdf->SetXY($x, $y);
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(0, 10, $title, 0, 1);

    $pdf->SetFont('helvetica', '', 10);
    $y += 5;

    foreach ($data as $row) {
        $label = $row['label'];
        $value = $row['value'];

        $pdf->SetXY($x, $y);
        $pdf->Cell(40, $barHeight, $label, 0, 0);

        $barWidth = $value * $barWidthUnit;
        $pdf->SetFillColor(50, 150, 250);
        $pdf->Rect($x + 45, $y, $barWidth, $barHeight, 'F');

        $pdf->SetXY($x + 45 + $barWidth + 2, $y);
        $pdf->Cell(0, $barHeight, $value, 0, 1);

        $y += $barHeight + 4;
    }
}

// Prepare chart data
$chartBestSelling = array_map(fn($row) => [
    'label' => $row['FoodName'],
    'value' => (float)$row['total_sold']
], $bestSelling);

$chartTimeSlots = array_map(fn($row) => [
    'label' => 'Hour ' . $row['hour_slot'],
    'value' => (int)$row['order_count']
], $busiestTimes);


// === Gemini API Call ===
$geminiKey = 'insert your api key here';
$prompt = "Based on this restaurant performance data, provide 3 actionable business recommendations. Also dont use bold letters just plaintext:\n\n" . $summary;
$response = getGeminiFeedback($geminiKey, $prompt);

// === Generate PDF if Button Clicked ===
if (isset($_POST['generate_pdf'])) {
    require_once(__DIR__ . '/../TCPDF-main/tcpdf.php');
    ob_end_clean();

    // Setup PDF
    $pdf = new TCPDF();
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetAuthor('Adris Restaurant');
    $pdf->SetTitle('Business Insights Report');
    $pdf->SetMargins(20, 20, 20);
    $pdf->AddPage();
    $pdf->SetFont('helvetica', '', 12);

    // === Title ===
    $pdf->SetFont('helvetica', 'B', 16);
    $pdf->Cell(0, 10, 'Business Insights Report', 0, 1, 'C');
    $pdf->Ln(5);

    // === Best-Selling Items ===
    $pdf->SetFont('helvetica', 'B', 13);
    $pdf->Cell(0, 10, 'Top 5 Best-Selling Food Items', 0, 1);
    $pdf->SetFont('helvetica', '', 11);
    foreach ($bestSelling as $item) {
        $pdf->MultiCell(0, 6, "• {$item['FoodName']} — {$item['total_sold']} sold", 0, 'L');
    }
    $pdf->Ln(5);

    // === Busiest Hours ===
    $pdf->SetFont('helvetica', 'B', 13);
    $pdf->Cell(0, 10, 'Top 3 Busiest Time Slots', 0, 1);
    $pdf->SetFont('helvetica', '', 11);
    foreach ($busiestTimes as $row) {
        $pdf->MultiCell(0, 6, "• Hour {$row['hour_slot']}: {$row['order_count']} orders", 0, 'L');
    }
    $pdf->Ln(5);

    // === Total Revenue ===
    $pdf->SetFont('helvetica', 'B', 13);
    $pdf->Cell(0, 10, 'Total Revenue', 0, 1);
    $pdf->SetFont('helvetica', '', 11);
    $pdf->MultiCell(0, 6, "• ₱" . number_format($totalSales['total_revenue'], 2), 0, 'L');
    $pdf->Ln(8);

    // === Gemini Feedback ===
    $pdf->SetFont('helvetica', 'B', 13);
    $pdf->Cell(0, 10, 'AI Business Recommendations (Gemini)', 0, 1);
    $pdf->SetFont('helvetica', '', 11);
    $pdf->MultiCell(0, 6, $response, 0, 'L');

    // === Page 2: Charts ===
    $pdf->AddPage();
    $pdf->SetFont('helvetica', 'B', 14);
    $pdf->Cell(0, 10, 'Visual Charts', 0, 1, 'C');
    $pdf->Ln(5);

    drawBarChart($pdf, $chartBestSelling, 'Best-Selling Items', 20, 30);
    drawBarChart($pdf, $chartTimeSlots, 'Busiest Time Slots', 20, 100);

    $pdf->Output('business_insights.pdf', 'D');
    exit;
}

// === Gemini Function ===
function getGeminiFeedback($apiKey, $prompt) {
    $url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$apiKey";

    $data = [
        "contents" => [
            [
                "parts" => [
                    ["text" => $prompt]
                ]
            ]
        ]
    ];

    $options = [
        "http" => [
            "header"  => "Content-type: application/json",
            "method"  => "POST",
            "content" => json_encode($data),
        ]
    ];

    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);

    if ($result === FALSE) {
        return "Error getting feedback from Gemini.";
    }

    $resultData = json_decode($result, true);
    return $resultData['candidates'][0]['content']['parts'][0]['text'] ?? "No feedback generated.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Business Insights</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #000000;
      background-image: 
        radial-gradient(circle at 20% 30%, rgba(248, 120, 160, 0.15) 0%, transparent 50%),
        radial-gradient(circle at 80% 70%, rgba(248, 120, 160, 0.1) 0%, transparent 50%);
      margin: 0;
      padding: 0;
      color: #ffffff;
      display: flex;
      min-height: 100vh;
    }
    
    .side-nav {
      width: 80px;
      height: 100vh;
      background: rgba(17, 17, 17, 0.7);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      display: flex;
      flex-direction: column;
      align-items: center;
      padding-top: 20px;
      position: fixed;
      border-right: 1px solid rgba(255, 255, 255, 0.1);
      box-shadow: 0 4px 30px rgba(0, 0, 0, 0.2);
      z-index: 10;
      transition: width 0.3s ease;
      overflow: hidden;
    }
    
    .side-nav:hover {
      width: 200px;
      align-items: flex-start;
      padding-left: 20px;
    }
    
    .logo-box {
      background-color: #f8e8e8;
      color: #000;
      padding: 8px 12px;
      margin-bottom: 30px;
      font-weight: bold;
      font-size: 18px;
      border-radius: 4px;
      box-shadow: 0 0 15px rgba(248, 120, 160, 0.5);
      align-self: center;
    }
    
    .side-nav:hover .logo-box {
      width: 80%;
      text-align: center;
      padding: 8px 0;
    }
    
    .nav-icon {
      width: 24px;
      height: 24px;
      margin: 15px 0;
      display: flex;
      align-items: center;
      color: #fff;
      opacity: 0.7;
      transition: all 0.3s;
      text-decoration: none;
      position: relative;
    }
    
    .nav-icon-text {
      white-space: nowrap;
      margin-left: 15px;
      opacity: 0;
      transition: opacity 0.3s ease;
      color: #ffffff;
      font-weight: 500;
    }
    
    .side-nav:hover .nav-icon {
      width: 90%;
      justify-content: flex-start;
    }
    
    .side-nav:hover .nav-icon-text {
      opacity: 1;
    }
    
    .nav-icon:hover {
      opacity: 1;
      text-shadow: 0 0 10px rgba(248, 232, 232, 0.8);
    }
    
    .nav-icon.active {
      opacity: 1;
      border-left: 2px solid #f8e8e8;
      padding-left: 10px;
      text-shadow: 0 0 10px rgba(248, 232, 232, 0.8);
    }
    
    .nav-icon img {
      width: 24px;
      height: 24px;
    }
    
    .main-content {
      flex: 1;
      margin-left: 80px;
      width: calc(100% - 80px);
      padding: 20px 0;
      transition: margin-left 0.3s ease, width 0.3s ease;
    }
    
    h1 {
      color: #ffffff;
      margin-bottom: 10px;
      text-align: center;
      padding-top: 20px;
      text-shadow: 0 0 10px rgba(248, 120, 160, 0.5);
    }
    
    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 20px;
    }
    
    .nav-tabs {
      display: flex;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      margin-bottom: 20px;
    }
    
    .nav-tab {
      padding: 12px 20px;
      color: #ffffff;
      text-decoration: none;
      margin-right: 5px;
      border-bottom: 3px solid transparent;
      font-weight: bold;
      transition: all 0.3s;
    }
    
    .nav-tab.active {
      border-bottom: 3px solid #f8a8c8;
      color: #f8a8c8;
    }
    
    .nav-tab:hover {
      background-color: rgba(248, 120, 160, 0.1);
    }
    
    .dashboard-stats {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: 15px;
      margin-bottom: 20px;
    }
    
    .stat-card {
      background: rgba(248, 232, 232, 0.1);
      border-radius: 10px;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      border: 1px solid rgba(255, 255, 255, 0.08);
      padding: 20px;
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      transition: transform 0.2s, box-shadow 0.3s;
    }
    
    .stat-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
    }
    
    .stat-title {
      font-size: 14px;
      opacity: 0.7;
      margin-bottom: 5px;
    }
    
    .stat-value {
      font-size: 28px;
      font-weight: bold;
      margin-bottom: 5px;
    }
    
    .card-section {
      background: rgba(248, 232, 232, 0.1);
      border-radius: 10px;
      padding: 20px;
      margin-bottom: 20px;
      border: 1px solid rgba(255, 255, 255, 0.08);
      backdrop-filter: blur(5px);
      -webkit-backdrop-filter: blur(5px);
    }
    
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      background: rgba(248, 120, 160, 0.7);
      color: white;
      border: none;
      padding: 12px 24px;
      border-radius: 5px;
      cursor: pointer;
      font-weight: bold;
      transition: all 0.3s;
      text-decoration: none;
      margin-top: 15px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    .btn:hover {
      background: rgba(248, 120, 160, 1);
      box-shadow: 0 8px 15px rgba(248, 120, 160, 0.3);
      transform: translateY(-2px);
    }
    
    .insights-data {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
    }

    .insight-box {
      flex: 1 1 300px;
      background: rgba(17, 17, 17, 0.5);
      border-radius: 8px;
      padding: 15px;
      border: 1px solid rgba(248, 120, 160, 0.3);
      transition: transform 0.3s, box-shadow 0.3s;
    }
    
    .insight-box:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 25px rgba(248, 120, 160, 0.15);
    }

    .insight-heading {
      font-size: 16px;
      margin-bottom: 10px;
      color: rgba(248, 120, 160, 1);
      border-bottom: 1px solid rgba(248, 120, 160, 0.3);
      padding-bottom: 5px;
    }

    .insight-list {
      list-style-type: none;
      padding-left: 0;
    }

    .insight-list li {
      padding: 8px 0;
      border-bottom: 1px solid rgba(255, 255, 255, 0.05);
      display: flex;
      justify-content: space-between;
    }

    .insight-list li:last-child {
      border-bottom: none;
    }
    
    /* AI Recommendations Styling */
    .ai-recommendations-container {
      background: rgba(17, 17, 17, 0.7);
      border-radius: 12px;
      padding: 20px;
      border: 1px solid rgba(248, 120, 160, 0.2);
      margin-bottom: 20px;
    }
    
    .ai-header {
      display: flex;
      align-items: center;
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 1px solid rgba(248, 120, 160, 0.3);
    }
    
    .ai-icon {
      margin-right: 10px;
    }
    
    .ai-title {
      font-size: 20px;
      font-weight: bold;
      color: rgba(248, 120, 160, 0.9);
      letter-spacing: 0.5px;
    }
    
    .recommendations-cards {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 15px;
    }
    
    .rec-card {
      background: rgba(255, 255, 255, 0.05);
      border-radius: 8px;
      padding: 20px;
      border: 1px solid rgba(248, 120, 160, 0.2);
      transition: transform 0.3s, box-shadow 0.3s;
      height: 100%;
      display: flex;
      flex-direction: column;
    }
    
    .rec-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 25px rgba(248, 120, 160, 0.15);
      background: rgba(255, 255, 255, 0.08);
    }
    
    .rec-title {
      font-size: 16px;
      margin-top: 0;
      margin-bottom: 15px;
      color: rgba(248, 120, 160, 0.9);
      padding-bottom: 8px;
      border-bottom: 1px solid rgba(248, 120, 160, 0.2);
    }
    
    .rec-content {
      line-height: 1.6;
      color: rgba(255, 255, 255, 0.8);
      flex-grow: 1;
    }
    
    /* Reports Page Specific Styling */
    .report-filters {
      display: flex;
      flex-wrap: wrap;
      gap: 15px;
      margin-bottom: 20px;
      background: rgba(17, 17, 17, 0.5);
      border-radius: 8px;
      padding: 20px;
      border: 1px solid rgba(248, 120, 160, 0.2);
    }
    
    .filter-group {
      flex: 1 1 200px;
      display: flex;
      flex-direction: column;
    }
    
    .filter-label {
      font-size: 14px;
      margin-bottom: 8px;
      color: rgba(248, 120, 160, 0.9);
    }
    
    .filter-input {
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(248, 120, 160, 0.3);
      border-radius: 5px;
      padding: 10px;
      color: white;
      outline: none;
    }
    
    .filter-input:focus {
      border-color: rgba(248, 120, 160, 0.8);
      box-shadow: 0 0 10px rgba(248, 120, 160, 0.2);
    }
    
    select.filter-input {
      appearance: none;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='rgba(248, 120, 160, 0.8)' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E");
      background-repeat: no-repeat;
      background-position: right 10px center;
      padding-right: 30px;
    }
    
    .report-table-container {
      overflow-x: auto;
      margin-bottom: 20px;
      background: rgba(17, 17, 17, 0.5);
      border-radius: 8px;
      padding: 15px;
      border: 1px solid rgba(248, 120, 160, 0.2);
    }
    
    .report-table {
      width: 100%;
      border-collapse: collapse;
    }
    
    .report-table th {
      background: rgba(248, 120, 160, 0.2);
      padding: 12px 15px;
      text-align: left;
      border-bottom: 2px solid rgba(248, 120, 160, 0.5);
      font-weight: bold;
    }
    
    .report-table td {
      padding: 10px 15px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    }
    
    .report-table tr:last-child td {
      border-bottom: none;
    }
    
    .report-table tr:hover td {
      background: rgba(248, 120, 160, 0.05);
    }
    
    .chart-container {
      background: rgba(17, 17, 17, 0.5);
      border-radius: 8px;
      padding: 20px;
      margin-bottom: 20px;
      border: 1px solid rgba(248, 120, 160, 0.2);
      height: 300px;
    }
  </style>
</head>
<body>
    <nav class="side-nav">
        <div class="logo-box">QB</div>
        <a href="get-user-orders.php" class="nav-icon">
          <img src="aimages/user-gear.png" alt="Users">
          <span class="nav-icon-text">Manage Users</span>
        </a>
        <a href="ManageMenu.php" class="nav-icon">
          <img src="aimages/task-checklist.png" alt="Menu">
          <span class="nav-icon-text">Manage Menu</span>
        </a>
        <a href="ManageSeats.php" class="nav-icon">
          <img src="aimages/chair.png" alt="Seats">
          <span class="nav-icon-text">Manage Seats</span>
        </a>
        <a href="reports.php" class="nav-icon active">
            <img src="aimages/user-gear.png" alt="Reports">
            <span class="nav-icon-text">Reports</span>
        </a>
        <a href="../Login/logout.php" class="nav-icon">
          <img src="aimages/exit.png" alt="Logout">
          <span class="nav-icon-text">Log Out</span>
        </a>
    </nav>

  <div class="main-content">
    <h1>Business Insights</h1>
    
    <div class="container">
      <div class="nav-tabs">
        <a href="#" class="nav-tab active">Overview</a>

      </div>
      
      <div class="dashboard-stats">
        <!-- Best Selling Item -->
        <div class="stat-card" style="grid-column: span 2;">
          <div class="stat-title">Most Ordered Item</div>
          <div class="stat-value" style="font-size: 36px;"><?= $bestSelling[0]['FoodName'] ?? 'No data' ?></div>
          <div class="stat-trend"><?= $bestSelling[0]['total_sold'] ?? 0 ?> orders</div>
        </div>
        
        <!-- Busiest Time Slot -->
        <div class="stat-card">
          <div class="stat-title">Busiest Hour</div>
          <div class="stat-value">Hour <?= $busiestTimes[0]['hour_slot'] ?? 'N/A' ?></div>
          <div class="stat-trend"><?= $busiestTimes[0]['order_count'] ?? 0 ?> orders</div>
        </div>
        
        <!-- Total Revenue -->
        <div class="stat-card">
          <div class="stat-title">Total Revenue</div>
          <div class="stat-value">₱<?= number_format($totalSales['total_revenue'] ?? 0, 2) ?></div>
        </div>
      </div>
      
  <div class="card-section">
<div class="ai-recommendations-container">
  <div class="ai-header">
    <div class="ai-icon">
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" stroke="rgba(248, 120, 160, 0.9)" stroke-width="2"/>
        <path d="M12 4C16.4183 4 20 7.58172 20 12C20 16.4183 16.4183 20 12 20C7.58172 20 4 16.4183 4 12C4 7.58172 7.58172 4 12 4Z" stroke="rgba(248, 120, 160, 0.6)" stroke-width="2"/>
        <path d="M12 4V2" stroke="rgba(248, 120, 160, 0.6)" stroke-width="2" stroke-linecap="round"/>
        <path d="M4 12H2" stroke="rgba(248, 120, 160, 0.6)" stroke-width="2" stroke-linecap="round"/>
        <path d="M12 22V20" stroke="rgba(248, 120, 160, 0.6)" stroke-width="2" stroke-linecap="round"/>
        <path d="M22 12H20" stroke="rgba(248, 120, 160, 0.6)" stroke-width="2" stroke-linecap="round"/>
      </svg>
    </div>
    <div class="ai-title">Gemini Analysis</div>
  </div>
  
  <style>
    .rec-card {
      background: rgba(255, 255, 255, 0.05);
      border-radius: 8px;
      padding: 20px;
      border: 1px solid rgba(248, 120, 160, 0.2);
      transition: all 0.3s;
      height: auto;
      min-height: 180px;
      display: flex;
      flex-direction: column;
      cursor: pointer;
      position: relative;
      overflow: hidden;
    }
    
    .rec-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 25px rgba(248, 120, 160, 0.15);
      background: rgba(255, 255, 255, 0.08);
    }
    
    .rec-card.expanded {
      height: auto;
      max-height: none;
      z-index: 10;
      position: relative;
      background: rgba(255, 255, 255, 0.12);
      transform: scale(1.02);
      box-shadow: 0 10px 30px rgba(248, 120, 160, 0.2);
    }
    
    .rec-content {
      line-height: 1.6;
      color: rgba(255, 255, 255, 0.8);
      flex-grow: 1;
      position: relative;
      overflow: hidden;
      max-height: 120px;
      transition: max-height 0.3s ease;
    }
    
    .rec-card.expanded .rec-content {
      max-height: 1000px;
    }
    
    .rec-gradient {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 40px;
      background: linear-gradient(transparent, rgba(17, 17, 17, 0.9));
      pointer-events: none;
      transition: opacity 0.3s;
    }
    
    .rec-card.expanded .rec-gradient {
      opacity: 0;
    }
    
    .recommendations-cards {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 20px;
    }
  </style>
  
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const cards = document.querySelectorAll('.rec-card');
      cards.forEach(card => {
        card.addEventListener('click', function() {
          this.classList.toggle('expanded');
        });
      });
    });
  </script>
  
  <?php
  // More robust recommendation parsing
  $cleanResponse = trim($response);
  
  // Try to split by numbered patterns first (1., 2., 3.)
  if (preg_match_all('/(\d+\..*?)(?=\d+\.|$)/s', $cleanResponse, $matches)) {
    $recommendations = array_slice(array_map('trim', $matches[0]), 0, 3);
  } else {
    // Fallback to paragraph splitting
    $paragraphs = preg_split('/\n\n+/', $cleanResponse);
    $recommendations = array_slice($paragraphs, 0, 3);
    
    // If we have less than 3 items, try splitting by newlines
    if (count($recommendations) < 3) {
      $lines = explode("\n", $cleanResponse);
      $filteredLines = array_filter($lines, function($line) {
        return strlen(trim($line)) > 15; // Only consider substantial lines
      });
      
      if (count($filteredLines) >= 3) {
        $recommendations = array_slice($filteredLines, 0, 3);
      }
    }
    
    // If still less than 3, generate placeholders
    while (count($recommendations) < 3) {
      $recommendations[] = "Based on your data analysis, consider optimizing your operation.";
    }
  }
  ?>
  
  <div class="recommendations-cards">
    <?php foreach ($recommendations as $index => $rec): ?>
      <?php 
        // Better title extraction logic
        $rec = trim($rec);
        $recNumber = $index + 1;
        
        // Try to find a natural title
        if (preg_match('/^(\d+\.\s*([^:.\n]+)[:.])/', $rec, $titleMatches)) {
          $title = trim(preg_replace('/^\d+\.\s*/', '', $titleMatches[1]));
          $content = trim(substr($rec, strlen($titleMatches[0])));
        } elseif (strpos($rec, ':') !== false) {
          // Split by first colon
          list($title, $content) = explode(':', $rec, 2);
          $title = trim($title);
          $content = trim($content);
        } else {
          // Get first sentence or part
          $sentences = preg_split('/(?<=[.!?])\s+/', $rec, 2);
          if (count($sentences) > 1 && strlen($sentences[0]) < 100) {
            $title = trim($sentences[0]);
            $content = trim($sentences[1]);
          } else {
            // Just split at a reasonable point
            $title = "Recommendation " . $recNumber;
            $content = $rec;
          }
        }
        
        // Ensure reasonable lengths
        if (strlen($title) > 60) {
          $title = substr($title, 0, 57) . '...';
        }
        
        // Ensure content isn't empty
        if (empty(trim($content))) {
          $content = "Consider implementing changes based on your data analysis.";
        }
      ?>
      <div class="rec-card">
        <h3 class="rec-title"><?= htmlspecialchars($title) ?></h3>
        <div class="rec-content"><?= nl2br(htmlspecialchars($content)) ?></div>
        <div class="rec-gradient"></div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
  
  <form method="post">
    <button type="submit" name="generate_pdf" class="btn">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 8px; vertical-align: middle;">
        <path d="M14 3V7C14 7.26522 14.1054 7.51957 14.2929 7.70711C14.4804 7.89464 14.7348 8 15 8H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M17 21H7C6.46957 21 5.96086 20.7893 5.58579 20.4142C5.21071 20.0391 5 19.5304 5 19V5C5 4.46957 5.21071 3.96086 5.58579 3.58579C5.96086 3.21071 6.46957 3 7 3H14L19 8V19C19 19.5304 18.7893 20.0391 18.4142 20.4142C18.0391 20.7893 17.5304 21 17 21Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M9 15H15" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M12 12V18" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      Download PDF Report
    </button>
  </form>
</div>
    </div>
  </div>
</body>
</html>