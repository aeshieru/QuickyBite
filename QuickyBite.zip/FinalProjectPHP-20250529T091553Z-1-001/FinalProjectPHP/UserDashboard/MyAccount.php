<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../logins.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "adris_ordertaking";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];

// Fetch user data
$sql = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Prepare failed (fetch user): (" . $conn->errno . ") " . $conn->error);
}
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc() ?: die("User not found.");
$stmt->close();

// Profile picture upload
if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
    $allowed = ['jpg', 'jpeg', 'png', 'gif'];
    $filename = $_FILES['profile_picture']['name'];
    $filetype = pathinfo($filename, PATHINFO_EXTENSION);

    if (in_array(strtolower($filetype), $allowed)) {
        $image_data = file_get_contents($_FILES['profile_picture']['tmp_name']);
        $update_sql = "UPDATE users SET profile_picture = ? WHERE user_id = ?";
        $update_stmt = $conn->prepare($update_sql);
        if (!$update_stmt) {
            die("Prepare failed (profile picture blob): (" . $conn->errno . ") " . $conn->error);
        }
        $null = NULL;
        $update_stmt->bind_param("bi", $null, $user_id);
        $update_stmt->send_long_data(0, $image_data);
        $update_stmt->execute();
        $update_stmt->close();

        // Reload updated image
        $stmt = $conn->prepare("SELECT profile_picture FROM users WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user['profile_picture'] = $result->fetch_assoc()['profile_picture'];
        $stmt->close();
    }
}

// Password change
$password_message = "";
if (isset($_POST['change_password'])) {
    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    $stmt = $conn->prepare("SELECT password FROM users WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($current_hash);
    $stmt->fetch();
    $stmt->close();

    if (password_verify($old_password, $current_hash) || $old_password === $user['password']) {
        if ($new_password === $confirm_password) {
            $new_hash = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET password = ? WHERE user_id = ?");
            $stmt->bind_param("si", $new_hash, $user_id);
            $stmt->execute();
            $password_message = "Password updated successfully.";
        } else {
            $password_message = "New passwords do not match.";
        }
    } else {
        $password_message = "Old password is incorrect.";
    }
}

// Email update
$email_message = "";
if (isset($_POST['update_email'])) {
    $new_email = trim($_POST['new_email']);
    if (!empty($new_email) && filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
        $stmt = $conn->prepare("UPDATE users SET email = ? WHERE user_id = ?");
        if ($stmt) {
            $stmt->bind_param("si", $new_email, $user_id);
            $stmt->execute();
            $stmt->close();
            $user['email'] = $new_email; // Update local data
            $email_message = "Email updated successfully!";
        } else {
            $email_message = "Error updating email: " . $conn->error;
        }
    } else {
        $email_message = "Invalid email address.";
    }
}

// Order history
$orders = [];
$sql = "SELECT o.OrderID, o.OrderDate, o.Status,
               oi.FoodName, oi.Quantity, oi.Price
        FROM orders o
        JOIN order_items oi ON o.OrderID = oi.OrderID
        WHERE o.user_id = ?
        ORDER BY o.OrderDate DESC";

$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $orders[$row['OrderID']][] = $row;
    }
    $stmt->close();
} else {
    die("Error fetching orders: " . $conn->error);
}

// Convert profile picture to base64
$profilePictureData = '';
if (!empty($user['profile_picture'])) {
    $base64 = base64_encode($user['profile_picture']);
    $profilePictureData = 'data:image/jpeg;base64,' . $base64;
} else {
    // Use default avatar image
    $profilePictureData = 'uimages/default-avatar.png';
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>My Account - QuickyBite</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="ustyles/user_dashboard.css">
    <style>
    :root {
        --primary-color: #f1d6d6;
        --secondary-color: #2a2a2a;
        --text-color: #ffffff;
        --accent-color: palevioletred;
        --card-bg: #1e1e1e;
        --hover-color: #333333;
        --bg-lighter: #222;
        --primary-dark: #9e2a2a;
        --border-radius: 8px;
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    body {
        background-color: #121212;
        color: var(--text-color);
        display: flex;
        min-height: 100vh;
        overflow-x: hidden;
        background: linear-gradient(135deg, #121212 0%, #1d1d1d 100%);
    }

    /* Side Navigation */
    .side-nav {
        width: 80px;
        background-color: var(--card-bg);
        min-height: 100vh;
        padding: 20px 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        box-shadow: 2px 0 10px rgba(0, 0, 0, 0.2);
        position: fixed;
        transition: width 0.3s ease;
        overflow: hidden;
        z-index: 100;
    }

    .side-nav:hover {
        width: 200px;
    }

    .logo-box {
        width: 50px;
        height: 50px;
        background-color: var(--primary-color);
        border-radius: 12px;
        display: flex;
        justify-content: center;
        align-items: center;
        font-size: 20px;
        font-weight: bold;
        color: var(--card-bg);
        margin-bottom: 40px;
        box-shadow: 0 0 15px rgba(241, 214, 214, 0.3);
    }

    .nav-icon {
        display: flex;
        align-items: center;
        padding: 12px 20px;
        width: 100%;
        color: var(--text-color);
        text-decoration: none;
        margin-bottom: 10px;
        border-radius: 0 20px 20px 0;
        transition: all 0.3s ease;
    }

    .nav-icon img {
        width: 24px;
        height: 24px;
        margin-right: 15px;
        transition: all 0.3s ease;
        filter: invert(1);
        opacity: 0.7;
    }

    .nav-icon-text {
        white-space: nowrap;
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .side-nav:hover .nav-icon-text {
        opacity: 1;
    }

    .nav-icon:hover {
        background-color: var(--hover-color);
    }

    .nav-icon:hover img {
        transform: scale(1.1);
        opacity: 1;
    }

    .nav-icon.active {
        background-color: var(--primary-color);
        color: #333;
    }

    .nav-icon.active img {
        filter: brightness(0.3);
        opacity: 1;
    }

    /* Main Content */
    .main-content {
        flex: 1;
        padding: 30px;
        padding-left: 110px;
        width: 100%;
        max-width: 1300px;
        margin: 0 auto;
    }

    h1 {
        font-size: 2.2rem;
        font-weight: 700;
        margin-bottom: 30px;
        background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
        -webkit-background-clip: text;
        background-clip: text;
        color: transparent;
        text-shadow: 0 0 10px rgba(241, 214, 214, 0.2);
        text-align: center;
    }

    .welcome-header {
        background-color: var(--bg-lighter);
        padding: 25px;
        border-radius: var(--border-radius);
        margin-bottom: 25px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .welcome-header h1 {
        color: var(--primary-color);
        font-size: 24px;
    }

    .order-now-btn {
        background-color: var(--primary-color);
        color: #000;
        border: none;
        padding: 10px 15px;
        border-radius: var(--border-radius);
        cursor: pointer;
        font-weight: bold;
        text-decoration: none;
        display: inline-block;
    }

    .order-now-btn:hover {
        background-color: var(--primary-dark);
    }

    .card {
        background-color: var(--card-bg);
        border-radius: 15px;
        padding: 20px;
        margin-bottom: 20px; /* Adjusted for consistent spacing */
        border: 1px solid rgba(255, 255, 255, 0.05);
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        animation: fadeIn 0.6s ease forwards;
    }

    .card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px; /* Adjusted for uniform spacing */
    }

    .card-header h2 {
        font-size: 20px;
    }

    .edit-btn {
        background: none;
        border: none;
        color: var(--primary-color);
        cursor: pointer;
    }

    /* Order History */
    .order-card {
        background-color: #333;
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 20px; /* Consistent spacing between cards */
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    }

    .order-header {
        display: flex;
        justify-content: space-between;
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid #444;
    }

    .order-items {
        width: 100%;
        border-collapse: collapse;
    }

    .order-items th, .order-items td {
        padding: 12px 20px;
        text-align: left;
    }

    .order-items th {
        color: #999;
        font-size: 14px; /* Consistent font size */
    }

    .order-items td {
        color: #fff;
    }

    .order-items tr {
        border-bottom: 1px solid #444; /* Consistent row separation */
    }

    .order-items tr:last-child {
        border-bottom: none;
    }

    .order-status {
        padding: 3px 8px;
        border-radius: 20px;
        font-size: 12px;
    }

    .status-completed {
        background-color: rgba(40, 167, 69, 0.2);
        color: #28a745;
    }

    .status-pending {
        background-color: rgba(255, 193, 7, 0.2);
        color: #ffc107;
    }

    .status-cancelled {
        background-color: rgba(220, 53, 69, 0.2);
        color: #dc3545;
    }

    /* Highlight only the total row */
    .order-items .total-row {
        font-weight: bold;
        background-color: #444;
        color: var(--primary-color); /* Highlight with primary color */
    }

    .order-items .total-row td {
        font-size: 16px;
        padding: 15px 20px;
    }

    /* Forms */
    .form-group {
        margin-bottom: 15px;
    }

    .form-group label {
        display: block;
        margin-bottom: 5px;
        color: #999;
    }

    .form-control {
        width: 100%;
        padding: 10px;
        background-color: #333;
        border: 1px solid #444;
        border-radius: 8px;
        color: var(--text-color);
    }

    .btn {
        padding: 10px 15px;
        border-radius: 8px;
        border: none;
        cursor: pointer;
        font-weight: bold;
    }

    .btn-primary {
        background-color: var(--primary-color);
        color: #000;
    }

    .btn-primary:hover {
        background-color: var(--primary-dark);
    }

    .alert {
        padding: 10px;
        border-radius: 8px;
        margin-bottom: 15px;
    }

    .alert-success {
        background-color: rgba(40, 167, 69, 0.2);
        border: 1px solid #28a745;
        color: #28a745;
    }

    .alert-danger {
        background-color: rgba(220, 53, 69, 0.2);
        border: 1px solid #dc3545;
        color: #dc3545;
    }

    /* Toast Notifications */
    .toast {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background-color: #333;
        color: white;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        display: flex;
        align-items: center;
        gap: 10px;
        z-index: 1000;
    }

    .toast .close-btn {
        background: none;
        border: none;
        color: white;
        cursor: pointer;
        margin-left: 10px;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    /* Responsive */
    @media (max-width: 768px) {
        .actions-grid {
            grid-template-columns: repeat(2, 1fr);
        }

        .profile-content {
            flex-direction: column;
        }

        .main-content {
            padding-left: 100px;
            padding: 20px;
        }
    }

    @media (max-width: 600px) {
        .side-nav {
            width: 60px;
        }

        .side-nav:hover {
            width: 180px;
        }

        .main-content {
            padding-left: 70px;
        }
    }

    </style>
</head>
<body>
    <!-- Side Navigation (Updated to match ViewCart.php) -->
    <nav class="side-nav">
        <div class="logo-box">QB</div>
        <a href="user_dashboard.php" class="nav-icon">
            <img src="uimages/house-blank.png" alt="Dashboard">
            <span class="nav-icon-text">Dashboard</span>
        </a>
        <a href="DisplayMenu.php" class="nav-icon">
            <img src="uimages/task-checklist.png" alt="Menu">
            <span class="nav-icon-text">Menu</span>
        </a>
        <a href="ViewCart.php" class="nav-icon">
            <img src="uimages/shopping-cart.png" alt="Cart">
            <span class="nav-icon-text">Cart</span>
        </a>
        <a href="SeatAvailability.php" class="nav-icon">
            <img src="uimages/chair.png" alt="Seat Availability">
            <span class="nav-icon-text">Seat Availability</span>
        </a>
        <a href="MyAccount.php" class="nav-icon active">
            <img src="uimages/user.png" alt="My Account">
            <span class="nav-icon-text">My Account</span>
        </a>
        <a href="../Login/logout.php" class="nav-icon">
            <img src="uimages/exit.png" alt="Logout">
            <span class="nav-icon-text">Log Out</span>
        </a>
    </nav>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Welcome Header -->
        <div class="welcome-header">
            <div>
                <h1>Welcome, <?= htmlspecialchars($user['username']) ?>!</h1>
                <p>What would you like to order today?</p>
            </div>
            <a href="DisplayMenu.php" class="order-now-btn">Order Now</a>
        </div>

        <!-- Profile Section -->
        <div class="card">
            <div class="card-header">
                <h2>My Profile</h2>
                <button class="edit-btn">
                    <i class="fas fa-pen"></i>
                </button>
            </div>
            <div class="profile-content">
                <div class="profile-pic">
                    <img src="<?php echo htmlspecialchars($profilePictureData); ?>" alt="Profile Picture">
                </div>
                <div class="profile-details">
                    <div class="profile-item">
                        <span>Name:</span>
                        <span><?= htmlspecialchars($user['full_name'] ?? $user['username']) ?></span>
                    </div>
                    <div class="profile-item">
                        <span>Username:</span>
                        <span><?= htmlspecialchars($user['username']) ?></span>
                    </div>
                    <div class="profile-item">
                        <span>Email:</span>
                        <span><?= htmlspecialchars($user['email']) ?></span>
                    </div>
                    <div class="profile-item">
                        <span>Member since:</span>
                        <span><?= date('F Y', strtotime($user['created_at'] ?? 'now')) ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="card">
            <div class="card-header">
                <h2>Quick Actions</h2>
            </div>
            <div class="actions-grid">
                <a href="DisplayMenu.php" class="action-item">
                    <i class="fas fa-utensils"></i>
                    <span>Browse Menu</span>
                </a>
                <a href="ViewCart.php" class="action-item">
                    <i class="fas fa-shopping-cart"></i>
                    <span>View Cart</span>
                </a>
                <a href="#order-history" class="action-item">
                    <i class="fas fa-history"></i>
                    <span>Order History</span>
                </a>
                <a href="SeatAvailability.php" class="action-item">
                    <i class="fas fa-chair"></i>
                    <span>Reserve Seat</span>
                </a>
            </div>
        </div>

        <!-- Profile Picture Upload -->
        <div class="card">
            <div class="card-header">
                <h2>Profile Picture</h2>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Upload new profile picture:</label>
                    <input type="file" name="profile_picture" accept="image/*" required class="form-control">
                </div>
                <button type="submit" class="btn btn-primary">Upload</button>
            </form>
        </div>

        <!-- Change Password -->
        <div class="card">
            <div class="card-header">
                <h2>Change Password</h2>
            </div>
            <?php if (!empty($password_message)): ?>
                <div class="alert <?= strpos($password_message, 'successfully') !== false ? 'alert-success' : 'alert-danger' ?>">
                    <?= htmlspecialchars($password_message) ?>
                </div>
            <?php endif; ?>
            <form method="POST">
                <div class="form-group">
                    <label>Old Password:</label>
                    <input type="password" name="old_password" required class="form-control">
                </div>
                <div class="form-group">
                    <label>New Password:</label>
                    <input type="password" name="new_password" required class="form-control">
                </div>
                <div class="form-group">
                    <label>Confirm New Password:</label>
                    <input type="password" name="confirm_password" required class="form-control">
                </div>
                <button type="submit" name="change_password" class="btn btn-primary">Change Password</button>
            </form>
        </div>

        <!-- Update Email -->
        <div class="card">
            <div class="card-header">
                <h2>Update Email</h2>
            </div>
            <?php if (!empty($email_message)): ?>
                <div class="alert <?= strpos($email_message, 'successfully') !== false ? 'alert-success' : 'alert-danger' ?>">
                    <?= htmlspecialchars($email_message) ?>
                </div>
            <?php endif; ?>
            <form method="POST">
                <div class="form-group">
                    <label>Email Address:</label>
                    <input type="email" name="new_email" value="<?= htmlspecialchars($user['email']) ?>" required class="form-control">
                </div>
                <button type="submit" name="update_email" class="btn btn-primary">Update Email</button>
            </form>
        </div>

        <!-- Order History -->
        <div class="card" id="order-history">
            <div class="card-header">
                <h2>Order History</h2>
            </div>
            <?php if (empty($orders)): ?>
                <p>No orders found.</p>
            <?php else: ?>
                <?php foreach ($orders as $order_id => $items): ?>
                    <div class="order-card">
                        <div class="order-header">
                            <div>
                                <strong>Order ID: #<?= $order_id ?></strong>
                                <div><?= date('M d, Y h:i A', strtotime($items[0]['OrderDate'])) ?></div>
                            </div>
                            <div>
                                <span class="order-status <?= 'status-' . strtolower($items[0]['Status']) ?>">
                                    <?= htmlspecialchars($items[0]['Status']) ?>
                                </span>
                            </div>
                        </div>
                        <table class="order-items">
                            <thead>
                                <tr>
                                    <th>Food</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $total = 0;
                                foreach ($items as $item): 
                                    $total += $item['Price'] * $item['Quantity'];
                                ?>
                                    <tr>
                                        <td><?= htmlspecialchars($item['FoodName']) ?></td>
                                        <td><?= $item['Quantity'] ?></td>
                                        <td>₱<?= number_format($item['Price'], 2) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                <tr>
                                    <td colspan="2" style="text-align: right;"><strong>Total:</strong></td>
                                    <td><strong>₱<?= number_format($total, 2) ?></strong></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Toast Notification -->
    <div class="toast" id="welcome-toast" style="display: none;">
        <i class="fas fa-circle-info"></i>
        <span>Profile updated successfully!</span>
        <button class="close-btn" onclick="document.getElementById('welcome-toast').style.display='none';">
            <i class="fas fa-times"></i>
        </button>
    </div>

    <script>
        // Show success notification when profile is updated
        <?php if (!empty($password_message) && strpos($password_message, 'successfully') !== false): ?>
        document.addEventListener('DOMContentLoaded', function() {
            const toast = document.getElementById('welcome-toast');
            toast.style.display = 'flex';
            setTimeout(() => {
                toast.style.display = 'none';
            }, 5000);
        });
        <?php endif; ?>
        
        <?php if (!empty($email_message) && strpos($email_message, 'successfully') !== false): ?>
        document.addEventListener('DOMContentLoaded', function() {
            const toast = document.getElementById('welcome-toast');
            toast.querySelector('span').textContent = 'Email updated successfully!';
            toast.style.display = 'flex';
            setTimeout(() => {
                toast.style.display = 'none';
            }, 5000);
        });
        <?php endif; ?>
    </script>
</body>
</html>