<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "adris_ordertaking";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";
$messageType = "";
$verificationSuccess = false;
$userName = "";

if (isset($_GET['token']) && !empty($_GET['token'])) {
    $token = $_GET['token'];

    // First check if the token exists
    $stmt = $conn->prepare("SELECT user_id, username, email, full_name FROM users WHERE account_activation_hash = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $userName = $user['full_name'];

        // Update user to active and clear the hash
        $updateStmt = $conn->prepare("
            UPDATE users 
            SET is_active = 1, account_activation_hash = NULL 
            WHERE user_id = ?
        ");
        $updateStmt->bind_param("i", $user['user_id']);

        if ($updateStmt->execute()) {
            $message = "Your email has been verified successfully. You can now login to your account.";
            $messageType = "success";
            $verificationSuccess = true;
        } else {
            $message = "Error verifying your account. Please try again later.";
            $messageType = "error";
        }

        $updateStmt->close();
    } else {
        $message = "Invalid or expired verification link.";
        $messageType = "error";
    }

    $stmt->close();
} else {
    $message = "Verification token is missing.";
    $messageType = "error";
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Email Verification - QuickyBite</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f7f9fc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }

        .verification-container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 3px 20px rgba(0, 0, 0, 0.1);
            padding: 40px;
            max-width: 500px;
            width: 100%;
            text-align: center;
        }

        .logo {
            margin-bottom: 30px;
        }

        .logo h2 {
            color: #ff6b6b;
        }

        h1 {
            margin-bottom: 20px;
            color: #333;
        }

        .message {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 25px;
            font-size: 16px;
        }

        .message.success {
            background-color: #e6f7ef;
            border-left: 4px solid #28a745;
            color: #1e7e34;
        }

        .message.error {
            background-color: #f8d7da;
            border-left: 4px solid #dc3545;
            color: #721c24;
        }

        .verification-success i,
        .verification-error i {
            font-size: 70px;
            margin-bottom: 20px;
        }

        .verification-success i {
            color: #28a745;
        }

        .verification-error i {
            color: #dc3545;
        }

        .user-name {
            font-weight: bold;
            color: #333;
        }

        .btn {
            display: inline-block;
            background-color: #ff6b6b;
            color: white;
            padding: 12px 25px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            border: none;
            cursor: pointer;
            margin-top: 20px;
        }

        .btn:hover {
            background-color: #ff5252;
        }

        .countdown {
            margin-top: 15px;
            font-weight: bold;
            color: #1877f2;
        }
    </style>
    <?php if ($verificationSuccess): ?>
    <script>
        // Start redirect countdown only on successful verification
        let seconds = 3;
        window.onload = function() {
            const countdownEl = document.getElementById("countdown");
            const interval = setInterval(() => {
                seconds--;
                countdownEl.textContent = seconds;
                if (seconds <= 0) {
                    clearInterval(interval);
                    window.location.href = "http://localhost:3000/logins.php";
                }
            }, 1000);
        }
    </script>
    <?php endif; ?>
</head>
<body>
    <div class="verification-container">
        <div class="logo">
            <h2><i class="fas fa-utensils"></i> QuickyBite</h2>
        </div>

        <?php if ($verificationSuccess): ?>
            <div class="verification-success">
                <i class="fas fa-check-circle"></i>
                <h1>Email Verification Successful!</h1>
                <p>Thank you, <span class="user-name"><?php echo htmlspecialchars($userName); ?></span>. Your email has been verified successfully.</p>
                <p>You will be redirected to the login page in <span class="countdown" id="countdown">5</span> seconds.</p>
            </div>
        <?php else: ?>
            <div class="verification-error">
                <i class="fas fa-times-circle"></i>
                <h1>Verification Failed</h1>
                <p><?php echo $message; ?></p>
                <p>If the problem persists, please contact our support team.</p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
