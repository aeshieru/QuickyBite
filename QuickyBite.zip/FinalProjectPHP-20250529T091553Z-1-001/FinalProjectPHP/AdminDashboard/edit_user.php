<?php
session_start();
$host = "localhost";
$username = "root";
$password = "";
$database = "adris_ordertaking";

// Connect to database
$conn = mysqli_connect($host, $username, $password, $database);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

function sanitize($conn, $data) {
    return mysqli_real_escape_string($conn, trim($data));
}

// Check if user ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid user ID.");
}

$user_id = intval($_GET['id']);
$error = "";
$success = "";

// Fetch user data for the form
$sql = "SELECT username, email, phone_number, full_name, user_type FROM users WHERE user_id = $user_id LIMIT 1";
$result = mysqli_query($conn, $sql);

if (!$result || mysqli_num_rows($result) == 0) {
    die("User not found.");
}

$user = mysqli_fetch_assoc($result);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($conn, $_POST['username']);
    $email = sanitize($conn, $_POST['email']);
    $phone_number = sanitize($conn, $_POST['phone_number']);
    $full_name = sanitize($conn, $_POST['full_name']);
    $user_type = sanitize($conn, $_POST['user_type']);

    // Basic validation (you can extend this)
    if (empty($username) || empty($email) || empty($full_name) || empty($user_type)) {
        $error = "Please fill in all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {
        // Update user info
        $updateSql = "
            UPDATE users SET
            username = '$username',
            email = '$email',
            phone_number = '$phone_number',
            full_name = '$full_name',
            user_type = '$user_type'
            WHERE user_id = $user_id
        ";
        if (mysqli_query($conn, $updateSql)) {
            $success = "User updated successfully.";
            // Refresh user data
            $user = [
                'username' => $username,
                'email' => $email,
                'phone_number' => $phone_number,
                'full_name' => $full_name,
                'user_type' => $user_type,
            ];
        } else {
            $error = "Error updating user: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Edit User</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" />
<style>
    body {
        background-color: #000;
        color: #fff;
        font-family: Arial, sans-serif;
        padding: 20px;
    }
    .form-control, .form-select {
        background-color: rgba(255,255,255,0.1);
        border: 1px solid rgba(255,255,255,0.2);
        color: #fff;
    }
    .form-control:focus, .form-select:focus {
        border-color: #f878a0;
        box-shadow: 0 0 10px #f878a0;
        background-color: rgba(255,255,255,0.15);
        color: #fff;
    }
    label {
        font-weight: bold;
    }
    .btn-primary {
        background-color: #f878a0;
        border-color: #f878a0;
    }
    .btn-primary:hover {
        background-color: #f84c7f;
        border-color: #f84c7f;
    }
</style>
</head>
<body>

<div class="container">
    <h2>Edit User</h2>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>

    <form method="post" action="">
        <div class="mb-3">
            <label for="username" class="form-label">Username *</label>
            <input type="text" name="username" id="username" class="form-control" required
                   value="<?php echo htmlspecialchars($user['username']); ?>" />
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email *</label>
            <input type="email" name="email" id="email" class="form-control" required
                   value="<?php echo htmlspecialchars($user['email']); ?>" />
        </div>
        <div class="mb-3">
            <label for="phone_number" class="form-label">Phone Number</label>
            <input type="text" name="phone_number" id="phone_number" class="form-control"
                   value="<?php echo htmlspecialchars($user['phone_number']); ?>" />
        </div>
        <div class="mb-3">
            <label for="full_name" class="form-label">Full Name *</label>
            <input type="text" name="full_name" id="full_name" class="form-control" required
                   value="<?php echo htmlspecialchars($user['full_name']); ?>" />
        </div>
        <div class="mb-3">
            <label for="user_type" class="form-label">User Type *</label>
            <select name="user_type" id="user_type" class="form-select" required>
                <option value="">-- Select User Type --</option>
                <?php 
                // Optional: Adjust user types as per your app
                $types = ['admin', 'customer', 'staff'];
                foreach ($types as $type): ?>
                    <option value="<?php echo $type; ?>" <?php echo ($user['user_type'] === $type) ? 'selected' : ''; ?>>
                        <?php echo ucfirst($type); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Update User</button>
        <a href="get-user-orders.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

</body>
</html>
