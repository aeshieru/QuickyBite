<?php
// forgot-password.php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

// Database configuration
$host = "localhost";
$username = "root";
$password = "";
$database = "adris_ordertaking";

// Initialize variables
$message = "";
$messageType = "";
$emailExists = false;

// CSRF token for security
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

try {
    $conn = new mysqli($host, $username, $password, $database);
    
    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Database connection failed: " . $conn->connect_error);
    }
    
    // Set charset to prevent encoding issues
    $conn->set_charset("utf8mb4");

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Verify CSRF token
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            throw new Exception("Invalid security token. Please refresh the page and try again.");
        }

        // Validate and sanitize input
        $email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);

        if (!$email) {
            throw new Exception("Please enter a valid email address.");
        }

        // Check if user exists and account is active
        $stmt = $conn->prepare("SELECT user_id, username, full_name, email FROM users WHERE email = ? AND is_active = 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $emailExists = true;
            $user = $result->fetch_assoc();
            $user_id = $user['user_id'];
            $username = $user['username'];
            $fullName = $user['full_name'];
            $userEmail = $user['email'];

            // Generate secure reset token
            $resetToken = bin2hex(random_bytes(32)); // Using 32 bytes for token length (64 chars in hex)
            $expires = date("Y-m-d H:i:s", strtotime('+1 hour'));

            // Delete any existing reset tokens for this user
            $deleteStmt = $conn->prepare("DELETE FROM password_reset WHERE user_id = ?");
            $deleteStmt->bind_param("i", $user_id);
            $deleteStmt->execute();
            $deleteStmt->close();

            // Insert new reset token
            $insertStmt = $conn->prepare("INSERT INTO password_reset (user_id, token, expires, created_at) VALUES (?, ?, ?, NOW())");
            $insertStmt->bind_param("iss", $user_id, $resetToken, $expires);
            
            if ($insertStmt->execute()) {
                // Send reset email using PHPMailer
                $mail = new PHPMailer(true);
                
                try {
                    // Enable detailed debugging
                    // $mail->SMTPDebug = SMTP::DEBUG_SERVER; // Uncomment for debugging SMTP issues
                    $mail->CharSet = 'UTF-8';
                    $mail->Encoding = 'base64';

                    // Gmail SMTP configuration
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'adrisquickybite@gmail.com'; // Your Gmail address
                    $mail->Password = 'dxvz rvwx hzvz frfn'; // Your Gmail app password
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
                    $mail->Port = 465;

                    // Prevent certificate verification issues
                    $mail->SMTPOptions = [
                        'ssl' => [
                            'verify_peer' => false,
                            'verify_peer_name' => false,
                            'allow_self_signed' => true
                        ]
                    ];

                    // Email settings
                    $mail->setFrom('adrisquickybite@gmail.com', 'QuickyBite');
                    $mail->addReplyTo('adrisquickybite@gmail.com', 'QuickyBite');
                    $mail->addAddress($userEmail, $fullName);
                    $mail->isHTML(true);
                    $mail->Subject = 'Reset Your QuickyBite Password';

                    // Reset password URL - Make sure this path is correct for your server setup
                    $resetUrl = "http://localhost:3000/Login/resetpassword.php?token=" . urlencode($resetToken);

                    // Email body
                    $mail->Body = "
                    <html>
                    <head>
                        <style>
                            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                            .header { background-color: #007cba; color: white; padding: 20px; text-align: center; }
                            .content { padding: 20px; background-color: #f9f9f9; }
                            .button { 
                                display: inline-block; 
                                background-color: #007cba; 
                                color: white; 
                                padding: 12px 24px; 
                                text-decoration: none; 
                                border-radius: 5px; 
                                margin: 20px 0;
                            }
                            .footer { background-color: #333; color: white; padding: 10px; text-align: center; font-size: 12px; }
                        </style>
                    </head>
                    <body>
                        <div class='container'>
                            <div class='header'>
                                <h1>QuickyBite</h1>
                                <h2>Password Reset Request</h2>
                            </div>
                            <div class='content'>
                                <p>Hello <strong>$fullName</strong>,</p>
                                <p>We received a request to reset your password for your QuickyBite account.</p>
                                <p>Click the button below to reset your password:</p>
                                <p style='text-align: center;'>
                                    <a href='$resetUrl' class='button'>Reset My Password</a>
                                </p>
                                <p>Or copy and paste this link into your browser:</p>
                                <p style='word-break: break-all; background-color: #e9e9e9; padding: 10px; border-radius: 3px;'>
                                    $resetUrl
                                </p>
                                <p><strong>Important:</strong> This link will expire in 1 hour for security reasons.</p>
                                <p>If you did not request this password reset, please ignore this email and your password will remain unchanged.</p>
                                <p>For security reasons, please do not share this link with anyone.</p>
                            </div>
                            <div class='footer'>
                                <p>© " . date('Y') . " QuickyBite. All rights reserved.</p>
                                <p>This is an automated message, please do not reply to this email.</p>
                            </div>
                        </div>
                    </body>
                    </html>
                    ";

                    // Plain text version for clients that don't support HTML
                    $mail->AltBody = "Hello $fullName,\n\nWe received a request to reset your password for your QuickyBite account.\n\nTo reset your password, click here: $resetUrl\n\nOr copy and paste this link into your browser:\n$resetUrl\n\nImportant: This link will expire in 1 hour for security reasons.\n\nIf you did not request this password reset, please ignore this email and your password will remain unchanged.\n\nFor security reasons, please do not share this link with anyone.\n\n© " . date('Y') . " QuickyBite. All rights reserved.";

                    $mail->send();
                    $message = "A password reset link has been sent to your email address. Please check your inbox and follow the instructions to reset your password.";
                    $messageType = "success";
                    
                    // Log successful reset request
                    error_log("Password reset email sent successfully to: $userEmail");
                    
                } catch (Exception $e) {
                    throw new Exception("Failed to send reset email. Please try again later. Error: {$mail->ErrorInfo}");
                }
            } else {
                throw new Exception("Failed to generate reset token. Please try again.");
            }
            
            $insertStmt->close();
        } else {
            // The email doesn't exist in the database or account is not active
            $message = "This email address is not registered or the account is not active. Please check your email address or sign up for a new account.";
            $messageType = "error";
        }

        $stmt->close();
    }

} catch (Exception $e) {
    $message = $e->getMessage();
    $messageType = "error";
    
    // Log error for debugging
    error_log("Password reset error: " . $e->getMessage());
}

if (isset($conn)) {
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Forgot Password - QuickyBite</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <style>
        :root {
            --primary-color: #f1d6d6;
            --secondary-color: #1e1e1e;
            --text-color: #fff;
            --error-color: #e74c3c;
            --success-color: #2ecc71;
            --accent-color: palevioletred;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #121212;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
            overflow-x: hidden;
            background: linear-gradient(135deg, #121212 0%, #1d1d1d 100%);
            position: relative;
        }

        /* Animated background elements */
        .bg-animation {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: -1;
            overflow: hidden;
        }

        .bg-bubble {
            position: absolute;
            border-radius: 50%;
            background: radial-gradient(circle at 30% 30%, rgba(241, 214, 214, 0.2), transparent);
            box-shadow: 0 0 10px rgba(241, 214, 214, 0.1);
            animation: float 15s infinite ease-in-out;
            opacity: 0.1;
        }

        .bg-bubble:nth-child(1) {
            width: 200px;
            height: 200px;
            left: 10%;
            top: 10%;
            animation-delay: 0s;
        }

        .bg-bubble:nth-child(2) {
            width: 150px;
            height: 150px;
            right: 15%;
            top: 20%;
            animation-delay: 2s;
        }

        .bg-bubble:nth-child(3) {
            width: 180px;
            height: 180px;
            left: 20%;
            bottom: 15%;
            animation-delay: 4s;
        }

        .bg-bubble:nth-child(4) {
            width: 120px;
            height: 120px;
            right: 20%;
            bottom: 25%;
            animation-delay: 6s;
        }

        @keyframes float {
            0% {
                transform: translateY(0) rotate(0deg);
            }
            50% {
                transform: translateY(-20px) rotate(5deg);
            }
            100% {
                transform: translateY(0) rotate(0deg);
            }
        }

        .container {
            background-color: #1e1e1e;
            border-radius: 10px;
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.3), 
                        0 0 15px rgba(241, 214, 214, 0.1);
            width: 100%;
            max-width: 450px;
            padding: 30px;
            position: relative;
            overflow: hidden;
            animation: containerAppear 0.8s ease-out forwards;
            transform: translateY(30px);
            opacity: 0;
        }

        @keyframes containerAppear {
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        /* Glowing border effect */
        .container::before {
            content: '';
            position: absolute;
            top: -2px;
            left: -2px;
            right: -2px;
            bottom: -2px;
            background: linear-gradient(45deg, transparent, transparent, var(--primary-color), transparent, transparent);
            z-index: -1;
            border-radius: 12px;
            opacity: 0;
            animation: glowingBorder 6s linear infinite;
        }

        @keyframes glowingBorder {
            0% {
                opacity: 0;
            }
            50% {
                opacity: 0.3;
            }
            100% {
                opacity: 0;
            }
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .logo {
            color: var(--primary-color);
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 15px;
            animation: fadeIn 0.6s ease forwards;
            opacity: 0;
            animation-delay: 0.2s;
        }

        h2 {
            color: #fff;
            font-size: 24px;
            margin-bottom: 10px;
            position: relative;
            letter-spacing: 1px;
            animation: fadeIn 0.6s ease forwards, textGlow 4s ease-in-out infinite;
            animation-delay: 0.4s;
            opacity: 0;
        }

        h2::after {
            content: '';
            display: block;
            width: 60px;
            height: 3px;
            background: linear-gradient(90deg, transparent, var(--primary-color), transparent);
            margin: 10px auto 0;
            animation: expandLine 1.2s ease-out forwards;
            transform: scaleX(0);
        }

        @keyframes expandLine {
            0% {
                transform: scaleX(0);
            }
            100% {
                transform: scaleX(1);
            }
        }

        @keyframes textGlow {
            0%, 100% {
                text-shadow: 0 0 5px rgba(241, 214, 214, 0.3);
            }
            50% {
                text-shadow: 0 0 15px rgba(241, 214, 214, 0.6), 0 0 20px rgba(241, 214, 214, 0.3);
            }
        }

        .subtitle {
            color: #aaa;
            font-size: 14px;
            line-height: 1.5;
            animation: fadeIn 0.6s ease forwards;
            animation-delay: 0.6s;
            opacity: 0;
        }

        .form-group {
            margin-bottom: 25px;
            opacity: 0;
            transform: translateX(-10px);
            animation: slideRight 0.5s ease forwards;
            animation-delay: 0.7s;
        }

        @keyframes slideRight {
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #ccc;
            font-weight: 600;
            font-size: 14px;
            transition: color 0.3s ease;
        }

        input[type="email"] {
            width: 100%;
            padding: 12px 16px;
            border: none;
            background-color: #2a2a2a;
            border-radius: 8px;
            color: #fff;
            font-size: 16px;
            transition: all 0.3s ease;
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.2);
        }

        input[type="email"]:focus {
            outline: none;
            box-shadow: 0 0 0 2px var(--primary-color), 0 0 10px rgba(241, 214, 214, 0.4);
            background-color: #333;
            transform: translateY(-2px);
        }

        .submit-btn {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            width: 100%;
            padding: 14px 20px;
            background-color: var(--primary-color);
            color: #1e1e1e;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
            opacity: 0;
            animation: fadeIn 0.8s ease forwards;
            animation-delay: 0.9s;
            box-shadow: 0 4px 12px rgba(241, 214, 214, 0.3);
        }

        .submit-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: 0.5s;
        }

        .submit-btn:hover {
            background-color: var(--accent-color);
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(219, 112, 147, 0.4);
        }

        .submit-btn:hover::before {
            left: 100%;
        }

        .submit-btn:active {
            transform: translateY(-1px);
            box-shadow: 0 3px 8px rgba(219, 112, 147, 0.3);
        }

        .submit-btn:disabled {
            background: #555;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        .message {
            padding: 15px;
            margin: 25px 0;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideDown 0.5s ease forwards;
            transform: translateY(-20px);
            opacity: 0;
        }

        @keyframes slideDown {
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .message.success {
            background-color: rgba(46, 204, 113, 0.2);
            border-left: 4px solid var(--success-color);
            color: #2ecc71;
            box-shadow: 0 0 10px rgba(46, 204, 113, 0.1);
        }

        .message.error {
            background-color: rgba(231, 76, 60, 0.2);
            border-left: 4px solid var(--error-color);
            color: #e74c3c;
            box-shadow: 0 0 10px rgba(231, 76, 60, 0.1);
        }

        .loading {
            display: none;
            width: 20px;
            height: 20px;
            border: 2px solid #1e1e1e;
            border-top: 2px solid transparent;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-right: 10px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .security-note {
            background-color: rgba(241, 214, 214, 0.1);
            border: 1px solid rgba(241, 214, 214, 0.2);
            border-radius: 8px;
            padding: 15px;
            margin-top: 20px;
            font-size: 13px;
            color: #aaa;
            opacity: 0;
            animation: fadeIn 0.6s ease forwards;
            animation-delay: 1s;
        }

        .links {
            text-align: center;
            margin-top: 30px;
            padding-top: 25px;
            border-top: 1px solid #333;
            opacity: 0;
            animation: fadeIn 0.6s ease forwards;
            animation-delay: 1.1s;
        }

        .links a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
            margin: 0 10px;
            transition: all 0.3s ease;
            position: relative;
        }

        .links a::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 100%;
            height: 1px;
            background-color: var(--primary-color);
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }

        .links a:hover {
            color: var(--accent-color);
        }

        .links a:hover::after {
            transform: scaleX(1);
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media (max-width: 480px) {
            .container {
                padding: 30px 20px;
            }
            
            .logo {
                font-size: 24px;
            }
            
            h2 {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Background animation -->
    <div class="bg-animation">
        <div class="bg-bubble"></div>
        <div class="bg-bubble"></div>
        <div class="bg-bubble"></div>
        <div class="bg-bubble"></div>
    </div>

    <div class="container">
        <div class="header">
            <div class="logo">🍔 QuickyBite</div>
            <h2>Forgot Password?</h2>
            <p class="subtitle">Enter your registered email address and we'll send you a link to reset your password.</p>
        </div>
        
        <?php if (!empty($message)): ?>
            <div class="message <?php echo htmlspecialchars($messageType, ENT_QUOTES, 'UTF-8'); ?>">
                <i class="fas <?php echo $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
                <?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?>
            </div>
        <?php endif; ?>

        <form method="POST" id="forgotPasswordForm">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>" />
            
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" 
                       id="email" 
                       name="email" 
                       required
                       placeholder="Enter your registered email address"
                       value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email'], ENT_QUOTES, 'UTF-8') : ''; ?>" />
            </div>
            
            <button type="submit" class="submit-btn" id="submitBtn">
                <span class="loading" id="loading"></span>
                <span id="btnText">Send Reset Link</span>
            </button>
        </form>

        <div class="security-note">
            <strong>🔐 Security Note:</strong> 
            The password reset link will expire in 1 hour. Only registered email addresses can request password resets.
            If you don't receive an email, please make sure you entered the correct email address.
        </div>

        <div class="links">
            <a href="logins.php">← Back to Login</a>
            <span style="color: #444;">|</span>
            <a href="signup.php">Create New Account</a>
        </div>
    </div>

    <script>
        // Form submission handling
        document.getElementById('forgotPasswordForm').addEventListener('submit', function(e) {
            const submitBtn = document.getElementById('submitBtn');
            const loading = document.getElementById('loading');
            const btnText = document.getElementById('btnText');
            
            // Show loading state
            submitBtn.disabled = true;
            loading.style.display = 'inline-block';
            btnText.textContent = 'Sending...';
            
            // Form validation
            const emailInput = document.getElementById('email');
            if (!emailInput.value.trim()) {
                e.preventDefault();
                alert('Please enter your email address');
                submitBtn.disabled = false;
                loading.style.display = 'none';
                btnText.textContent = 'Send Reset Link';
                return false;
            }
            
            // Re-enable form after a timeout (in case of server issues)
            setTimeout(function() {
                if (submitBtn.disabled) {
                    submitBtn.disabled = false;
                    loading.style.display = 'none';
                    btnText.textContent = 'Send Reset Link';
                }
            }, 30000); // 30 seconds timeout
        });

        // Auto-focus email field
        window.addEventListener('load', function() {
            document.getElementById('email').focus(); // likely intended
        });

        // Clear success messages after a delay
        <?php if (isset($messageType) && $messageType === 'success'): ?>
        setTimeout(function() {
            const messageEl = document.querySelector('.message.success');
            if (messageEl) {
                messageEl.style.opacity = '0';
                messageEl.style.transition = 'opacity 0.5s ease';
                setTimeout(function() {
                    messageEl.style.display = 'none';
                }, 500);
            }
        }, 5000);
        <?php endif; ?>
    </script>
</body>
</html>