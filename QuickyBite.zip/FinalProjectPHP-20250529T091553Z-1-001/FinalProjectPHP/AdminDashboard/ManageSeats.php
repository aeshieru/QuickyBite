
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "adris_ordertaking";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ADJUSTABLE TIMER - Change this value to modify the reservation timeout
$RESERVATION_TIMEOUT_SECONDS = 20; 

// Handle table addition
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $status = $_POST['status'];
    $seats = isset($_POST['seats']) ? (int)$_POST['seats'] : 4;
    $errors = [];

    if (empty($name)) {
        $errors[] = "Table name is required.";
    }
    if (!preg_match("/^[A-Za-z0-9]+$/", $name)) {
        $errors[] = "Table name can only contain letters and numbers.";
    }

    $check_sql = "SELECT * FROM adminseats WHERE TableNum = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("s", $name);
    $check_stmt->execute();
    if ($check_stmt->get_result()->num_rows > 0) {
        $errors[] = "Table name already exists.";
    }

    if (empty($errors)) {
        $sql = "INSERT INTO adminseats (TableNum, Description, Status, Seats) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $name, $description, $status, $seats);
        
        if ($stmt->execute()) {
            echo "<script>alert('Table added successfully!');</script>";
        } else {
            echo "<script>alert('Error adding table: " . $conn->error . "');</script>";
        }
        $stmt->close();
    } else {
        foreach ($errors as $error) {
            echo "<script>alert('Error: " . $error . "');</script>";
        }
    }
    $check_stmt->close();
}

// Handle table deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $table_id = $_POST['table_id'];
    $sql = "DELETE FROM adminseats WHERE TableNum = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $table_id);
    
    if ($stmt->execute()) {
        echo "<script>alert('Table deleted successfully!');</script>";
    } else {
        echo "<script>alert('Error deleting table: " . $conn->error . "');</script>";
    }
    $stmt->close();
}

// AJAX endpoint for timer check - Clean up expired reservations
if (isset($_GET['action']) && $_GET['action'] === 'check_timers') {
    // Clean up expired reservations
    $expirationTime = date('Y-m-d H:i:s', strtotime("-{$RESERVATION_TIMEOUT_SECONDS} seconds"));
    $cleanup_sql = "UPDATE adminseats SET Status = 'Available', ReservedAt = NULL, Confirmed = FALSE 
                    WHERE Status = 'Occupied' AND Confirmed = TRUE AND ReservedAt IS NOT NULL AND ReservedAt <= ?";
    $cleanup_stmt = $conn->prepare($cleanup_sql);
    $cleanup_stmt->bind_param("s", $expirationTime);
    $cleanup_stmt->execute();
    $cleanup_stmt->close();
    
    // Return updated table statuses with timer info
    $sql = "SELECT TableNum, Status, ReservedAt, Confirmed FROM adminseats";
    $result = $conn->query($sql);
    $tables = [];
    while ($row = $result->fetch_assoc()) {
        $remaining = 0;
        if ($row['Status'] === 'Occupied' && $row['ReservedAt']) {
            $reservedTime = strtotime($row['ReservedAt']);
            $currentTime = time();
            $elapsed = $currentTime - $reservedTime;
            $remaining = max(0, $RESERVATION_TIMEOUT_SECONDS - $elapsed);
        }
        $row['remaining_time'] = $remaining;
        $tables[] = $row;
    }
    header('Content-Type: application/json');
    echo json_encode($tables);
    exit;
}

// Table listing and search
$search = $_GET['search'] ?? '';
$order_by = $_GET['order_by'] ?? 'TableNum';
$order_dir = strtoupper($_GET['order_dir'] ?? 'ASC');

$allowed_columns = ['TableNum', 'Description', 'Status', 'Seats'];
$allowed_directions = ['ASC', 'DESC'];

if (!in_array($order_by, $allowed_columns)) {
    $order_by = 'TableNum';
}
if (!in_array($order_dir, $allowed_directions)) {
    $order_dir = 'ASC';
}

$sql = "SELECT * FROM `adminseats` WHERE 
    TableNum LIKE ? OR 
    Description LIKE ? OR 
    Status LIKE ?
    ORDER BY $order_by $order_dir";

$stmt = $conn->prepare($sql);
$searchTerm = "%$search%";
$stmt->bind_param("sss", $searchTerm, $searchTerm, $searchTerm);
$stmt->execute();
$result = $stmt->get_result();

// Clean up expired reservations on page load
$expirationTime = date('Y-m-d H:i:s', strtotime("-{$RESERVATION_TIMEOUT_SECONDS} seconds"));
$cleanup_sql = "UPDATE adminseats SET Status = 'Available', ReservedAt = NULL, Confirmed = FALSE 
                WHERE Status = 'Occupied' AND Confirmed = TRUE AND ReservedAt IS NOT NULL AND ReservedAt <= ?";
$cleanup_stmt = $conn->prepare($cleanup_sql);
$cleanup_stmt->bind_param("s", $expirationTime);
$cleanup_stmt->execute();
$cleanup_stmt->close();

// Seat selection handling
$tableSelected = "";
if (isset($_POST['select_table'])) {
    if (!empty($_POST['seats'])) {
        $tableSelected = $_POST['seats'][0];
        $now = date('Y-m-d H:i:s');
        
        // Check if table is actually available before reserving
        $check_sql = "SELECT Status FROM adminseats WHERE TableNum = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $tableSelected);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            $table_data = $check_result->fetch_assoc();
            if ($table_data['Status'] === 'Available') {
                // Reserve the table with timer
                $reserve_sql = "UPDATE adminseats SET 
                                Status = 'Occupied', 
                                ReservedAt = ?, 
                                Confirmed = TRUE
                                WHERE TableNum = ? AND Status = 'Available'";
                $reserve_stmt = $conn->prepare($reserve_sql);
                $reserve_stmt->bind_param("ss", $now, $tableSelected);
                
                if ($reserve_stmt->execute() && $reserve_stmt->affected_rows > 0) {
                    echo "<script>alert('Table reserved successfully! Reservation will expire in {$RESERVATION_TIMEOUT_SECONDS} seconds.');</script>";
                } else {
                    echo "<script>alert('Error: Table is no longer available.');</script>";
                }
                $reserve_stmt->close();
            } else {
                echo "<script>alert('Error: Table is already occupied.');</script>";
            }
        }
        $check_stmt->close();
    } else {
        echo "<script>alert('Please select a table first');</script>";
    }
}

function isTableAvailable($tableNum, $conn) {
    $sql = "SELECT Status FROM adminseats WHERE TableNum = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $tableNum);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $stmt->close();
        return $row['Status'] === 'Available';
    }
    
    $stmt->close();
    return false;
}

function getTableStatusClass($tableNum, $conn) {
    return isTableAvailable($tableNum, $conn) ? "available" : "occupied";
}

function getTableReservedTime($tableNum, $conn) {
    $sql = "SELECT ReservedAt FROM adminseats WHERE TableNum = ? AND Status = 'Occupied'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $tableNum);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $stmt->close();
        return $row['ReservedAt'];
    }
    $stmt->close();
    return null;
}

function getRemainingTime($tableNum, $conn) {
    global $RESERVATION_TIMEOUT_SECONDS;
    
    $reservedAt = getTableReservedTime($tableNum, $conn);
    if ($reservedAt) {
        $reservedTime = strtotime($reservedAt);
        $currentTime = time();
        $elapsed = $currentTime - $reservedTime;
        return max(0, $RESERVATION_TIMEOUT_SECONDS - $elapsed);
    }
    return 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Manage Seats - ADRIS Reservation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="astyles/ManageSeats.css">
    <style>
        Timer-specific styles
        .timer-countdown {
    color: var(--accent);
    font-weight: bold;
    animation: pulse 1s infinite;
}

.timer-expired {
    color: var(--danger);
    font-weight: bold;
}

.table-timer {
    position: absolute;
    top: 5px;
    right: 5px;
    background: rgba(255, 54, 197, 0.8);
    color: white;
    font-size: 10px;
    padding: 2px 4px;
    border-radius: 3px;
    font-weight: bold;
}

@keyframes pulse {
    0% { opacity: 1; }
    50% { opacity: 0.5; }
    100% { opacity: 1; }
}

/* Make table position relative for timer positioning */
.table {
    position: relative;
    background: rgba(255, 255, 255, 0.1);
    border: 2px solid rgba(255, 255, 255, 0.2);
    border-radius: 8px;
    padding: 15px;
    text-align: center;
    transition: all 0.3s ease;
    cursor: pointer;
    min-height: 80px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}

.table:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(248, 120, 160, 0.3);
}

/* Ensure occupied tables are red */
.table.occupied {
    background-color: #ff6b6b !important;
    color: white !important;
    border-color: #ff5252 !important;
}

.table.available {
    background-color: #51cf66 !important;
    color: white !important;
    border-color: #4caf50 !important;
}

.table.selected {
    background-color: #ff922b !important;
    color: white !important;
    border-color: #ff8f00 !important;
}

.table-label {
    font-weight: bold;
    font-size: 16px;
    margin-bottom: 4px;
}

.seats-info {
    font-size: 12px;
    opacity: 0.9;
}

/* Seat Availability Card - matching first design */
.seat-availability-card {
    background: rgba(248, 232, 232, 0.1);
    border-radius: 10px;
    padding: 20px;
    margin-bottom: 20px;
    color: #ffffff;
    border: 1px solid rgba(255, 255, 255, 0.08);
    transition: all 0.3s ease;
}

.seat-availability-card:hover {
    background: rgba(248, 232, 232, 0.15);
    box-shadow: 0 0 15px rgba(248, 120, 160, 0.2);
}

.restaurant-layout {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
    gap: 15px;
    padding: 20px;
    background: rgba(0, 0, 0, 0.2);
    border-radius: 8px;
    margin-bottom: 20px;
    max-width: 100%;
    margin-left: auto;
    margin-right: auto;
}

/* Ensure the form doesn't stretch beyond container */
.seat-availability-card form {
    max-width: 100%;
    margin: 0 auto;
}
/* Fixed Legend Styling */
/* Fixed Legend Styling - Replace the existing .legend styles in your CSS */
.legend {
    display: flex;
    gap: 20px;
    justify-content: center;
    align-items: center;
    margin: 20px auto;
    padding: 15px 20px;
    background: rgba(0, 0, 0, 0.4);
    border-radius: 10px;
    border: 1px solid rgba(255, 255, 255, 0.1);
    width: fit-content;
    min-width: 500px;
    max-width: 700px;
    box-sizing: border-box;
}

.legend > div {
    display: flex;
    align-items: center;
    gap: 8px;
    color: #ffffff;
    font-size: 14px;
    font-weight: 500;
    padding: 10px 20px;
    background: rgba(255, 255, 255, 0.08);
    border-radius: 8px;
    transition: all 0.3s ease;
    white-space: nowrap;
    border: 1px solid rgba(255, 255, 255, 0.1);
    flex: 1;
    justify-content: center;
    min-width: 120px;
}

.legend > div:hover {
    background: rgba(255, 255, 255, 0.15);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
}

.legend-box {
    width: 16px;
    height: 16px;
    border-radius: 3px;
    border: 1px solid rgba(255, 255, 255, 0.3);
    transition: all 0.3s ease;
    flex-shrink: 0;
}

.legend-box.green {
    background-color: #51cf66;
    border-color: #4caf50;
}

.legend-box.orange {
    background-color: #ff922b;
    border-color: #ff8f00;
}

.legend-box.red {
    background-color: #ff6b6b;
    border-color: #ff5252;
}

/* Responsive adjustments for legend */
@media (max-width: 768px) {
    .legend {
        flex-direction: row;
        flex-wrap: wrap;
        gap: 15px;
        max-width: 90%;
        min-width: unset;
        padding: 15px;
        justify-content: center;
    }
    
    .legend > div {
        flex: 0 1 auto;
        min-width: 100px;
        padding: 8px 15px;
    }
}

@media (max-width: 480px) {
    .legend {
        flex-direction: column;
        gap: 10px;
        max-width: 95%;
        padding: 12px;
    }
    
    .legend > div {
        width: 100%;
        flex: none;
        justify-content: center;
        padding: 10px 15px;
        font-size: 13px;
    }
    
    .legend-box {
        width: 14px;
        height: 14px;
    }
}
.submit-btn {
    background: linear-gradient(135deg, #f8a8c8, #ff8bb3);
    color: #000;
    border: none;
    padding: 14px 28px;
    border-radius: 8px;
    cursor: pointer;
    box-shadow: 0 4px 15px rgba(248, 120, 160, 0.3);
    font-weight: bold;
    font-size: 16px;
    transition: all 0.3s ease;
    display: block;
    margin: 20px auto 0;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.submit-btn:hover {
    background: linear-gradient(135deg, #ff8bb3, #f8a8c8);
    box-shadow: 0 6px 20px rgba(248, 120, 160, 0.5);
    transform: translateY(-2px);
}

.submit-btn:active {
    transform: translateY(0);
    box-shadow: 0 2px 10px rgba(248, 120, 160, 0.4);
}

.delete-btn {
    background: linear-gradient(135deg, #ff3652, #ff5066);
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 14px;
    font-weight: 600;
}

.delete-btn:hover {
    background: linear-gradient(135deg, #ff5066, #ff3652);
    box-shadow: 0 4px 15px rgba(255, 54, 82, 0.4);
    transform: translateY(-1px);
}
    </style>
</head>
<body>
    <nav class="side-nav">
        <div class="logo-box">QB</div>
        <a href="get-user-orders.php" class="nav-icon">
          <img src="aimages/user-gear.png" alt="Users">
          <span class="nav-icon-text">Manage Users</span>
        </a>
        <a href="ManageMenu.php" class="nav-icon">
          <img src="aimages/task-checklist.png" alt="Menu">
          <span class="nav-icon-text">Manage Menu</span>
        </a>
        <a href="ManageSeats.php" class="nav-icon active">
          <img src="aimages/chair.png" alt="Seats">
          <span class="nav-icon-text">Manage Seats</span>
        </a>
        <a href="reports.php" class="nav-icon">
            <img src="aimages/user-gear.png" alt="Reports">
            <span class="nav-icon-text">Reports</span>
        </a>
        <a href="../Login/logout.php" class="nav-icon">
          <img src="aimages/exit.png" alt="Logout">
          <span class="nav-icon-text">Log Out</span>
        </a>
    </nav>

    <!-- Main Content -->
    <div class="main-content">
        <h1>Manage Seats</h1>
        
        <div class="container">
            <div class="nav-tabs">
                <a href="#" class="nav-tab active">Table Management</a>
                <a href="#" class="nav-tab">Seat Availability</a>
                <a href="#" class="nav-tab">Reservations</a>
            </div>

            <!-- Table List Section -->
            <div class="card">
                <div class="card-header">
                    <div class="card-title">List of Tables</div>
                    <button class="button" onclick="openModal('addTableModal')">
                        <i class="fas fa-plus"></i>
                        <span>Create New</span>
                    </button>
                </div>
                <div class="table-controls">
                    <form method="GET" action="ManageSeats.php">
                        <input type="text" name="search" placeholder="Search..." value="<?= htmlspecialchars($search) ?>">
                        <select name="order_by">
                            <option value="TableNum" <?= $order_by == 'TableNum' ? 'selected' : '' ?>>Table Number</option>
                            <option value="Description" <?= $order_by == 'Description' ? 'selected' : '' ?>>Description</option>
                            <option value="Status" <?= $order_by == 'Status' ? 'selected' : '' ?>>Status</option>
                            <option value="Seats" <?= $order_by == 'Seats' ? 'selected' : '' ?>>Seats</option>
                        </select>
                        <select name="order_dir">
                            <option value="ASC" <?= $order_dir == 'ASC' ? 'selected' : '' ?>>Ascending</option>
                            <option value="DESC" <?= $order_dir == 'DESC' ? 'selected' : '' ?>>Descending</option>
                        </select>
                        <button type="submit">Search</button>
                    </form>
                </div>
                <div class="table-container">
                    <table id="mainTable">
                        <thead>
                            <tr>
                                <th>Table<i class="fas fa-sort"></i></th>
                                <th>Description<i class="fas fa-sort"></i></th>
                                <th>Seats<i class="fas fa-sort"></i></th>
                                <th>Status<i class="fas fa-sort"></i></th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($result && $result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr data-table='" . htmlspecialchars($row['TableNum']) . "'>";
                                    echo "<td>" . htmlspecialchars($row['TableNum']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['Description']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['seats']) . "</td>";
                                    echo "<td class='status-cell'><span class='status " . htmlspecialchars($row['Status']) . "'>" . htmlspecialchars($row['Status']) . "</span></td>";
                                    echo "<td><button class='delete-btn' onclick=\"openDeleteModal('" . $row['TableNum'] . "')\">Delete</button></td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='5'>No Tables</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <div class="pagination">
                    <div class="page-info">Showing 1 to 10 of 10 entries</div>
                    <div class="page-controls">
                        <button class="page-link" disabled>Previous</button>
                        <button class="page-link active">1</button>
                        <button class="page-link">Next</button>
                    </div>
                </div>
            </div>

            <!-- Seat Availability Section -->
            <div class="card seat-availability-card">
                <div class="card-header">
                    <div class="card-title">Seat Availability</div>
                </div>
                <div class="restaurant-layout" id="restaurantLayout">
                    <form method="POST" action="">
                        <?php
                        $sql = "SELECT TableNum, Seats, Status, ReservedAt FROM adminseats";
                        $tables_result = $conn->query($sql);
                        if ($tables_result && $tables_result->num_rows > 0) {
                            while ($table = $tables_result->fetch_assoc()) {
                                $tableId = $table['TableNum'];
                                $tableSeats = $table['Seats'];
                                $statusClass = getTableStatusClass($tableId, $conn);
                                $isSelected = ($tableSelected === $tableId);
                                if ($isSelected) $statusClass = "selected";
                                $disabled = ($statusClass === "occupied") ? "disabled" : "";
                                
                                $timerHtml = "";
                                if ($table['Status'] === 'Occupied' && $table['ReservedAt']) {
                                    $remaining = getRemainingTime($tableId, $conn);
                                    if ($remaining > 0) {
                                        $timerHtml = "<div class='table-timer' data-reserved-time='" . $table['ReservedAt'] . "'>" . $remaining . "s</div>";
                                    }
                                }
                        ?>
                            <div class="table <?php echo $statusClass; ?>" data-table-id="<?php echo $tableId; ?>" data-status="<?php echo $table['Status']; ?>" data-reserved-time="<?php echo $table['ReservedAt'] ?? ''; ?>">
                                <div class="table-label"><?php echo $tableId; ?></div>
                                <div class="seats-info"><?php echo $tableSeats; ?> seats</div>
                                <?php echo $timerHtml; ?>
                                <input type="checkbox" name="seats[]" value="<?php echo $tableId; ?>" <?php echo $disabled; ?>>
                            </div>
                        <?php
                            }
                        } else {
                            echo "<p>No tables available</p>";
                        }
                        ?>
                        <div class="legend">
                            <div><div class="legend-box green"></div> Available</div>
                            <div><div class="legend-box orange"></div> Selected</div>
                            <div><div class="legend-box red"></div> Occupied</div>
                        </div>
                        <br>
                        <button type="submit" name="select_table" class="submit-btn">Reserve Selected Table</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Table Modal -->
    <div class="modal" id="addTableModal">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Table</h5>
                <button type="button" class="modal-close" onclick="closeModal('addTableModal')">×</button>
            </div>
            <form action="ManageSeats.php" method="POST">
                <input type="hidden" name="action" value="add">
                <div class="modal-body">
                    <div class="form-group">
                        <label class="form-label">Table Name</label>
                        <input type="text" class="form-control" name="name" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Number of Seats</label>
                        <input type="number" class="form-control" name="seats" min="1" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Description</label>
                        <textarea class="form-control" name="description" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Status</label>
                        <select class="form-select" name="status">
                            <option value="Available">Available</option>
                            <option value="Occupied">Occupied</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-secondary" onclick="closeModal('addTableModal')">Cancel</button>
                    <button type="submit" class="button">Save</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal" id="deleteModal">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Delete</h5>
                <button type="button" class="modal-close" onclick="closeModal('deleteModal')">×</button>
            </div>
            <form action="ManageSeats.php" method="POST">
                <input type="hidden" name="action" value="delete">
                <div class="modal-body">
                    <p>Are you sure you want to delete this table? This action cannot be undone.</p>
                    <input type="hidden" name="table_id" id="delete_table_id">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-secondary" onclick="closeModal('deleteModal')">Cancel</button>
                    <button type="submit" class="btn-danger">Delete</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
        }
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }
        function openDeleteModal(tableId) {
            document.getElementById('delete_table_id').value = tableId;
            openModal('deleteModal');
        }

          // ADJUSTABLE TIMER CONFIGURATION - matches PHP variable
        const RESERVATION_TIMEOUT_SECONDS = <?php echo $RESERVATION_TIMEOUT_SECONDS; ?>;
        
        function openModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }
        
        function openDeleteModal(tableId) {
            document.getElementById('delete_table_id').value = tableId;
            openModal('deleteModal');
        }

        // Timer and status update functions
        function updateLocalTimers() {
            // Update countdown timers in the seat layout
            document.querySelectorAll('.table').forEach(function(tableDiv) {
                const tableId = tableDiv.getAttribute('data-table-id');
                const status = tableDiv.getAttribute('data-status');
                const reservedTime = tableDiv.getAttribute('data-reserved-time');
                
                if (status === 'Occupied' && reservedTime && reservedTime !== '') {
                    const reservedTimestamp = new Date(reservedTime).getTime();
                    const currentTime = Date.now();
                    const elapsed = Math.floor((currentTime - reservedTimestamp) / 1000);
                    const remaining = Math.max(0, RESERVATION_TIMEOUT_SECONDS - elapsed);
                    
                    let timer = tableDiv.querySelector('.table-timer');
                    
                    if (remaining > 0) {
                        // Timer still running
                        if (!timer) {
                            timer = document.createElement('div');
                            timer.className = 'table-timer timer-countdown';
                            tableDiv.appendChild(timer);
                        }
                        timer.textContent = remaining + 's';
                        timer.classList.add('timer-countdown');
                        timer.classList.remove('timer-expired');
                        
                        // Ensure table is marked as occupied
                        tableDiv.classList.remove('available');
                        tableDiv.classList.add('occupied');
                        const checkbox = tableDiv.querySelector('input[type="checkbox"]');
                        if (checkbox) {
                            checkbox.disabled = true;
                            checkbox.checked = false;
                        }
                    } else {
                        // Timer expired
                        if (timer) {
                            timer.textContent = '';
                            timer.classList.add('timer-expired');
                            timer.classList.remove('timer-countdown');
                        }
                    }
                } else {
                    // Table is available or no timer
                    const timer = tableDiv.querySelector('.table-timer');
                    if (timer) {
                        timer.remove();
                    }
                    
                    if (status === 'Available') {
                        tableDiv.classList.remove('occupied');
                        tableDiv.classList.add('available');
                        const checkbox = tableDiv.querySelector('input[type="checkbox"]');
                        if (checkbox) {
                            checkbox.disabled = false;
                        }
                    }
                }
            });
        }

        function checkAndUpdateTableStatuses() {
            // Make AJAX call to check for expired reservations
            fetch('ManageSeats.php?action=check_timers')
                .then(response => response.json())
                .then(tables => {
                    console.log('Updated table data:', tables); // Debug log
                    
                    // Update main table rows
                    tables.forEach(table => {
                        const row = document.querySelector(`tr[data-table="${table.TableNum}"]`);
                        if (row) {
                            const statusCell = row.querySelector('.status-cell');
                            statusCell.textContent = table.Status;
                        }
                    });

                    // Update seat layout
                    tables.forEach(table => {
                        const tableDiv = document.querySelector(`[data-table-id="${table.TableNum}"]`);
                        if (tableDiv) {
                            const checkbox = tableDiv.querySelector('input[type="checkbox"]');
                            const timer = tableDiv.querySelector('.table-timer');
                            
                            // Update data attributes
                            tableDiv.setAttribute('data-status', table.Status);
                            tableDiv.setAttribute('data-reserved-time', table.ReservedAt || '');
                            
                            // Remove existing classes
                            tableDiv.classList.remove('available', 'occupied', 'selected');
                            
                            if (table.Status === 'Available') {
                                tableDiv.classList.add('available');
                                checkbox.disabled = false;
                                if (timer) {
                                    timer.remove();
                                }
                            } else if (table.Status === 'Occupied') {
                                tableDiv.classList.add('occupied');
                                checkbox.disabled = true;
                                checkbox.checked = false;
                                
                                // Add timer if remaining time > 0
                                if (table.remaining_time > 0) {
                                    if (!timer) {
                                        const newTimer = document.createElement('div');
                                        newTimer.className = 'table-timer timer-countdown';
                                        tableDiv.appendChild(newTimer);
                                    }
                                } else {
                                    if (timer) {
                                        timer.remove();
                                    }
                                }
                            }
                        }
                    });
                })
                .catch(error => {
                    console.error('Error checking table statuses:', error);
                });
        }

        // Start timer updates when page loads
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Timer system starting with timeout:', RESERVATION_TIMEOUT_SECONDS, 'seconds');
            
            // Update local timers every second
            setInterval(updateLocalTimers, 1000);
            
            // Check database for expired reservations every 3 seconds
            setInterval(checkAndUpdateTableStatuses, 3000);
            
            // Initial calls
            updateLocalTimers();
            setTimeout(checkAndUpdateTableStatuses, 1000); // Initial check after 1 second
        });
    </script>
</body>
</html>
<?php $conn->close(); ?>