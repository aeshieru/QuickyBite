<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewportKitchen Das" content="width=device-width, initial-scale=1.0">
  <title>View Orders</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background-color: #000000;
      background-image: 
        radial-gradient(circle at 20% 30%, rgba(248, 120, 160, 0.1) 0%, transparent 50%),
        radial-gradient(circle at 80% 70%, rgba(248, 120, 160, 0.08) 0%, transparent 50%);
      margin: 0;
      padding: 0;
      color: #ffffff;
      min-height: 100vh;
      font-size: 18px; /* Increased base font size */
    }
    
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 20px 40px;
      background: rgba(17, 17, 17, 0.8);
      backdrop-filter: blur(10px);
      border-bottom: 1px solid rgba(248, 120, 160, 0.2);
    }
    
    .header-left, .header-center, .header-right {
      flex: 1;
    }
    
    .header-center {
      text-align: center;
    }
    
    .header-right {
      text-align: right;
    }
    
    .kitchen-title {
      color: #ffffff;
      font-size: 36px; /* Increased from 28px */
      font-weight: 600;
      margin: 0;
      background: linear-gradient(45deg, #ffffff, #f8a8c8);
      background-clip: text;
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    
    .datetime {
      font-weight: 500;
      color: #f8a8c8;
      font-size: 18px; /* Increased from 14px */
    }
    
    .logout-btn {
      background: linear-gradient(45deg, #f878a0, #f8a0a0);
      border: none;
      color: #000000;
      padding: 12px 20px; /* Increased padding */
      border-radius: 6px;
      font-weight: 500;
      font-size: 16px; /* Added explicit font size */
      cursor: pointer;
      transition: all 0.2s;
    }
    
    .logout-btn:hover {
      background: linear-gradient(45deg, #f85a8a, #f88a8a);
      transform: translateY(-1px);
    }
    
    .main-content {
      padding: 30px;
      max-width: 1200px;
      margin: 0 auto;
      height: calc(100vh - 100px);
    }
    
    .orders-layout {
      display: flex;
      gap: 24px;
      height: 100%;
    }
    
    .orders-column {
      flex: 1;
      display: flex;
      flex-direction: column;
      height: 100%;
    }
    
    .column-header {
      font-size: 26px; /* Increased from 20px */
      font-weight: 600;
      text-align: center;
      margin-bottom: 20px;
      padding: 20px; /* Increased padding */
      border-radius: 8px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    
    .preparing-header {
      background: rgba(248, 160, 120, 0.2);
      color: #f8a078;
      border: 1px solid rgba(248, 160, 120, 0.3);
    }
    
    .completed-header {
      background: rgba(120, 248, 160, 0.2);
      color: #78f8a0;
      border: 1px solid rgba(120, 248, 160, 0.3);
    }
    
    .orders-container {
      flex: 1;
      overflow-y: auto;
      padding-right: 8px;
    }
    
    .orders-container::-webkit-scrollbar {
      width: 6px;
    }
    
    .orders-container::-webkit-scrollbar-track {
      background: rgba(255, 255, 255, 0.1);
      border-radius: 3px;
    }
    
    .orders-container::-webkit-scrollbar-thumb {
      background: rgba(248, 120, 160, 0.4);
      border-radius: 3px;
    }
    
    .orders-container::-webkit-scrollbar-thumb:hover {
      background: rgba(248, 120, 160, 0.6);
    }
    
    .loading-message {
      text-align: center;
      color: #f8a8c8;
      font-size: 20px; /* Increased from 16px */
      margin-top: 40px;
      padding: 24px;
      background: rgba(248, 232, 232, 0.05);
      border-radius: 8px;
      border: 1px solid rgba(248, 120, 160, 0.2);
    }
    
    .error-message {
      text-align: center;
      color: #f87890;
      background: rgba(248, 120, 144, 0.1);
      padding: 16px;
      border-radius: 8px;
      border: 1px solid rgba(248, 120, 144, 0.3);
      margin-top: 20px;
      font-size: 18px; /* Added explicit font size */
    }
    
    .orders-container h2 {
      margin: 16px 0 12px;
      color: #f8a8c8;
      font-size: 24px; /* Increased from 18px */
      font-weight: 600;
      text-align: left;
      padding: 16px 20px; /* Increased padding */
      background: rgba(248, 232, 232, 0.1);
      border-radius: 6px;
      border-left: 4px solid #f878a0;
    }
    
    .order-card {
      background: rgba(255, 255, 255, 0.9);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 8px;
      padding: 20px; /* Increased from 16px */
      margin-bottom: 12px;
      backdrop-filter: blur(10px);
      transition: all 0.2s ease;
      font-size: 18px; /* Added explicit font size */
      line-height: 1.6; /* Improved line height */
      color: #000000; /* Black text for order cards */
    }
    
    .order-card:hover {
      background: rgba(255, 255, 255, 0.95);
      border-color: rgba(248, 120, 160, 0.4);
      transform: translateY(-1px);
    }
    
    .orders-container > div:not(.order-card):not(.loading-message):not(.error-message),
    .orders-container > p {
      background: rgba(255, 255, 255, 0.9);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 8px;
      padding: 20px; /* Increased from 16px */
      margin-bottom: 12px;
      transition: all 0.2s ease;
      font-size: 18px; /* Increased from 14px */
      line-height: 1.6; /* Increased from 1.5 */
      color: #000000; /* Black text for other white boxes */
    }
    
    .orders-container > div:hover:not(.loading-message):not(.error-message),
    .orders-container > p:hover {
      background: rgba(255, 255, 255, 0.95);
      border-color: rgba(248, 120, 160, 0.4);
    }
    
    .orders-container a {
      color: #d63384;
      text-decoration: none;
      font-weight: 500;
      font-size: 18px; /* Added explicit font size */
    }
    
    .orders-container a:hover {
      color: #b02a4a;
      text-decoration: underline;
    }
    
    .orders-container strong {
      color: #000000;
      font-weight: 600;
      font-size: 19px; /* Slightly larger for emphasis */
    }
    
    .orders-container table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 16px;
      background: rgba(255, 255, 255, 0.05);
      border-radius: 6px;
      overflow: hidden;
    }
    
    .orders-container td, .orders-container th {
      padding: 14px 16px; /* Increased from 10px 12px */
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      text-align: left;
      font-size: 18px; /* Added explicit font size */
    }
    
    .orders-container th {
      background: rgba(248, 120, 160, 0.2);
      color: #f8a8c8;
      font-weight: 600;
      font-size: 16px; /* Increased from 13px */
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    
    .orders-container td {
      font-size: 18px; /* Increased from 14px */
    }
    
    @media (max-width: 768px) {
      body {
        font-size: 16px; /* Slightly smaller on mobile but still larger than original */
      }
      
      .header {
        padding: 16px 20px;
        flex-direction: column;
        gap: 12px;
      }
      
      .header-left, .header-center, .header-right {
        flex: none;
        text-align: center;
      }
      
      .kitchen-title {
        font-size: 30px; /* Increased from 24px */
      }
      
      .datetime {
        font-size: 16px; /* Increased for mobile */
      }
      
      .main-content {
        padding: 20px;
        height: calc(100vh - 140px);
      }
      
      .orders-layout {
        flex-direction: column;
        gap: 16px;
      }
      
      .orders-column {
        height: 45vh;
      }
      
      .column-header {
        font-size: 22px; /* Increased from 18px */
        padding: 16px; /* Increased from 12px */
      }
      
      .order-card {
        font-size: 16px; /* Responsive font size for mobile */
        padding: 16px;
      }
      
      .orders-container > div:not(.order-card):not(.loading-message):not(.error-message),
      .orders-container > p {
        font-size: 16px;
        padding: 16px;
      }
      
      .orders-container h2 {
        font-size: 20px;
        padding: 14px 16px;
      }
      
      .orders-container td, .orders-container th {
        font-size: 16px;
        padding: 12px 14px;
      }
      
      .orders-container th {
        font-size: 14px;
      }
    }
  </style>
</head>
<body>

<div class="header">
  <div class="header-left">
    <div class="datetime" id="datetime"></div>
  </div>
  <div class="header-center">
    <h1 class="kitchen-title">LIVE ORDER</h1>
  </div>
  <div class="header-right">
    <button class="logout-btn" onclick="logout()">Logout</button>
  </div>
</div>

<div class="main-content">
  <div class="orders-layout">
    <div class="orders-column">
      <div class="column-header preparing-header">Preparing Orders</div>
      <div class="orders-container">
        <div id="preparingContainer" class="loading-message">Loading preparing orders...</div>
      </div>
    </div>
    
    <div class="orders-column">
      <div class="column-header completed-header">Completed Orders</div>
      <div class="orders-container">
        <div id="completedContainer" class="loading-message">Loading completed orders...</div>
      </div>
    </div>
  </div>
</div>

<script>
function updateDateTime() {
  const now = new Date();
  const formatted = now.toLocaleString();
  document.getElementById('datetime').textContent = formatted;
}
setInterval(updateDateTime, 1000);
updateDateTime();

function loadOrders() {
  const xhr = new XMLHttpRequest();
  xhr.open("GET", "Queue.php", true);
  xhr.onload = function () {
    if (xhr.status === 200) {
      const response = xhr.responseText;
      separateOrders(response);
    } else {
      document.getElementById("completedContainer").innerHTML = '<div class="error-message">Error loading orders: ' + xhr.status + '</div>';
      document.getElementById("preparingContainer").innerHTML = '<div class="error-message">Error loading orders: ' + xhr.status + '</div>';
    }
  };
  xhr.onerror = function () {
    document.getElementById("completedContainer").innerHTML = '<div class="error-message">Request failed. Please check your connection.</div>';
    document.getElementById("preparingContainer").innerHTML = '<div class="error-message">Request failed. Please check your connection.</div>';
  };
  xhr.send();
}

function separateOrders(htmlContent) {
  const tempDiv = document.createElement('div');
  tempDiv.innerHTML = htmlContent;
  
  let completedOrders = '';
  let preparingOrders = '';
  
  const h2Elements = tempDiv.querySelectorAll('h2');
  
  if (h2Elements.length > 0) {
    let currentSection = '';
    let currentContent = '';
    
    const allElements = Array.from(tempDiv.children);
    
    for (let i = 0; i < allElements.length; i++) {
      const element = allElements[i];
      
      if (element.tagName === 'H2') {
        if (currentSection && currentContent) {
          const wrappedContent = wrapOrdersInCards(currentContent);
          if (currentSection.toLowerCase().includes('completed') || 
              currentSection.toLowerCase().includes('done') || 
              currentSection.toLowerCase().includes('ready')) {
            completedOrders += '<h2>' + currentSection + '</h2>' + wrappedContent;
          } else {
            preparingOrders += '<h2>' + currentSection + '</h2>' + wrappedContent;
          }
        }
        
        currentSection = element.textContent;
        currentContent = '';
      } else {
        currentContent += element.outerHTML;
      }
    }
    
    if (currentSection && currentContent) {
      const wrappedContent = wrapOrdersInCards(currentContent);
      if (currentSection.toLowerCase().includes('completed') || 
          currentSection.toLowerCase().includes('done') || 
          currentSection.toLowerCase().includes('ready')) {
        completedOrders += '<h2>' + currentSection + '</h2>' + wrappedContent;
      } else {
        preparingOrders += '<h2>' + currentSection + '</h2>' + wrappedContent;
      }
    }
  } else {
    const contentText = htmlContent.toLowerCase();
    
    if (contentText.includes('completed') || contentText.includes('done') || contentText.includes('ready')) {
      const lines = htmlContent.split('\n');
      let foundSplit = false;
      
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].toLowerCase();
        if (line.includes('preparing') || line.includes('pending') || line.includes('new')) {
          completedOrders = wrapOrdersInCards(lines.slice(0, i).join('\n'));
          preparingOrders = wrapOrdersInCards(lines.slice(i).join('\n'));
          foundSplit = true;
          break;
        }
      }
      
      if (!foundSplit) {
        completedOrders = wrapOrdersInCards(htmlContent);
      }
    } else {
      preparingOrders = wrapOrdersInCards(htmlContent);
    }
  }
  
  if (!completedOrders.trim()) {
    completedOrders = '<div class="loading-message">No completed orders</div>';
  }
  
  if (!preparingOrders.trim()) {
    preparingOrders = '<div class="loading-message">No orders being prepared</div>';
  }
  
  document.getElementById("completedContainer").innerHTML = completedOrders;
  document.getElementById("preparingContainer").innerHTML = preparingOrders;
}

function wrapOrdersInCards(content) {
  if (!content || !content.trim()) return '';
  
  if (content.includes('loading-message') || content.includes('error-message')) {
    return content;
  }
  
  // Clean up malformed HTML first
  let cleanedContent = content
    // Fix malformed div tags like <>class="card"> 
    .replace(/<>\s*class="[^"]*">/gi, '')
    // Fix incomplete opening tags like <>
    .replace(/<>\s*/gi, '')
    // Fix Order ID patterns and create proper separation
    .replace(/(\*\*Order ID:\*\*\s*\d+)/gi, '<div class="order-separator">$1</div>')
    // Clean up extra whitespace and newlines
    .replace(/\s*<div class="order-separator">/gi, '</div><div class="order-separator">')
    // Fix the first occurrence
    .replace(/^<\/div>/, '');
  
  // Split by order separators to create individual cards
  const orderParts = cleanedContent.split('<div class="order-separator">');
  
  if (orderParts.length > 1) {
    // Multiple orders found, wrap each in a card
    const wrappedOrders = orderParts
      .filter(part => part.trim())
      .map(part => {
        // Clean up the part and remove closing div tag
        const cleanPart = part.replace('</div>', '').trim();
        return cleanPart ? `<div class="order-card">${cleanPart}</div>` : '';
      })
      .filter(part => part)
      .join('');
    
    return wrappedOrders;
  }
  
  // Fallback: try other separators
  const orderSeparators = [
    /<hr\s*\/?>/gi,
    /<br\s*\/?>\s*<br\s*\/?>/gi,
    /\n\s*\n/g
  ];
  
  let processedContent = cleanedContent;
  
  for (const separator of orderSeparators) {
    if (separator.test(processedContent)) {
      const parts = processedContent.split(separator);
      processedContent = parts
        .filter(part => part.trim())
        .map(part => `<div class="order-card">${part.trim()}</div>`)
        .join('');
      break;
    }
  }
  
  // If no separators found, wrap the entire content as one card
  if (processedContent === cleanedContent && cleanedContent.trim()) {
    processedContent = `<div class="order-card">${cleanedContent}</div>`;
  }
  
  return processedContent;
}

loadOrders();
setInterval(loadOrders, 1000);

function logout() {
  if (confirm('Are you sure you want to logout?')) {
    window.location.href = 'login.php';
  }
}
</script>

</body>
</html>