<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Kitchen Dashboard</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      padding: 20px;
    }
    #orderContainer h2 {
      margin-top: 40px;
    }
  </style>
</head>
<body>

<h1>Kitchen Dashboard</h1>
<p id="datetime" style="font-weight: bold;"></p>

<div id="orderContainer">Loading orders...</div>

<script>
// Update clock
function updateDateTime() {
  const now = new Date();
  const formatted = now.toLocaleString();
  document.getElementById('datetime').textContent = formatted;
}
setInterval(updateDateTime, 1000);
updateDateTime();

// Auto-refresh order display
function loadOrders() {
  const xhr = new XMLHttpRequest();
  xhr.open("GET", "manage_orders.php", true);
  xhr.onload = function () {
    if (xhr.status === 200) {
      document.getElementById("orderContainer").innerHTML = xhr.responseText;
    } else {
      document.getElementById("orderContainer").innerHTML = "Error loading orders: " + xhr.status;
    }
  };
  xhr.onerror = function () {
    document.getElementById("orderContainer").innerHTML = "Request failed.";
  };
  xhr.send();
}loadOrders();
setInterval(loadOrders, 1000); // Refresh every second
</script>

</body>
</html>