<?php
    session_start();
    // Database connection
    $conn = mysqli_connect("localhost", "root", "", "adris_ordertaking");
    
    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    
    $customername = $_SESSION['full_name'] ?? 'Guest';
    $cart = $_SESSION['cart'] ?? [];
    
    // Calculate total for display
    $total = 0;
    foreach ($cart as $item) {
        $total += $item['FoodPrice'] * $item['Quantity'];
    }
    
    // Fetch order types from database
    $orderTypes = [];
    $orderTypesQuery = "SELECT DISTINCT OrderType FROM order_types ORDER BY OrderType";
    $result = mysqli_query($conn, $orderTypesQuery);
    
    if ($result && mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            $orderTypes[] = $row['OrderType'];
        }
    } else {
        // Default order types if none in database
        $orderTypes = ['Dine In', 'Take Out'];
    }
    
    // Set timezone and get current date/time
    date_default_timezone_set("Asia/Manila");
    $date_reserved = date("Y-m-d");
    $time_reserved = date("h:i:sA");
    
    // Calculate available pickup times
   $minTime = date('H:i', strtotime('+0 minutes'));     
    $maxTime = date('H:i', strtotime('+1 hours'));

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkout'])) {
    // 1. Collect data

    if (!isset($_SESSION['user_id'])) {
    die("User not logged in.");
    }
    if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as &$cartItem) {
        unset($cartItem['FoodImage']);
    }
    unset($cartItem); // break the reference
}
    $customername = $_SESSION['full_name'] ?? 'Guest';
    $orderType = $_POST['OrderType'] ?? null;
    $pickupDate = date("Y-m-d");
    $pickupTime = $_POST['PickupTime'] ?? null;
    $paymentMethod = $_POST['PaymentMethod'] ?? null;
    $cart = $_SESSION['cart'] ?? []; 

    $total = $total * 100;
    $user_id = $_SESSION['user_id'];

    $orderId = uniqid();
    $reference = "ORDER_" . $orderId;
    $cartJson = json_encode($cart);


    $stmt = $conn->prepare("INSERT INTO pending_orders 
    (reference, customer_name, cart_json, total, status, pickupDate, pickupTime, orderType, userId) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $status = "pending";

    $stmt->bind_param("sssissssi", 
        $reference, $customername, $cartJson, $total, $status, 
        $pickupDate, $pickupTime, $orderType, $user_id);

    if (!$stmt->execute()) {
        die("Insert failed: " . $stmt->error);
    }
    $payload = json_encode([
        "data" => [
            "attributes" => [
                "billing" => [
                    "name" => $customerName,
                    "email" => "youremail@gmail.com" 
                ],
            "line_items" => [[
                "currency" => "PHP",
                "amount" => $total,
                "name" => "QuickyBite Order",
                "quantity" => 1, // or use count($cart) if you want total items
                "description" => "Restaurant Order #$reference"
            ]],
                "payment_method_types" => ["gcash"], // only GCash supported in UI
                "reference_number" => $reference,
                "success_url" => "http://localhost:3000/UserDashboard/ProcessCheckout.php?ref=$reference",
                "cancel_url" => "http://localhost:3000/UserDashboard/Fail.php"
            ]
        ]
    ]);

    $ch = curl_init("https://api.paymongo.com/v1/checkout_sessions");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_HTTPHEADER => [
            "Authorization: Basic " . base64_encode("sk_test_GmYWaGhoT8LbP4VQAg5k1RHV"), 
            "Content-Type: application/json"
        ]
    ]);
    $response = curl_exec($ch);
    curl_close($ch);
    $result = json_decode($response, true);

    // 4. Redirect user to PayMongo payment URL
    if (isset($result['data']['attributes']['checkout_url'])) {
        header("Location: " . $result['data']['attributes']['checkout_url']);
        exit;
    } else {
        echo "Error creating payment session. Please try again.";
        var_dump($result);
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Method - QuickyBite</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="ustyles/PaymentMethod.css">
</head>
<body>
    <nav class="side-nav">
        <div class="logo-box">QB</div>
        <a href="user_dashboard.php" class="nav-icon">
            <img src="uimages/house-blank.png" alt="Dashboard">
            <span class="nav-icon-text">Dashboard</span>
        </a>
        <a href="DisplayMenu.php" class="nav-icon">
            <img src="uimages/task-checklist.png" alt="Menu">
            <span class="nav-icon-text">Menu</span>
        </a>
        <a href="ViewCart.php" class="nav-icon active">
            <img src="uimages/shopping-cart.png" alt="Cart">
            <span class="nav-icon-text">Cart</span>
        </a>
        <a href="SeatAvailability.php" class="nav-icon">
            <img src="uimages/chair.png" alt="Seat Availability">
            <span class="nav-icon-text">Seat Availability</span>
        </a>
        <a href="MyAccount.php" class="nav-icon">
            <img src="uimages/user.png" alt="My Account">
            <span class="nav-icon-text">My Account</span>
        </a>
        <a href="../Login/logout.php" class="nav-icon">
            <img src="uimages/exit.png" alt="Logout">
            <span class="nav-icon-text">Log Out</span>
        </a>
    </nav>

    <div class="main-content">
        <h1>Payment Method</h1>
        
        <div class="container">
            <div class="payment-container">
                <div class="order-summary">
                    <h2>Order Summary</h2>
                    <?php if (!empty($cart)): ?>
                        <?php foreach ($cart as $item): ?>
                            <div class="summary-item">
                                <span><?= htmlspecialchars($item['FoodName']) ?> × <?= $item['Quantity'] ?></span>
                                <span>₱<?= number_format($item['FoodPrice'] * $item['Quantity'], 2) ?></span>
                            </div>
                        <?php endforeach; ?>
                        <div class="summary-total">
                            <span>Total</span>
                            <span>₱<?= number_format($total, 2) ?></span>
                        </div>
                    <?php else: ?>
                        <div class="summary-item">No items in cart</div>
                    <?php endif; ?>
                </div>
                
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="customerName" class="form-label">Customer Name</label>
                        <input type="text" id="customerName" name="CustomerName" value="<?= htmlspecialchars($customername) ?>" readonly class="form-control">
                    </div>
                    
                    <!-- Order Type Selection -->
                    <div class="form-group">
                        <label class="form-label">Order Type</label>
                        <div class="order-types">
                            <div class="order-type selected" onclick="selectOrderType('Dine In')">
                                <i class="fas fa-utensils"></i>
                                <div class="order-type-name">Dine In</div>
                            </div>
                            <div class="order-type" onclick="selectOrderType('Take Out')">
                                <i class="fas fa-shopping-bag"></i>
                                <div class="order-type-name">Take Out</div>
                            </div>
                        </div>
                        <input type="hidden" id="orderType" name="OrderType" value="Dine In" required>
                    </div>
                    <script>
                    function selectOrderType(type) {
                        // Remove "selected" class from all order types
                        document.querySelectorAll('.order-type').forEach(el => el.classList.remove('selected'));

                        // Add "selected" to the one that matches
                        document.querySelectorAll('.order-type').forEach(el => {
                            if (el.textContent.includes(type)) {
                                el.classList.add('selected');
                            }
                        });

                        // Update hidden input
                        document.getElementById('orderType').value = type;
                    }
                    </script>
                                        
                        <!-- Pickup Time Selection (appears only when Take Out is selected) -->
                        <div id="pickupTimeContainer" class="pickup-time-container">
                            <div class="form-group">
                                <label for="pickupTime" class="form-label">Pickup Time</label>
                                <?php
                                
                                    $minTime = date('H:i', strtotime('+30 minutes'));    
                                    
                                    $maxTime = date('H:i', strtotime('19:00'));
                                ?>
                                <input type="time" id="pickupTime" name="PickupTime" class="form-control" 
                                    min="<?= $minTime ?>" max="<?= $maxTime ?>" value="<?= $minTime ?>">
                                <small style="color: rgba(255,255,255,0.6); display: block; margin-top: 8px;">
                                    Available pickup times between <?= date('g:i A', strtotime($minTime)) ?> and <?= date('g:i A', strtotime($maxTime)) ?>
                                </small>
                            </div>
                        </div>
                    
                        <!-- Payment Method Selection -->
                        <div class="form-group">
                            <label class="form-label">Payment Method</label>
                            <div class="payment-methods">
                                <div class="payment-method selected" onclick="selectPayment('GCash')">
                                    <img src="uimages/gcash.png" alt="GCash">
                                <div class="payment-method-name">GCash</div>
                                </div>
                            </div>
                            <input type="hidden" id="paymentMethod" name="PaymentMethod" value="GCash" required>
                        </div>

                    <button type="submit" name="checkout" class="submit-btn">Confirm Order</button>
                </form>
                
                <a href="ViewCart.php" class="back-btn">Back to Cart</a>
            </div>
        </div>
    </div>
    
  <script src="PaymentMethod.js"></script>
</body>
</html>