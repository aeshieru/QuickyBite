 // Toggle password visibility
 document.querySelectorAll('.toggle-password').forEach(function(toggle) {
    toggle.addEventListener('click', function() {
        const passwordInput = this.previousElementSibling;
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        
        // Toggle eye icon
        this.classList.toggle('fa-eye');
        this.classList.toggle('fa-eye-slash');
    });
});

// Password strength checker
const passwordInput = document.getElementById('password');
const strengthIndicator = document.querySelector('.password-strength');
const strengthLabel = document.querySelector('.strength-label');

passwordInput.addEventListener('input', function() {
    const password = this.value;
    let strength = 0;
    
    // Length check
    if (password.length >= 8) strength += 1;
    
    // Contains lowercase and uppercase
    if (password.match(/([a-z].*[A-Z])|([A-Z].*[a-z])/)) strength += 1;
    
    // Contains numbers
    if (password.match(/\d/)) strength += 1;
    
    // Contains special characters
    if (password.match(/[^a-zA-Z0-9]/)) strength += 1;
    
    // Update strength indicator
    strengthIndicator.className = 'password-strength';
    
    if (password.length === 0) {
        strengthLabel.textContent = 'Weak';
        strengthLabel.style.color = '#aaa';
    } else if (strength < 2) {
        strengthIndicator.classList.add('weak');
        strengthLabel.textContent = 'Weak';
        strengthLabel.style.color = '#e74c3c';
    } else if (strength < 4) {
        strengthIndicator.classList.add('medium');
        strengthLabel.textContent = 'Medium';
        strengthLabel.style.color = '#f39c12';
    } else {
        strengthIndicator.classList.add('strong');
        strengthLabel.textContent = 'Strong';
        strengthLabel.style.color = '#2ecc71';
    }
});
        
        // Focus effects for inputs
        const inputs = document.querySelectorAll('input[type="text"], input[type="email"], input[type="password"], input[type="tel"]');
        
        inputs.forEach(input => {
            // Add focus animation
            input.addEventListener('focus', function() {
                this.parentElement.classList.add('input-focused');
                const label = this.previousElementSibling || this.parentElement.previousElementSibling;
                if (label && label.tagName === 'LABEL') {
                    label.style.color = 'var(--primary-color)';
                }
            });
            
            // Remove focus animation
            input.addEventListener('blur', function() {
                this.parentElement.classList.remove('input-focused');
                const label = this.previousElementSibling || this.parentElement.previousElementSibling;
                if (label && label.tagName === 'LABEL' && !this.value) {
                    label.style.color = '#ccc';
                }
            });
        });
        
        // Form validation with enhanced animations
        const form = document.getElementById('signupForm');
        const submitBtn = document.getElementById('submitBtn');
        
       // Replace the current submit event listener with this updated one
        form.addEventListener('submit', function(event) {
            // Get form elements
            const fullName = document.getElementById('fullName').value.trim();
            const username = document.getElementById('username').value.trim();
            const email = document.getElementById('email').value.trim();
            const phone = document.getElementById('phone').value.trim();
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            const agreement = document.getElementById('agreement').checked;
            
            let valid = true;
            let message = '';
            let errorField = null;
            
            // Reset previously highlighted fields
            inputs.forEach(input => {
                input.style.boxShadow = '';
            });
            
            // Check required fields
            if (fullName === '') {
                message = 'Please enter your full name';
                errorField = document.getElementById('fullName');
                valid = false;
            } else if (username === '') {
                message = 'Please enter a username';
                errorField = document.getElementById('username');
                valid = false;
            } else if (email === '') {
                message = 'Please enter your email address';
                errorField = document.getElementById('email');
                valid = false;
            } else if (!isValidEmail(email)) {
                message = 'Please enter a valid email address';
                errorField = document.getElementById('email');
                valid = false;
            } else if (phone === '') {
                message = 'Please enter your phone number';
                errorField = document.getElementById('phone');
                valid = false;
            } else if (password === '') {
                message = 'Please create a password';
                errorField = document.getElementById('password');
                valid = false;
            } else if (password.length < 8) {
                message = 'Password must be at least 8 characters long';
                errorField = document.getElementById('password');
                valid = false;
            } else if (confirmPassword === '') {
                message = 'Please confirm your password';
                errorField = document.getElementById('confirmPassword');
                valid = false;
            } else if (password !== confirmPassword) {
                message = 'Passwords do not match';
                errorField = document.getElementById('confirmPassword');
                valid = false;
            } else if (!agreement) {
                message = 'You must agree to the Terms & Conditions';
                document.getElementById('agreement').parentElement.classList.add('shake');
                valid = false;
            }

            // Display validation error if any
    if (!valid) {
        event.preventDefault();
        
        // Create or update error message
        let messageDiv = document.querySelector('.message');
        if (messageDiv) {
            document.querySelector('.container').removeChild(messageDiv);
        }
        
        messageDiv = document.createElement('div');
        messageDiv.className = 'message error';
        messageDiv.innerHTML = `<i class="fas fa-exclamation-circle"></i>${message}`;
        document.querySelector('.container').insertBefore(messageDiv, document.querySelector('form'));
        
        // Animate error message
        setTimeout(() => {
            messageDiv.style.animation = 'slideDown 0.5s ease forwards';
        }, 10);
        
        // Highlight error field with shake animation
        if (errorField) {
            errorField.style.boxShadow = '0 0 0 2px var(--error-color)';
            errorField.classList.add('shake');
            errorField.focus();
            
            // Remove shake class after animation completes
            setTimeout(() => {
                errorField.classList.remove('shake');
            }, 600);
        }
    } else {
        // Show loading state on button with animation
        submitBtn.innerHTML = '<div class="spinner"></div><span>Processing...</span>';
        submitBtn.classList.add('submitting');
        
        // Allow form submission
        // The PHP redirect will handle navigation after processing
    }
});

// Add this to initialize the form state at page load
document.addEventListener('DOMContentLoaded', function() {
    // Check if there's a success message, which means the form was submitted successfully
    if (document.querySelector('.message.success')) {
        submitBtn.innerHTML = '<i class="fas fa-check"></i> SUCCESS';
        submitBtn.classList.add('success');
    }
});
        
        // Helper function to validate email format
        function isValidEmail(email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        }
        
        // Add success animation for successful submission
        if (document.querySelector('.message.success')) {
            const successMessage = document.querySelector('.message.success');
            
            // Add checkmark animation
            const checkmark = document.createElement('span');
            checkmark.className = 'checkmark';
            successMessage.prepend(checkmark);
            
            // Redirect to login page after showing success message
            setTimeout(() => {
                window.location.href = 'logins.php';
            }, 3000);
        }
