<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "adris_ordertaking";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$tableSelected = "";

// Clean up expired unconfirmed reservations
$expirationTime = date('Y-m-d H:i:s', strtotime('-30 seconds'));
$conn->query("DELETE FROM adminseats WHERE Confirmed = FALSE AND ReservedAt <= '$expirationTime'");

if (isset($_POST['select_table'])) {
    if (!empty($_POST['seats'])) {      
        $tableSelected = $_POST['seats'][0];
        $now = date('Y-m-d H:i:s');

        // Temporarily reserve the table
        $reserve_sql = "INSERT INTO adminseats (TableNum, Date, Status, ReservedAt, Confirmed)
                        VALUES ('$tableSelected', '$now', 'Occupied', '$now', FALSE)
                        ON DUPLICATE KEY UPDATE 
                            Status = 'Occupied', 
                            ReservedAt = '$now', 
                            Confirmed = FALSE";
        $conn->query($reserve_sql);
    } else {
        echo "<script>alert('Please select a table first');</script>";
    }
}

if (isset($_POST['confirm_seat'])) {
    $table = trim($_POST['table']);
    $date = $_POST['date'];
    $time = $_POST['time'];
    $name = trim($_POST['name']);
    $guests = $_POST['guests'];
    $description = trim($_POST['description']);
    $datetime = $date . ' ' . $time;
    $errors = [];

    if (empty($table)) $errors[] = "No table selected.";
    if ($date < date('Y-m-d')) $errors[] = "Reservation date cannot be in the past.";
    if (empty($time)) $errors[] = "Time is required.";
    // Improved name validation to allow any non-empty name with letters, spaces and common name characters
    if (empty($name) || !preg_match("/^[a-zA-Z\s\-'.]+$/", $name)) $errors[] = "Please enter a valid name (letters, spaces, hyphens, and apostrophes allowed).";
    if (empty($guests)) $errors[] = "Please select the number of guests.";

    $check_sql = "SELECT * FROM adminseats WHERE TableNum = '$table' AND Date = '$datetime' AND Confirmed = TRUE";
    $check_result = $conn->query($check_sql);
    if ($check_result->num_rows > 0) {
        $errors[] = "This table is already reserved for the selected date and time.";
    }

    if (empty($errors)) {
        $sql = "UPDATE adminseats SET
                    Date = '$datetime',
                    Description = '$description',
                    Status = 'Occupied',
                    Confirmed = TRUE
                WHERE TableNum = '$table'";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Seat reserved successfully!');</script>";
            $tableSelected = "";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        foreach ($errors as $error) {
            echo "<script>alert('Error: " . $error . "');</script>";
        }
    }
}

function isTableAvailable($tableNum, $conn) {
    $sql = "SELECT * FROM adminseats WHERE TableNum = '$tableNum' AND Status = 'Occupied'";
    $result = $conn->query($sql);
    return !($result && $result->num_rows > 0);
}

function getTableStatusClass($tableNum, $conn) {
    return isTableAvailable($tableNum, $conn) ? "available" : "occupied";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table Reservation - QuickyBite</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="ustyles/SeatAvailability.css">
    <style>
        /* Fix for dropdown colors */
        select {
            color: var(--text-color) !important;
        }
        select option {
            background-color: var(--card-bg);
            color: var(--text-color);
        }
        select option:first-child {
            color: #999;
        }
    </style>
</head>
<body>
    <nav class="side-nav">
        <div class="logo-box">QB</div>
        <a href="user_dashboard.php" class="nav-icon">
            <img src="uimages/house-blank.png" alt="Dashboard">
            <span class="nav-icon-text">Dashboard</span>
        </a>
        <a href="DisplayMenu.php" class="nav-icon">
            <img src="uimages/task-checklist.png" alt="Menu">
            <span class="nav-icon-text">Menu</span>
        </a>
        <a href="ViewCart.php" class="nav-icon">
            <img src="uimages/shopping-cart.png" alt="Cart">
            <span class="nav-icon-text">Cart</span>
        </a>
        <a href="SeatAvailability.php" class="nav-icon active">
            <img src="uimages/chair.png" alt="Seats">
            <span class="nav-icon-text">Seat Availability</span>
        </a>
        <a href="MyAccount.php" class="nav-icon">
            <img src="uimages/user.png" alt="My Account">
            <span class="nav-icon-text">My Account</span>
        </a>
        <a href="../Login/logout.php" class="nav-icon">
            <img src="uimages/exit.png" alt="Logout">
            <span class="nav-icon-text">Log Out</span>
        </a>
    </nav>

    <div class="main-content">
        <h1>Table Reservation</h1>
        
        <div class="reservation-content">
            <div class="layout-container">
                <h3>Restaurant Layout</h3>
                <form method="POST" action="">
                    <div class="restaurant-layout">
                        <?php
                        $tables = [
                            ['id' => 'A1', 'seats' => 4], ['id' => 'B1', 'seats' => 6], ['id' => 'C1', 'seats' => 2],
                            ['id' => 'A2', 'seats' => 4], ['id' => 'B2', 'seats' => 6], ['id' => 'C2', 'seats' => 2],
                            ['id' => 'A3', 'seats' => 4], ['id' => 'B3', 'seats' => 6], ['id' => 'C3', 'seats' => 2],
                            ['id' => 'A4', 'seats' => 4], ['id' => 'B4', 'seats' => 6], ['id' => 'C4', 'seats' => 2],
                            ['id' => 'A5', 'seats' => 4], ['id' => 'B5', 'seats' => 6], ['id' => 'C5', 'seats' => 2]
                        ];

                        foreach ($tables as $table) {
                            $tableId = $table['id'];
                            $tableSeats = $table['seats'];
                            $statusClass = getTableStatusClass($tableId, $conn);
                            $isSelected = ($tableSelected === $tableId);
                            if ($isSelected) $statusClass = "selected";
                            $disabled = ($statusClass === "occupied") ? "disabled" : "";
                        ?>
                            <div class="table <?php echo $statusClass; ?>">
                                <div class="table-label"><?php echo $tableId; ?></div>
                                <div class="seats-info"><?php echo $tableSeats; ?> seats</div>
                                <input type="checkbox" name="seats[]" value="<?php echo $tableId; ?>" <?php echo $disabled; ?> <?php echo $isSelected ? 'checked' : ''; ?>>
                            </div>
                        <?php } ?>
                    </div>

                    <div class="legend">
                        <div><div class="legend-box green"></div> Available</div>
                        <div><div class="legend-box orange"></div> Selected</div>
                        <div><div class="legend-box red"></div> Occupied</div>
                    </div>

                    <button type="submit" name="select_table" class="submit-btn">Select Table</button>
                </form>
            </div>

            <div class="form-container">
                <h3>Reservation Details</h3>
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="table">Table</label>
                        <input type="text" id="table" name="table" placeholder="Please select a table" value="<?php echo $tableSelected; ?>" readonly required>
                    </div>

                    <div class="form-group">
                        <label for="date">Date</label>
                        <input type="date" id="date" name="date" min="<?php echo date('Y-m-d'); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="time">Time</label>
                        <input type="time" id="time" name="time" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input type="text" id="name" name="name" placeholder="Enter your full name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="guests">Number of Guests</label>
                        <select id="guests" name="guests" required>
                            <option value="">Select number</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6+</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="description">Special Requests</label>
                        <input type="text" id="description" name="description" placeholder="Any special requests or notes">
                    </div>

                    <button type="submit" name="confirm_seat" class="submit-btn">Confirm Reservation</button>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Set minimum date for date input to today
        document.getElementById('date').min = new Date().toISOString().split('T')[0];
        
        // Add animation when page loads
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.table').forEach(function(table, index) {
                setTimeout(function() {
                    table.style.opacity = '1';
                    table.style.transform = 'translateY(0)';
                }, index * 50);
            });
        });
    </script>
</body>
</html>