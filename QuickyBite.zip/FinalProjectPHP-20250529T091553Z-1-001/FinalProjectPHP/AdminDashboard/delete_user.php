<?php
session_start();
$host = "localhost";
$username = "root";
$password = "";
$database = "adris_ordertaking";

// Connect to database
$conn = mysqli_connect($host, $username, $password, $database);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

function sanitize($conn, $data) {
    return mysqli_real_escape_string($conn, trim($data));
}

// Validate user ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid user ID.");
}

$user_id = intval($_GET['id']);
$error = "";
$success = "";

// Fetch user data for confirmation
$sql = "SELECT username, full_name, email FROM users WHERE user_id = $user_id LIMIT 1";
$result = mysqli_query($conn, $sql);

if (!$result || mysqli_num_rows($result) == 0) {
    die("User not found.");
}

$user = mysqli_fetch_assoc($result);

// Handle deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
    $deleteSql = "DELETE FROM users WHERE user_id = $user_id";
    if (mysqli_query($conn, $deleteSql)) {
        $success = "User deleted successfully.";
    } else {
        $error = "Error deleting user: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Delete User</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" />
<style>
    body {
        background-color: #000;
        color: #fff;
        font-family: Arial, sans-serif;
        padding: 20px;
    }
    .form-control, .form-select {
        background-color: rgba(255,255,255,0.1);
        border: 1px solid rgba(255,255,255,0.2);
        color: #fff;
    }
    .btn-danger {
        background-color: #dc3545;
        border-color: #dc3545;
    }
    .btn-danger:hover {
        background-color: #c82333;
        border-color: #bd2130;
    }
    .btn-secondary {
        background-color: #6c757d;
        border-color: #6c757d;
    }
</style>
</head>
<body>

<div class="container">
    <h2>Delete User</h2>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php elseif ($success): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <a href="get-user-orders.php" class="btn btn-secondary mt-3">Back to Users</a>
    <?php else: ?>
        <div class="alert alert-warning">
            <strong>Warning!</strong> You are about to delete the following user:
            <ul>
                <li><strong>Username:</strong> <?php echo htmlspecialchars($user['username']); ?></li>
                <li><strong>Full Name:</strong> <?php echo htmlspecialchars($user['full_name']); ?></li>
                <li><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></li>
            </ul>
            This action <strong>cannot be undone</strong>.
        </div>

        <form method="post" action="">
            <input type="hidden" name="confirm_delete" value="1" />
            <button type="submit" class="btn btn-danger">Delete User</button>
            <a href="get-user-orders.php" class="btn btn-secondary">Cancel</a>
        </form>
    <?php endif; ?>
</div>

</body>
</html>
