<?php

require 'vendor/autoload.php'; // PHPMailer via Composer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "adris";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Database connection failed: ' . $conn->connect_error
    ]);
    exit();
}

// Handle POST request
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Sanitize and retrieve form data
    $name = filter_var(trim($_POST['name']), FILTER_SANITIZE_STRING);
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    $subject = filter_var(trim($_POST['subject']), FILTER_SANITIZE_STRING);
    $message = filter_var(trim($_POST['message']), FILTER_SANITIZE_STRING);
    $date = date('Y-m-d H:i:s');

    // Validate required fields
    if (empty($name) || empty($email) || empty($message)) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Please fill in all required fields.'
        ]);
        exit();
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Please enter a valid email address.'
        ]);
        exit();
    }

    // Insert message into the database
    $stmt = $conn->prepare("INSERT INTO contact_message (name, email, subject, message, `submission-date`) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $subject, $message, $date);

    if ($stmt->execute()) {
        // Prepare email content
        $emailBody = "
            <h2>New Contact Form Message</h2>
            <p><strong>Name:</strong> {$name}</p>
            <p><strong>Email:</strong> <a href='mailto:{$email}'>{$email}</a></p>
            <p><strong>Subject:</strong> {$subject}</p>
            <p><strong>Message:</strong><br>{$message}</p>
            <hr>
            <p>This message was sent via the Adris Contact Form on {$date}</p>
        ";

        // Send email using PHPMailer
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'adrisquickybite@gmail.com'; // Your Gmail address
            $mail->Password = 'dxvz rvwx hzvz frfn';       // App password
            $mail->SMTPSecure = 'ssl';
            $mail->Port = 465;

            $mail->setFrom($email, $name);
            $mail->addReplyTo($email, $name); // User's email for reply
            $mail->addAddress('adrisquickybite@gmail.com', 'Adris Admin'); // Receiver

            $mail->isHTML(true);
            $mail->Subject = "New Message from {$name} <{$email}>: {$subject}";
            $mail->Body = $emailBody;

            $mail->send();

            // Show success message then redirect
            echo "
                <script>
                    alert('Thank you! Your message has been sent successfully.');
                    window.location.href = 'homepage.html';
                </script>
            ";
            exit();

        } catch (Exception $e) {
            echo json_encode([
                'status' => 'partial',
                'message' => 'Your message was saved, but email delivery failed: ' . $mail->ErrorInfo
            ]);
            exit();
        }
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Error saving your message: ' . $stmt->error
        ]);
        exit();
    }
}

// Handle invalid request methods
echo json_encode([
    'status' => 'error',
    'message' => 'Invalid request method.'
]);
exit();

?>
