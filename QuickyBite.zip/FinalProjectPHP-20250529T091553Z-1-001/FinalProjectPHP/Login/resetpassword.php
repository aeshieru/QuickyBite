<?php
// resetpassword.php
session_start();

require 'vendor/autoload.php';

// Database configuration
$host = "localhost";
$username = "root";
$password = "";
$database = "adris_ordertaking";

// Initialize variables
$message = "";
$messageType = "";
$token = isset($_GET['token']) ? trim($_GET['token']) : '';
$validToken = false;

// CSRF token for security
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

try {
    $conn = new mysqli($host, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Database connection failed: " . $conn->connect_error);
    }

    $conn->set_charset("utf8mb4");

    // Validate token
    if (empty($token)) {
        throw new Exception("Invalid or missing reset token.");
    }

    // Check if the token exists and is valid (not expired)
    $now = date('Y-m-d H:i:s');
    
    // Debug log
    error_log("Checking token: $token at time: $now");
    
    $stmt = $conn->prepare("SELECT `user_id` FROM password_reset WHERE token = ? AND expires > ?");
    if (!$stmt) {
        throw new Exception("Prepare statement failed: " . $conn->error);
    }
    
    $stmt->bind_param("ss", $token, $now);
    if (!$stmt->execute()) {
        throw new Exception("Execute failed: " . $stmt->error);
    }
    
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        throw new Exception("Invalid or expired token. Please request a new password reset link.");
    }
    
    $validToken = true;
    $row = $result->fetch_assoc();
    $userId = $row['user_id'];
    
    // Debug log
    error_log("Valid token found for user ID: $userId");
    
    // Handle form submission
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // CSRF token check
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            throw new Exception("Invalid security token. Please refresh the page and try again.");
        }

        $newPassword = trim($_POST['new_password'] ?? '');
        $confirmPassword = trim($_POST['confirm_password'] ?? '');

        if (empty($newPassword) || empty($confirmPassword)) {
            throw new Exception("Both password fields are required.");
        }

        if ($newPassword !== $confirmPassword) {
            throw new Exception("Passwords do not match.");
        }

        if (strlen($newPassword) < 8) {
            throw new Exception("Password must be at least 8 characters long.");
        }

        // Hash and update the password
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $updateStmt = $conn->prepare("UPDATE `users` SET `password` = ? WHERE `user_id` = ?");
        if (!$updateStmt) {
            throw new Exception("Prepare update statement failed: " . $conn->error);
        }
        
        $updateStmt->bind_param("si", $hashedPassword, $userId);

        if ($updateStmt->execute()) {
            $message = "Your password has been successfully reset. Redirecting to login page...";
            $messageType = "success";
            error_log("Password reset successful for user_id: $userId");

            $_SESSION['password_reset_success'] = true;

            // Delete used token
            $deleteStmt = $conn->prepare("DELETE FROM password_reset WHERE token = ?");
            if (!$deleteStmt) {
                error_log("Failed to prepare delete statement: " . $conn->error);
            } else {
                $deleteStmt->bind_param("s", $token);
                if (!$deleteStmt->execute()) {
                    error_log("Failed to delete token: " . $deleteStmt->error);
                }
                $deleteStmt->close();
            }
        } else {
            throw new Exception("Failed to update password. Please try again. Error: " . $updateStmt->error);
        }

        $updateStmt->close();
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    $message = $e->getMessage();
    $messageType = "error";
    error_log("Password reset error: " . $e->getMessage());
}

if (isset($conn)) {
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - QuickyBite</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="styles/resetpassword.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="logo">🍔 QuickyBite</div>
            <h2>Reset Password</h2>
            <p class="subtitle">Enter your new password below to reset your account password.</p>
        </div>

        <?php if (!empty($message)): ?>
            <div class="message <?php echo htmlspecialchars($messageType, ENT_QUOTES, 'UTF-8'); ?>">
                <?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?>
            </div>
        <?php endif; ?>

        <?php if ($messageType !== 'success' && $validToken): ?>
        <form method="POST" id="resetPasswordForm">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">

            <div class="form-group">
                <label for="new_password">New Password</label>
                <div class="password-field">
                    <input type="password" id="new_password" name="new_password" required placeholder="Enter your new password" minlength="8">
                    <span class="toggle-password" onclick="togglePasswordVisibility('new_password')">
                        <i class="fa fa-eye" id="new_password_toggle"></i>
                    </span>
                </div>
            </div>

            <div class="form-group">
                <label for="confirm_password">Confirm Password</label>
                <div class="password-field">
                    <input type="password" id="confirm_password" name="confirm_password" required placeholder="Confirm your new password" minlength="8">
                    <span class="toggle-password" onclick="togglePasswordVisibility('confirm_password')">
                        <i class="fa fa-eye" id="confirm_password_toggle"></i>
                    </span>
                </div>
            </div>

            <button type="submit" class="submit-btn" id="submitBtn">
                <span class="loading" id="loading"></span>
                <span id="btnText">Reset Password</span>
            </button>
        </form>

        <div class="security-note">
            <strong>🔐 Security Note:</strong> 
            Your new password must be at least 8 characters long. Choose a strong password and do not reuse passwords from other services.
        </div>
        <?php endif; ?>

        <script>
            function togglePasswordVisibility(fieldId) {
                const passwordField = document.getElementById(fieldId);
                const toggleIcon = document.getElementById(fieldId + '_toggle');
                
                if (passwordField.type === 'password') {
                    passwordField.type = 'text';
                    toggleIcon.className = 'fa fa-eye-slash';
                } else {
                    passwordField.type = 'password';
                    toggleIcon.className = 'fa fa-eye';
                }
            }
            
            const form = document.getElementById('resetPasswordForm');
            if (form) {
                form.addEventListener('submit', function(e) {
                    const submitBtn = document.getElementById('submitBtn');
                    const loading = document.getElementById('loading');
                    const btnText = document.getElementById('btnText');

                    submitBtn.disabled = true;
                    loading.style.display = 'inline-block';
                    btnText.textContent = 'Resetting...';

                    const newPassword = document.getElementById('new_password').value;
                    const confirmPassword = document.getElementById('confirm_password').value;

                    if (newPassword !== confirmPassword) {
                        e.preventDefault();
                        alert('Passwords do not match!');
                        submitBtn.disabled = false;
                        loading.style.display = 'none';
                        btnText.textContent = 'Reset Password';
                        return false;
                    }

                    if (newPassword.length < 8) {
                        e.preventDefault();
                        alert('Password must be at least 8 characters long!');
                        submitBtn.disabled = false;
                        loading.style.display = 'none';
                        btnText.textContent = 'Reset Password';
                        return false;
                    }

                    setTimeout(function () {
                        if (submitBtn.disabled) {
                            submitBtn.disabled = false;
                            loading.style.display = 'none';
                            btnText.textContent = 'Reset Password';
                        }
                    }, 30000);
                });
            }

            window.addEventListener('load', function () {
                const newPasswordField = document.getElementById('new_password');
                if (newPasswordField) {
                    newPasswordField.focus();
                }
            });

            <?php if ($messageType === 'success'): ?>
            setTimeout(function () {
                window.location.href = 'logins.php';
            }, 3000);
            <?php endif; ?>
        </script>
    </div>
</body>
</html>

<style>
/* Add this if not already in your resetpassword.css file */
.password-field {
    position: relative;
}

.toggle-password {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    color: #777;
}

.toggle-password:hover {
    color: #333;
}
</style>