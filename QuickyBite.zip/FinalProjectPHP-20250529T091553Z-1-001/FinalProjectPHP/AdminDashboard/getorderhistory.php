<?php
// get_order_history.php - This script fetches and displays the order history for a specific user

session_start();
$host = "localhost";
$username = "root"; 
$password = ""; 
$database = "adris_ordertaking"; 

// Connect to database
$conn = mysqli_connect($host, $username, $password, $database);

// Check connection
if (!$conn) {
    die("<div class='alert alert-danger'>Connection failed: " . mysqli_connect_error() . "</div>");
}

// Function to sanitize input
function sanitize($conn, $data) {
    return mysqli_real_escape_string($conn, trim($data));
}

// Check if user_id is set and is numeric
if (isset($_GET['user_id']) && is_numeric($_GET['user_id'])) {
    $userId = sanitize($conn, $_GET['user_id']);
    
    // Check if user exists and get user information
    $checkUserSql = "SELECT * FROM users WHERE user_id = ?";
    $stmt = mysqli_prepare($conn, $checkUserSql);
    mysqli_stmt_bind_param($stmt, "i", $userId);
    mysqli_stmt_execute($stmt);
    $userResult = mysqli_stmt_get_result($stmt);
    
    if (mysqli_num_rows($userResult) == 0) {
        echo "<div class='alert' style='background: rgba(248, 100, 100, 0.2); border: 1px solid rgba(248, 100, 100, 0.5); color: #ff6b6b; padding: 15px; border-radius: 8px;'>User not found</div>";
        exit;
    }
    
    // Get user data
    $user = mysqli_fetch_assoc($userResult);
    
    // Display customer info
    echo "<div class='user-info mb-4' style='background: rgba(248, 232, 232, 0.05); border-radius: 10px; padding: 20px; border: 1px solid rgba(255, 255, 255, 0.1);'>";
    echo "<div class='row'>";
    echo "<div class='col-md-6'>";
    echo "<p><strong style='color: #f8a8c8;'>Name:</strong> <span style='color: #ffffff;'>" . htmlspecialchars($user['full_name']) . "</span></p>";
    echo "<p><strong style='color: #f8a8c8;'>Email:</strong> <span style='color: #ffffff;'>" . htmlspecialchars($user['email']) . "</span></p>";
    echo "</div>";
    echo "<div class='col-md-6'>";
    echo "<p><strong style='color: #f8a8c8;'>Phone:</strong> <span style='color: #ffffff;'>" . htmlspecialchars($user['phone_number']) . "</span></p>";
    echo "<p><strong style='color: #f8a8c8;'>Account Type:</strong> <span style='color: #ffffff;'>" . htmlspecialchars($user['user_type']) . "</span></p>";
    echo "</div>";
    echo "</div>";
    echo "</div>";
    
    // Prepare and execute order query using prepared statement
    $orderSql = "SELECT o.OrderID, o.CustomerName, o.OrderDate, o.Status 
             FROM orders o
             WHERE o.user_id = ?
             ORDER BY o.OrderDate DESC";
             
    $orderStmt = mysqli_prepare($conn, $orderSql);
    mysqli_stmt_bind_param($orderStmt, "i", $userId);
    mysqli_stmt_execute($orderStmt);
    $orderResult = mysqli_stmt_get_result($orderStmt);
    
    // Check if there are any orders
    if ($orderResult && mysqli_num_rows($orderResult) > 0) {
        echo "<div class='table-responsive'>";
        echo "<table class='table table-bordered table-hover' style='color: #ffffff; border-color: rgba(255, 255, 255, 0.1);'>";
        echo "<thead>";
        echo "<tr style='background: rgba(248, 120, 160, 0.1);'>";
        echo "<th style='border-color: rgba(255, 255, 255, 0.1); color: #f8a8c8;'>Order ID</th>";
        echo "<th style='border-color: rgba(255, 255, 255, 0.1); color: #f8a8c8;'>Customer Name</th>";
        echo "<th style='border-color: rgba(255, 255, 255, 0.1); color: #f8a8c8;'>Date</th>";
        echo "<th style='border-color: rgba(255, 255, 255, 0.1); color: #f8a8c8;'>Payment Method</th>";
        echo "<th style='border-color: rgba(255, 255, 255, 0.1); color: #f8a8c8;'>Status</th>";
        echo "<th style='border-color: rgba(255, 255, 255, 0.1); color: #f8a8c8;'>Actions</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";
        
        while ($order = mysqli_fetch_assoc($orderResult)) {
            $orderId = htmlspecialchars($order['OrderID']);
            
            echo "<tr style='border-color: rgba(255, 255, 255, 0.1);'>";
            echo "<td style='border-color: rgba(255, 255, 255, 0.1);'>#" . $orderId . "</td>";
            echo "<td style='border-color: rgba(255, 255, 255, 0.1);'>" . htmlspecialchars($order['CustomerName']) . "</td>";
            echo "<td style='border-color: rgba(255, 255, 255, 0.1);'>" . date('M d, Y h:i A', strtotime($order['OrderDate'])) . "</td>";
            echo "<td style='border-color: rgba(255, 255, 255, 0.1);'>" . htmlspecialchars('Gcash') . "</td>";
            
            // Display status with appropriate badge color
            echo "<td style='border-color: rgba(255, 255, 255, 0.1);'>";
            $statusClass = "";
            $statusBgColor = "";
            $statusTextColor = "#ffffff";
            
            switch($order['Status']) {
                case 'Pending':
                    $statusBgColor = "rgba(255, 152, 0, 0.3)";
                    $statusTextColor = "#ffc107";
                    break;
                case 'Processing':
                    $statusBgColor = "rgba(0, 123, 255, 0.3)";
                    $statusTextColor = "#0dcaf0";
                    break;
                case 'Completed':
                    $statusBgColor = "rgba(40, 167, 69, 0.3)";
                    $statusTextColor = "#4caf50";
                    break;
                case 'Cancelled':
                    $statusBgColor = "rgba(220, 53, 69, 0.3)";
                    $statusTextColor = "#f44336";
                    break;
                default:
                    $statusBgColor = "rgba(108, 117, 125, 0.3)";
            }
            echo "<span style='display: inline-block; padding: 0.25em 0.6em; font-size: 0.85em; font-weight: 500; border-radius: 4px; background-color: " . $statusBgColor . "; color: " . $statusTextColor . ";'>" . htmlspecialchars($order['Status']) . "</span>";
            echo "</td>";
            
            echo "<td style='border-color: rgba(255, 255, 255, 0.1);'>";
            echo "<button class='btn btn-sm view-details' style='background-color: rgba(248, 120, 160, 0.7); border-color: rgba(248, 120, 160, 0.3); color: white;' data-orderid='" . $orderId . "'>View Details</button>";
            echo "</td>";
            echo "</tr>";
            
            // Hidden row for order details
            echo "<tr class='details-row' id='orderDetails_" . $orderId . "' style='display:none; border-color: rgba(255, 255, 255, 0.1);'>";
            echo "<td colspan='6' class='p-4' style='background: rgba(17, 17, 17, 0.7); border-color: rgba(255, 255, 255, 0.1);'>";
            
            // Get items for this order using prepared statement
            $itemSql = "SELECT oi.OrderItemID, oi.OrderID, oi.FoodName, oi.Quantity, oi.Price 
                        FROM order_items oi 
                        WHERE oi.OrderID = ?";
            $itemStmt = mysqli_prepare($conn, $itemSql);
            mysqli_stmt_bind_param($itemStmt, "i", $order['OrderID']);
            mysqli_stmt_execute($itemStmt);
            $itemResult = mysqli_stmt_get_result($itemStmt);
            
            if (mysqli_num_rows($itemResult) > 0) {
                echo "<h5 class='mb-3' style='color: #f8a8c8; text-shadow: 0 0 5px rgba(248, 120, 160, 0.3);'>Ordered Items:</h5>";
                echo "<div class='table-responsive'>";
                echo "<table class='table table-sm table-bordered' style='color: #ffffff; border-color: rgba(255, 255, 255, 0.1);'>";
                echo "<thead>";
                echo "<tr style='background: rgba(248, 120, 160, 0.1);'>";
                echo "<th style='border-color: rgba(255, 255, 255, 0.1); color: #f8a8c8;'>Item</th>";
                echo "<th style='border-color: rgba(255, 255, 255, 0.1); color: #f8a8c8;'>Quantity</th>";
                echo "<th style='border-color: rgba(255, 255, 255, 0.1); color: #f8a8c8;'>Price</th>";
                echo "<th style='border-color: rgba(255, 255, 255, 0.1); color: #f8a8c8;'>Subtotal</th>";
                echo "</tr>";
                echo "</thead>";
                echo "<tbody>";
                
                $totalAmount = 0;
                $totalItems = 0;
                while ($item = mysqli_fetch_assoc($itemResult)) {
                    $subtotal = $item['Quantity'] * $item['Price'];
                    $totalAmount += $subtotal;
                    $totalItems += $item['Quantity'];
                    
                    echo "<tr style='border-color: rgba(255, 255, 255, 0.1);'>";
                    echo "<td style='border-color: rgba(255, 255, 255, 0.1);'>" . htmlspecialchars($item['FoodName']) . "</td>";
                    echo "<td style='border-color: rgba(255, 255, 255, 0.1);'>" . $item['Quantity'] . "</td>";
                    echo "<td style='border-color: rgba(255, 255, 255, 0.1);'>$" . number_format($item['Price'], 2) . "</td>";
                    echo "<td style='border-color: rgba(255, 255, 255, 0.1);'>$" . number_format($subtotal, 2) . "</td>";
                    echo "</tr>";
                }
                
                echo "</tbody>";
                echo "<tfoot>";
                echo "<tr style='border-color: rgba(255, 255, 255, 0.1); background: rgba(248, 120, 160, 0.05);'>";
                echo "<td colspan='3' class='text-end' style='border-color: rgba(255, 255, 255, 0.1);'><strong style='color: #f8a8c8;'>Total:</strong></td>";
                echo "<td style='border-color: rgba(255, 255, 255, 0.1);'><strong>$" . number_format($totalAmount, 2) . "</strong></td>";
                echo "</tr>";
                echo "</tfoot>";
                echo "</table>";
                echo "</div>";
                
                echo "<div class='row mt-3' style='background: rgba(248, 120, 160, 0.05); border-radius: 8px; padding: 10px; margin: 0;'>";
                echo "<div class='col-md-6'>";
                echo "<p><strong style='color: #f8a8c8;'>Total Items:</strong> <span style='color: #ffffff;'>" . $totalItems . "</span></p>";
                echo "</div>";
                echo "<div class='col-md-6'>";
                echo "<p><strong style='color: #f8a8c8;'>Payment Method:</strong> <span style='color: #ffffff;'>" . htmlspecialchars('Gcash') . "</span></p>";
                echo "</div>";
                echo "</div>";
            } else {
                echo "<p style='color: #f8e8e8; background: rgba(248, 120, 160, 0.05); padding: 10px; border-radius: 5px;'>No items found for this order.</p>";
            }
            
            echo "</td>";
            echo "</tr>";
        }
        
        echo "</tbody>";
        echo "</table>";
        echo "</div>";
    } else {
        echo "<div style='background: rgba(13, 202, 240, 0.2); border: 1px solid rgba(13, 202, 240, 0.5); color: #0dcaf0; padding: 15px; border-radius: 8px;'>This customer has not placed any orders yet.</div>";
    }
} else {
    echo "<div style='background: rgba(248, 100, 100, 0.2); border: 1px solid rgba(248, 100, 100, 0.5); color: #ff6b6b; padding: 15px; border-radius: 8px;'>Invalid user ID. Please provide a valid user ID.</div>";
}

// Close the database connection
mysqli_close($conn);
?>

<!-- Add jQuery if it's not already included in your page -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function() {
    // Use event delegation for dynamically created elements
    $(document).on('click', '.view-details', function() {
        var orderId = $(this).data('orderid');
        $('#orderDetails_' + orderId).toggle();
    });
    
    // Add hover effect to rows
    $('tbody tr').not('.details-row').hover(
        function() {
            $(this).css('background-color', 'rgba(248, 120, 160, 0.05)');
        }, 
        function() {
            $(this).css('background-color', '');
        }
    );
    
    // Add hover effect to buttons
    $('.view-details').hover(
        function() {
            $(this).css({
                'background-color': 'rgba(248, 120, 160, 0.9)',
                'border-color': 'rgba(248, 120, 160, 0.5)'
            });
        },
        function() {
            $(this).css({
                'background-color': 'rgba(248, 120, 160, 0.7)',
                'border-color': 'rgba(248, 120, 160, 0.3)'
            });
        }
    );
});
</script>