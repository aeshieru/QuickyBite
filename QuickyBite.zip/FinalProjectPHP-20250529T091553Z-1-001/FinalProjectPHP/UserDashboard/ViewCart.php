<?php
    session_start();
    $cart = $_SESSION['cart'] ?? [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Cart - QuickyBite</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="ustyles/ViewCart.css">
</head>
<body>
    <nav class="side-nav">
        <div class="logo-box">QB</div>
        <a href="user_dashboard.php" class="nav-icon">
            <img src="uimages/house-blank.png" alt="Dashboard">
            <span class="nav-icon-text">Dashboard</span>
        </a>
        <a href="DisplayMenu.php" class="nav-icon">
            <img src="uimages/task-checklist.png" alt="Menu">
            <span class="nav-icon-text">Menu</span>
        </a>
        <a href="ViewCart.php" class="nav-icon active">
            <img src="uimages/shopping-cart.png" alt="Cart">
            <span class="nav-icon-text">Cart</span>
        </a>
        <a href="SeatAvailability.php" class="nav-icon">
            <img src="uimages/chair.png" alt="Seat Availability">
            <span class="nav-icon-text">Seat Availability</span>
        </a>
        <a href="MyAccount.php" class="nav-icon">
            <img src="uimages/user.png" alt="My Account">
            <span class="nav-icon-text">My Account</span>
        </a>
        <a href="../Login/logout.php" class="nav-icon">
            <img src="uimages/exit.png" alt="Logout">
            <span class="nav-icon-text">Log Out</span>
        </a>
    </nav>

    <div class="main-content">
        <h1>Your Cart</h1>
        
        <div class="container">
            <div class="cart-container">
                <?php
                if(isset($_POST['clear_cart'])){
                    unset($_SESSION['cart']);
                    $cart = [];
                    echo '<div class="empty-cart">Cart has been cleared</div>';
                }

                if(isset($_POST['remove_item'])){
                    $index = $_POST['item_index'];
                    unset($cart[$index]);
                    $cart = array_values($cart);
                    $_SESSION['cart'] = $cart;
                }

                if(isset($_POST['qty_action'])){
                    $index = $_POST['item_index'];
                    $action = $_POST['qty_action'];

                    if($action === 'increase'){
                        $cart[$index]['Quantity']++;
                    }elseif($action === 'decrease'){
                        if($cart[$index]['Quantity'] > 1){
                            $cart[$index]['Quantity']--;
                        } else {
                            unset($cart[$index]);
                            $cart = array_values($cart); // Reindex array    
                        }
                    }

                    $_SESSION['cart'] = $cart;
                }

                if(empty($cart)){
                    echo '<div class="empty-cart">Your cart is empty</div>';
                } else {
                    $total = 0;
                    foreach ($cart as $index => $item):
                        $subtotal = $item['FoodPrice'] * $item['Quantity'];
                        $total += $subtotal;
                        ?>
                        <div class="cart-item">
                            <img src="<?= htmlspecialchars($item['FoodImage']) ?>" class="cart-item-image" alt="<?= htmlspecialchars($item['FoodName']) ?>">
                            <div class="cart-item-details">
                                <div class="cart-item-name"><?= htmlspecialchars($item['FoodName']) ?></div>
                                <div class="cart-item-price">₱<?= number_format($item['FoodPrice'], 2) ?></div>
                                
                                <div class="cart-quantity-controls">
                                    <form method="post" action="ViewCart.php" style="display:inline;">
                                        <input type="hidden" name="item_index" value="<?= $index ?>">
                                        <input type="hidden" name="qty_action" value="decrease">
                                        <button type="submit" class="quantity-btn">−</button>
                                    </form>
                                    
                                    <span class="quantity-value"><?= $item['Quantity'] ?></span>
                                    
                                    <form method="post" action="ViewCart.php" style="display:inline;">
                                        <input type="hidden" name="item_index" value="<?= $index ?>">
                                        <input type="hidden" name="qty_action" value="increase">
                                        <button type="submit" class="quantity-btn">+</button>
                                    </form>
                                </div>
                                
                                <div class="cart-item-actions">
                                    <div>Subtotal: ₱<?= number_format($subtotal, 2) ?></div>
                                    <form method="post" action="ViewCart.php">
                                        <input type="hidden" name="item_index" value="<?= $index ?>">
                                        <button type="submit" name="remove_item" class="remove-btn">Remove</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    
                    <div class="cart-summary">
                        <div class="total-price">Total: ₱<?= number_format($total, 2) ?></div>
                        
                        <div class="cart-actions">
                            <form method="post" action="ViewCart.php">
                                <button type="submit" name="clear_cart" class="action-btn clear-btn">Clear Cart</button>
                            </form>
                            
                            <form method="post" action="PaymentMethod.php">
                                <button type="submit" name="PaymentMethod" class="action-btn checkout-btn">Proceed to Checkout</button>
                            </form>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
</body>
</html> 