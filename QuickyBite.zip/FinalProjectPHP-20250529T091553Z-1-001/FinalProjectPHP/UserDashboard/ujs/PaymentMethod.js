 function selectPayment(method) {
            document.getElementById('paymentMethod').value = method;
            
            // Remove selected class from all
            const methods = document.querySelectorAll('.payment-method');
            methods.forEach(el => el.classList.remove('selected'));
            
            // Add selected class to clicked method
            const selectedMethod = Array.from(methods).find(el => 
                el.querySelector('.payment-method-name').textContent === method
            );
            selectedMethod.classList.add('selected');
        }
        
        function selectOrderType(type) {
            document.getElementById('orderType').value = type;
            
            // Remove selected class from all
            const types = document.querySelectorAll('.order-type');
            types.forEach(el => el.classList.remove('selected'));
            
            // Add selected class to clicked type
            const selectedType = Array.from(types).find(el => 
                el.querySelector('.order-type-name').textContent === type
            );
            selectedType.classList.add('selected');
            
            // Show/hide pickup time based on selection
            const pickupTimeContainer = document.getElementById('pickupTimeContainer');
            if (type === 'Take Out') {
                pickupTimeContainer.style.display = 'block';
                document.getElementById('pickupTime').setAttribute('required', 'required');
            } else {
                pickupTimeContainer.style.display = 'none';
                document.getElementById('pickupTime').removeAttribute('required');
            }
        }
        
        // Set initial selections
        document.addEventListener('DOMContentLoaded', function() {
            selectPayment('Cash');
            selectOrderType('Dine In');
        });