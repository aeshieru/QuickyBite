document.addEventListener('DOMContentLoaded', function() {
    // Add loading screen styles
    const loadingScreenStyle = document.createElement('style');
    loadingScreenStyle.textContent = `
        .loading-screen {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, #121212 0%, #1d1d1d 100%);
            z-index: 9999;
            display: flex;
            justify-content: center;
            align-items: center;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.5s ease, visibility 0.5s ease;
        }
        
        .loading-screen.active {
            opacity: 1;
            visibility: visible;
        }
        
        .loading-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            transform: translateY(20px);
            opacity: 0;
            transition: transform 0.8s ease, opacity 0.8s ease;
        }
        
        .loading-screen.active .loading-content {
            transform: translateY(0);
            opacity: 1;
        }
        
        .loading-logo {
            font-size: 2.5rem;
            font-weight: 700;
            color: #f1d6d6;
            margin-bottom: 30px;
            text-shadow: 0 0 15px rgba(241, 214, 214, 0.5);
            letter-spacing: 1px;
            animation: pulseLogo 2s infinite;
        }
        
        @keyframes pulseLogo {
            0%, 100% {
                opacity: 1;
                transform: scale(1);
            }
            50% {
                opacity: 0.8;
                transform: scale(1.05);
            }
        }
        
        .loading-animation {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 25px;
        }
        
        .loading-circle {
            width: 12px;
            height: 12px;
            margin: 0 5px;
            background-color: #f1d6d6;
            border-radius: 50%;
            animation: bounce 1.5s infinite ease-in-out;
            box-shadow: 0 0 10px rgba(241, 214, 214, 0.5);
        }
        
        .loading-circle:nth-child(1) { animation-delay: 0s; }
        .loading-circle:nth-child(2) { animation-delay: 0.2s; }
        .loading-circle:nth-child(3) { animation-delay: 0.4s; }
        .loading-circle:nth-child(4) { animation-delay: 0.6s; }
        .loading-circle:nth-child(5) { animation-delay: 0.8s; }
        
        @keyframes bounce {
            0%, 100% {
                transform: translateY(0);
                background-color: #f1d6d6;
            }
            50% {
                transform: translateY(-15px);
                background-color: palevioletred;
            }
        }
        
        .loading-text {
            color: #ccc;
            font-size: 1rem;
            text-align: center;
            animation: fadeInOut 2s infinite;
        }
        
        @keyframes fadeInOut {
            0%, 100% { opacity: 0.5; }
            50% { opacity: 1; }
        }
        
        /* Button loading state */
        .btn.loading {
            background-color: #8d7b7b;
            cursor: not-allowed;
        }
        
        .btn.loading i {
            animation: spin 1s infinite linear;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* Transition overlay for smooth redirect */
        .transition-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: white;
            z-index: 10000;
            opacity: 0;
            transition: opacity 0.5s ease;
            pointer-events: none;
        }
    `;
    
    document.head.appendChild(loadingScreenStyle);
    
    // Check if we're coming from a redirect and create fade-in effect
    if (document.referrer && document.referrer !== '') {
        const body = document.querySelector('body');
        
        // Create a fade-in overlay
        const fadeInOverlay = document.createElement('div');
        fadeInOverlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: white;
            z-index: 10000;
            opacity: 1;
            transition: opacity 0.8s ease;
        `;
        document.body.appendChild(fadeInOverlay);
        
        // Fade out the overlay to reveal the page
        setTimeout(() => {
            fadeInOverlay.style.opacity = '0';
            
            // Remove the overlay after transition completes
            setTimeout(() => {
                document.body.removeChild(fadeInOverlay);
            }, 800);
        }, 100);
    }

    // NEW FIX: Use event delegation for toggle password functionality
    // This attaches the event handler to the document which persists through DOM updates
    document.addEventListener('click', function(event) {
        // Check if the clicked element or any of its parents has the toggle-password class
        const toggleButton = event.target.closest('.toggle-password');
        
        if (toggleButton) {
            // Find the password input that's the previous sibling
            const passwordInput = toggleButton.previousElementSibling;
            
            if (passwordInput && (passwordInput.type === 'password' || passwordInput.type === 'text')) {
                // Toggle password visibility
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                
                // Toggle eye icon with smooth transition
                toggleButton.style.transition = 'transform 0.3s ease';
                toggleButton.style.transform = 'translateY(-50%) scale(1.2)';
                
                setTimeout(() => {
                    toggleButton.classList.toggle('fa-eye');
                    toggleButton.classList.toggle('fa-eye-slash');
                    
                    setTimeout(() => {
                        toggleButton.style.transform = 'translateY(-50%) scale(1)';
                    }, 100);
                }, 100);
                
                // Prevent event from bubbling up
                event.preventDefault();
                event.stopPropagation();
            }
        }
    });

    // NEW FIX: Use event delegation for input focus/blur effects
    document.addEventListener('focus', function(event) {
        if (event.target.matches('input[type="text"], input[type="password"]')) {
            const label = event.target.previousElementSibling || event.target.parentElement.previousElementSibling;
            if (label && label.tagName === 'LABEL') {
                label.style.color = '#f1d6d6';
                label.style.transition = 'color 0.3s ease';
            }
        }
    }, true); // Use capture phase
    
    document.addEventListener('blur', function(event) {
        if (event.target.matches('input[type="text"], input[type="password"]')) {
            const label = event.target.previousElementSibling || event.target.parentElement.previousElementSibling;
            if (label && label.tagName === 'LABEL' && !event.target.value) {
                label.style.color = '#ccc';
            }
        }
    }, true); // Use capture phase

    // Enhanced form validation with animations
    function setupFormValidation() {
        const form = document.getElementById('loginForm');
        if (form) {
            // Remove any existing event listeners
            const newForm = form.cloneNode(true);
            form.parentNode.replaceChild(newForm, form);
            
            const loginBtn = document.getElementById('loginBtn');
            let formActionURL = newForm.getAttribute('action') || '';
            
            newForm.addEventListener('submit', function(event) {
                // Always prevent default form submission first
                event.preventDefault();
                
                // Get form elements
                const username = document.getElementById('username').value.trim();
                const password = document.getElementById('password').value;
                
                let valid = true;
                let message = '';
                let errorField = null;
                
                // Reset previously highlighted fields
                document.querySelectorAll('input').forEach(input => {
                    input.style.boxShadow = '';
                });
                
                // Check required fields
                if (username === '') {
                    message = 'Please enter your username or email';
                    errorField = document.getElementById('username');
                    valid = false;
                } else if (password === '') {
                    message = 'Please enter your password';
                    errorField = document.getElementById('password');
                    valid = false;
                }
                
                // Display validation error if any
                if (!valid) {
                    // Create or update error message
                    let messageDiv = document.querySelector('.message');
                    if (messageDiv) {
                        document.querySelector('.container').removeChild(messageDiv);
                    }
                    
                    messageDiv = document.createElement('div');
                    messageDiv.className = 'message error';
                    messageDiv.innerHTML = `<i class="fas fa-exclamation-circle"></i>${message}`;
                    document.querySelector('.container').insertBefore(messageDiv, document.querySelector('form'));
                    
                    // Animate error message
                    setTimeout(() => {
                        messageDiv.style.animation = 'slideDown 0.5s ease forwards';
                    }, 10);
                    
                    // Highlight error field with shake animation
                    if (errorField) {
                        errorField.style.boxShadow = '0 0 0 2px var(--error-color)';
                        errorField.classList.add('shake');
                        errorField.focus();
                        
                        // Remove shake class after animation completes
                        setTimeout(() => {
                            errorField.classList.remove('shake');
                        }, 600);
                    }
                } else {
                    // First change button to loading state
                    if (loginBtn) {
                        loginBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> LOGGING IN...';
                        loginBtn.classList.add('loading');
                    }
                    
                    // Show loading screen immediately
                    showLoadingScreen();
                    
                    // Handle form submission with AJAX instead of traditional form submit
                    // This allows us to control the transition to the dashboard
                    const formData = new FormData(newForm);
                    
                    fetch(formActionURL, {
                        method: 'POST',
                        body: formData,
                        credentials: 'same-origin'
                    })
                    .then(response => {
                        if (response.redirected) {
                            // Create overlay for smooth transition to dashboard
                            const transitionOverlay = document.createElement('div');
                            transitionOverlay.className = 'transition-overlay';
                            document.body.appendChild(transitionOverlay);
                            
                            // Wait a moment then fade in the transition overlay
                            setTimeout(() => {
                                transitionOverlay.style.opacity = '1';
                                
                                // After overlay is fully visible, redirect to the dashboard
                                setTimeout(() => {
                                    window.location.href = response.url;
                                }, 500);
                            }, 1000);
                        } else {
                            // If no redirect, assume there was an error
                            response.text().then(html => {
                                // Replace current page with response
                                document.open();
                                document.write(html);
                                document.close();
                                
                                // After page content is replaced, reinitialize everything with delay
                                setTimeout(() => {
                                    setupMessageDismiss();
                                    setupAnimatedBackground();
                                    setupFormValidation();
                                }, 100);
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error during login:', error);
                        // If fetch fails, submit the form traditionally
                        newForm.submit();
                    });
                }
            });
        }
    }

    // Initialize form validation
    setupFormValidation();

    // Create and show the loading screen
    function showLoadingScreen() {
        // Create the loading screen container
        const loadingScreen = document.createElement('div');
        loadingScreen.className = 'loading-screen';
        
        // Create the loading content
        const loadingContent = document.createElement('div');
        loadingContent.className = 'loading-content';
        
        // Create logo element
        const logo = document.createElement('div');
        logo.className = 'loading-logo';
        logo.innerHTML = 'QuickyBite';
        
        // Create loading animation
        const loadingAnimation = document.createElement('div');
        loadingAnimation.className = 'loading-animation';
        
        // Create loading circles
        for (let i = 0; i < 5; i++) {
            const circle = document.createElement('div');
            circle.className = 'loading-circle';
            loadingAnimation.appendChild(circle);
        }
        
        // Create loading text
        const loadingText = document.createElement('div');
        loadingText.className = 'loading-text';
        loadingText.innerHTML = 'Preparing your dashboard...';
        
        // Assemble the loading screen
        loadingContent.appendChild(logo);
        loadingContent.appendChild(loadingAnimation);
        loadingContent.appendChild(loadingText);
        loadingScreen.appendChild(loadingContent);
        
        // Add to document body
        document.body.appendChild(loadingScreen);
        
        // Trigger the entrance animation
        setTimeout(() => {
            loadingScreen.classList.add('active');
        }, 10);
    }

    // FIX: Separate function for message dismissal
    function setupMessageDismiss() {
        // Auto-dismiss success messages after a delay
        const message = document.querySelector('.message');
        if (message && message.classList.contains('success')) {
            setTimeout(function() {
                message.style.animation = 'fadeOut 0.5s ease forwards';
                
                setTimeout(function() {
                    message.remove();
                }, 500);
            }, 3000);
        }
    }
    
    // Initialize message dismissal
    setupMessageDismiss();

    // Check for existing URL parameters that might indicate a redirect message
    const urlParams = new URLSearchParams(window.location.search);
    const status = urlParams.get('status');
    const msg = urlParams.get('message');
    
    if (status && msg) {
        let messageDiv = document.createElement('div');
        messageDiv.className = `message ${status}`;
        
        const icon = document.createElement('i');
        icon.className = `fas fa-${status === 'error' ? 'exclamation-circle' : 'check-circle'}`;
        messageDiv.appendChild(icon);
        
        const textNode = document.createTextNode(decodeURIComponent(msg));
        messageDiv.appendChild(textNode);
        
        const container = document.querySelector('.container');
        const form = document.getElementById('loginForm');
        container.insertBefore(messageDiv, form);
        
        // Auto-dismiss success messages
        if (status === 'success') {
            setTimeout(function() {
                messageDiv.style.animation = 'fadeOut 0.5s ease forwards';
                
                setTimeout(function() {
                    messageDiv.remove();
                }, 500);
            }, 3000);
        }
    }

    // FIX: Separate function for animated background
    function setupAnimatedBackground() {
        // Clean up any existing event listeners
        document.removeEventListener('mousemove', handleMouseMove);
        
        // Add slight movement to bubbles based on mouse position
        document.addEventListener('mousemove', handleMouseMove);
        
        // Add subtle pulse to the login button
        const loginBtn = document.querySelector('.btn');
        if (loginBtn) {
            if (window.pulseInterval) {
                clearInterval(window.pulseInterval);
            }
            
            window.pulseInterval = setInterval(() => {
                loginBtn.style.boxShadow = '0 4px 15px rgba(241, 214, 214, 0.5)';
                
                setTimeout(() => {
                    loginBtn.style.boxShadow = '0 4px 12px rgba(241, 214, 214, 0.3)';
                }, 1000);
            }, 2000);
            
            // Clean up interval when navigating away
            window.addEventListener('beforeunload', () => {
                clearInterval(window.pulseInterval);
            });
        }
    }
    
    function handleMouseMove(e) {
        const bubbles = document.querySelectorAll('.bg-bubble');
        const mouseX = e.clientX / window.innerWidth;
        const mouseY = e.clientY / window.innerHeight;
        
        bubbles.forEach((bubble, index) => {
            const depth = index + 1;
            const moveX = (mouseX - 0.5) * 20 / depth;
            const moveY = (mouseY - 0.5) * 20 / depth;
            
            bubble.style.transform = `translate(${moveX}px, ${moveY}px) scale(${1 + mouseY * 0.1})`;
        });
    }
    
    // Initialize animated background
    setupAnimatedBackground();
    
    // Handle DOM mutations - completely reimagined approach
    const observer = new MutationObserver(function(mutations) {
        let documentReplaced = false;
        
        mutations.forEach(function(mutation) {
            // Look for substantial DOM changes that might indicate a page refresh
            if (mutation.type === 'childList' && 
                (mutation.target === document.body || mutation.target === document.documentElement)) {
                documentReplaced = true;
            }
        });
        
        if (documentReplaced) {
            // If we detect a major DOM change, reinitialize everything
            setTimeout(function() {
                setupFormValidation();
                setupMessageDismiss();
                setupAnimatedBackground();
            }, 100);
        }
    });
    
    // Start observing the document with the configured parameters
    observer.observe(document, { childList: true, subtree: true });
});